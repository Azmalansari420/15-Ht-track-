<!DOCTYPE html>

<html lang="en-US">
    <head>
    <meta charset="utf-8"/>
        <meta name="_csrf" content="aae83eeb-2a20-4d82-9b40-00ab49e1546b"/>
        <meta name="_csrf_header" content="X-XSRF-TOKEN"/>

        <link rel="preload" href="https://assets.winni.in/coreast/constant/font/roboto/roboto-700.woff2" as="font" type="font/woff2" crossorigin>
        <link rel="preload" href="https://assets.winni.in/coreast/constant/font/roboto/roboto-400.woff2" as="font" type="font/woff2" crossorigin>

        <link rel="dns-prefetch" href="//d3s16h6oq3j5fb.cloudfront.net">
        <link rel="dns-prefetch" href="//dr56butoyblab.cloudfront.net">
        <link rel="dns-prefetch" href="//d3s16h6oq3j5fb.cloudfront.net">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>Page Not Found | Winni.in</title>
            <meta name="currentCityId" content="">
            <meta name="theme-color" content="#ffffff">
        <meta name="apple-mobile-web-app-title" content="Winni">
        <meta name="application-name" content="Winni">
        <link rel="mask-icon" href="https://assets.winni.in/coreast/constant/icon/v1/safari-pinned-tab.svg" color="#dc0013">
        <link rel="apple-touch-icon" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="57x57" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="https://assets.winni.in/coreast/constant/icon/v1/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192" href="https://assets.winni.in/coreast/constant/icon/v1/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="https://assets.winni.in/coreast/constant/icon/v1/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="https://assets.winni.in/coreast/constant/icon/v1/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://assets.winni.in/coreast/constant/icon/v1/favicon-16x16.png">

        <link rel="manifest" href="https://assets.winni.in/coreast/constant/manifest/08022021-3CA8E/manifest.json">

        <meta property="fb:app_id" content="262562007188964" />
        <meta property="og:type" content="website">
        <meta property="og:image" content="https://assets.winni.in/groot/2023/05/06/winni-logo/logo-test-thirty-six.png">
                <meta property="og:title" content="Page Not Found | Winni.in">
            <meta property="og:site_name" content="Winni">
        <meta name="twitter:description" content="">
                <meta name="twitter:image" content="https://assets.winni.in/groot/2023/05/06/winni-logo/logo-test-thirty-six.png">
            <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:site" content="@WinniGifts">
        <meta name="twitter:title" content="Page Not Found | Winni.in">
            <link rel="stylesheet" href="https://assets.winni.in/coreast/constant/css/vnd/materialize-1.0.0.min.css" type="text/css"/>
        <link rel="stylesheet" href="/assets/css/thor/common.css;jsessionid=486A8842E4390D8EFB2D8B423AA04561" type="text/css"/>
                  <link rel="stylesheet" href="/assets/css/thor/deliveryIn-common.css;jsessionid=486A8842E4390D8EFB2D8B423AA04561" type="text/css"/>
                  <script>(function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({'gtm.start':
                            new Date().getTime(), event: 'gtm.js'});
                var f = d.getElementsByTagName(s)[0],
                        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                        'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-MT9R5X3');</script>

    <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-MT9R5X3"
                      height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


       <script type="text/javascript">
                   const MIXPANEL_CUSTOM_LIB_URL = "https://vision.winni.in/lib.min.js";
                   (function (f, b) { if (!b.__SV) { var e, g, i, h; window.mixpanel = b; b._i = []; b.init = function (e, f, c) { function g(a, d) { var b = d.split("."); 2 == b.length && ((a = a[b[0]]), (d = b[1])); a[d] = function () { a.push([d].concat(Array.prototype.slice.call(arguments, 0))); }; } var a = b; "undefined" !== typeof c ? (a = b[c] = []) : (c = "mixpanel"); a.people = a.people || []; a.toString = function (a) { var d = "mixpanel"; "mixpanel" !== c && (d += "." + c); a || (d += " (stub)"); return d; }; a.people.toString = function () { return a.toString(1) + ".people (stub)"; }; i = "disable time_event track track_pageview track_links track_forms track_with_groups add_group set_group remove_group register register_once alias unregister identify name_tag set_config reset opt_in_tracking opt_out_tracking has_opted_in_tracking has_opted_out_tracking clear_opt_in_out_tracking start_batch_senders people.set people.set_once people.unset people.increment people.append people.union people.track_charge people.clear_charges people.delete_user people.remove".split( " "); for (h = 0; h < i.length; h++) g(a, i[h]); var j = "set set_once union unset remove delete".split(" "); a.get_group = function () { function b(c) { d[c] = function () { call2_args = arguments; call2 = [c].concat(Array.prototype.slice.call(call2_args, 0)); a.push([e, call2]); }; } for ( var d = {}, e = ["get_group"].concat( Array.prototype.slice.call(arguments, 0)), c = 0; c < j.length; c++) b(j[c]); return d; }; b._i.push([e, f, c]); }; b.__SV = 1.2; e = f.createElement("script"); e.type = "text/javascript"; e.async = !0; e.src = "undefined" !== typeof MIXPANEL_CUSTOM_LIB_URL ? MIXPANEL_CUSTOM_LIB_URL : "file:" === f.location.protocol && "//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js".match(/^\/\//) ? "https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js" : "//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js"; g = f.getElementsByTagName("script")[0]; g.parentNode.insertBefore(e, g); } })(document, window.mixpanel || []);
                   mixpanel.init("6d946b9e4213ec8f7f281cf6e42fd895", {api_host: "https://vision.winni.in", track_pageview: true, persistence: 'localStorage'})
       </script>

    <script src="https://www.google.com/recaptcha/enterprise.js?render=6LffrDQpAAAAAAdJSbgVUcL7-4643gjXzCcIv7e1"></script>
    <script src="//swopstore.com/wrapper.php?method=container&shopId=SHOP_ID" type="text/javascript"></script>

    </head>
<body class="notFound">
    <a name="top" id="top"></a>
    <header >
        <style>
    .nav-wrapper #international li:first-child a {
        font-weight: bold;
    }
    .briefPageTitle h1{
        margin-top: 20px !important;
    }
    .briefPageTitle > p {
        float: left;
        text-align: center;
        width: 100%;
        font-size: 16px;
        margin: 20px 0 10px;
    }
    .maxWidthAllCountry{
    max-width: 1600px!important;
    margin: 0 auto!important;
    }
    .profile-dropdown-wishlist{
    top: 65px !important;
        width:80px !important
    }
    .profile-dropdown-cart{
    top: 65px !important;
            width:30px !important
    }
    .currencyHover:hover{
    color: #FF4E89;
    }
    .currencyHoverList:hover{
     color: #FF4E89;
     font-weight:600;
    }
    .partnerWithUs:hover{
     color: #FF4E89;
    }
    .left.bg-cart:hover {
        background-image: url('https://assets.winni.in/groot/2023/11/20/desktop/header-image/cart-pink.png');
    }

     .cartLeft{
       left:0px!important;
     }
     .profileLeft{
         left: 355.475px!important;
     }
.bg-wishlist {
    width: 45px;
    height: 33px;
    background: url("https://assets.winni.in/groot/2023/11/20/desktop/heart-svg.svg") no-repeat 0px 0px;
    background-size: 24px;
}
.selected-currency{
font-weight:bold;
}
        .trending-shortcut {
            background-color: white;
            border-radius: 10px;
        }

        .trending-shortcut__parent {
               display: flex;
               flex-wrap: wrap;
               gap: 2px;
               font-size: 16px;
               justify-content: normal;
               width: calc(100% - 20px);
        }
     .trending-shortcut__childTag , .search-item{
         padding: 6px 10px;
         border-radius: 5px;
         color: #333;
         text-decoration: none;
         transition: background-color 0.3s ease, color 0.3s ease, border 0.3s ease;
         border: 1px solid transparent;
         font-size:14px;
         font-weight:500;
         white-space: nowrap;
         overflow: hidden;
         text-overflow: ellipsis;
         margin-left: 5px;
     }

     .trending-shortcut__childTag:hover ,.search-item:hover  {
         background-color: #FFF8FB;
         color: #333333;
         border: 1px solid #EC9EC0;
         padding: 6px 10px;
     }

        .trending-shortcut__header {
          display: flex;
          align-items: center;
          width: 100%;
          max-width: 600px;
          margin: 5px auto;
        }

        .trending-shortcut__text {
          padding: 0 15px;
          font-size: 16px;
          color: #333;
          white-space: nowrap;
        }

        .trending-shortcut__header::after {
          content: "";
          flex-grow: 1;
          height: 2px;
          background-color: #e0e0e0;
        }
         .recent-search {
            width: 100%;
          }

        .recent-search__icon {
            margin-right: 10px;
            color: #666;
        }
           .user-search-item-tag{
                color: #333;
             }
             .align-span-tag{
                    vertical-align:bottom;
                }
                .recent-search_svg-icon{
                 vertical-align: middle;
                }
               #adbsearchEvent.input-field.twitter-typeahead.tt-menu {
                   line-height: initial !important;
                   background-color: #FFF !important;
                   width: 100% !important;
                   left: -10px !important;
                   margin-left: 10px !important;
                   box-shadow: 0px 4 !important;
                   max-height: fit-content !important;
                   overflow-y:none !important;
               }
               .tt-menu{
               overflow-y:auto !important;
               max-height: fit-content !important;
               }

</style>
<header style="position: fixed; left: 0; right: 0; z-index: 999;">
        <div class="">
            <nav class="white main-nav header-primary" style="margin:0 auto;margin-bottom:24px;max-width:1600px!important;">
                <div class="nav-wrapper">
                    <div class="sup-nav" style="padding-right:9px; margin-bottom: 12px;">
                    <a class="adbHeaderLink" href="/contact-us;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="border-right:2px solid #d7d7d7;font-size: 14px;">Help</a>
                     <span style="border-right:2px solid #d7d7d7;padding-right: 6px;font-size:14px;">
                        <a style="padding-right: 0" class="dropdown-trigger currencyHover" data-hover="true" data-belowOrigin="true" data-target="dropdowncurrency" data-constrainWidth="false">
                            Currency <span style="display: inline-block; width: 10px;">-&nbsp;</span><span style="padding:0px 3px; font-weight: bold" class="showUserCurrency"></span>
                        </a>
                        <ul id="dropdowncurrency" class='dropdown-content' style="border-radius:6px!important;font-size:12px!important;margin-bottom:10px;overflow-x: hidden;">
                          <div style="text-align:left;font-size:16px;color:black;padding-left:16px;font-weight:700;">Currency</div>
                            <li class="currency currencyHoverList" data-value="AUD" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('AUD')">AUD - Australian Dollar</li>
                            <li class="currency currencyHoverList" data-value="AED" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('AED')">AED - United Arab Emirates Dirham</li>
                            <li class="currency currencyHoverList" data-value="SGD" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('SGD')">SGD - Singapore Dollar</li>
                            <li class="currency currencyHoverList" data-value="QAR" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('QAR')">QAR - Qatari Rial</li>
                            <li class="currency currencyHoverList" data-value="EUR" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('EUR')">EUR - Euro</li>
                            <li class="currency currencyHoverList" data-value="GBP" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('GBP')">GBP - British Pound Sterling</li>
                            <li class="currency currencyHoverList" data-value="MYR" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('MYR')">MYR - Malaysian Ringgit</li>
                            <li class="currency currencyHoverList" data-value="USD" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('USD')">USD - United States Dollar</li>
                            <li class="currency currencyHoverList" data-value="CAD" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('CAD')">CAD - Canadian Dollar</li>
                            <li class="currency currencyHoverList" data-value="NZD" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('NZD')">NZD - New Zealand Dollar</li>
                            <li class="currency currencyHoverList" data-value="INR" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('INR')">INR - Indian Rupee</li>
                            <li class="currency currencyHoverList" data-value="THB" style="margin-top: 3px;margin-left:7px;font-size:12px!important;" onclick="selectCurrency('THB')">THB - Thai Baht</li>
                            </ul>
                    </span>
                     <a class="adbHeaderLink" target="_BLANK" href="/corporate;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="border-right:2px solid #d7d7d7;font-size: 14px;">Corporate Gifts</a>
                      <span style="border-right:2px solid #d7d7d7;padding-right: 6px;font-size: 14px;">
                                            <a style="padding-right: 0" class="adbHeaderLink dropdown-trigger partnerWithUs" data-hover="true" data-belowOrigin="true" data-target="dropdownpartner" data-constrainWidth="false">
                                                Partner With Us
                                            </a>
                                            <ul id="dropdownpartner" class='dropdown-content partner'>
                                                <li style="margin-top: 5px"><a class="adbHeaderLink" target="_BLANK" href="https://docs.google.com/forms/d/e/1FAIpQLScPw-OEiQkqHUA_Jrhc6DBJgAsVgkI6u9RJDgK7x3-XBsyyBQ/viewform">Become a vendor</a></li>
                                                <li style="margin-top: -2px"><a class="adbHeaderLink" target="_BLANK" href="/franchise;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Become a franchisee</a></li>
                                            </ul>
                                        </span>
                    <span style=""></span>
                    <a class="adbHeaderLink" href="/my-winni/orders/list;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="font-size: 14px;">Track Order</a>

                </div>
                <div class="nav-center" style="height: max-content;">
                    <div class="row">
                        <div class="col l2" style="padding-left: 0;margin-top: 10px">
                            <a id="adbHeaderLogo" style="margin-top: -10px" href="/;jsessionid=486A8842E4390D8EFB2D8B423AA04561" class="adbHeaderLink brand-logo bg-logo_home">
                                                            <input type="hidden" value="Winni Logo" />
                                                        </a>
                        </div>
                        <div class="hide" id="searchIconTemplate">
                            <span class="recent-search__icon">
                               <svg class="recent-search_svg-icon"  xmlns="http://www.w3.org/2000/svg" width="17" height="16.15" viewBox="0 0 17 16.15">
                                 <path id="Shape" d="M8.925,0a7.938,7.938,0,0,0-6.97,4.08L0,2.125V7.65H5.525L3.145,5.27A6.409,6.409,0,0,1,15.3,8.075,6.389,6.389,0,0,1,2.89,10.2H1.1A8.092,8.092,0,0,0,17,8.075,8.126,8.126,0,0,0,8.925,0ZM7.65,4.25V8.585l3.995,2.38.68-1.1-3.4-2.04V4.25Z" fill="#333" fill-rule="evenodd"/>
                               </svg>
                            </span>
                      </div>
                        <div class="col l4" style="padding-left: 30px;">
                            <form  id="adbsearchEvent" class="category-search" action="/search;jsessionid=486A8842E4390D8EFB2D8B423AA04561" method="GET" autocomplete="off" style="height :0">
                                <div class="input-field">
                                    <input id="search-input-in-desktop" class="search-input-desktop validate browser-default search-field adbSearch" placeholder="Search 5000+ flowers, cakes, gifts etc" maxlength="50" type="text" name="q" value="" style="border:2px solid transparent;background: none 0% 0% / auto repeat scroll padding-box border-box rgba(234, 233, 233, 0.75);width: 100%;height: 40px;color: #8f9196;font-weight:700;border-radius: 6px;vertical-align: top;" required>
                                     <img class="search-icon-image"  id="searchIconImg" src="https://assets.winni.in/groot/2023/01/31/icons/desktopheadersearch.png" alt="desktopheadersearch" style="width: 22px!important; margin-top: -31px!important;"/>
                                      <div class="search-dropdown-by-category adbSearchSugg ">
                                        <div class="trending-shortcut" style="padding: 12px 12px 0px 12px;">
                                             <div class="trending-shortcut__header hide">
                                               <span class="trending-shortcut__text">Recent Search</span>
                                              </div>
                                              <div class="search-item">
                                              </div>
                                          </div>
                                          <div class="trending-shortcut" style="padding: 0px 12px 12px 12px;">
                                             <div class="trending-shortcut__header">
                                              <span class="trending-shortcut__text">Trending Shortcut</span>
                                             </div>
                                                <div class="trending-shortcut__parent ">
                                                 <div style="width:33%;">
                                                    <a  class="trending-shortcut__childTag" style="font-size:14px;" data-adbPos="1" href="/cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes</a>
                                                 </div>
                                                  <div style="width:27%;">
                                                    <a  class="trending-shortcut__childTag" style="font-size:14px;margin: -10px;padding: calc(0.5% + 5px) calc(1% + 8px);"  data-adbPos="2" href="/flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flowers</a>
                                                  </div>
                                                   <div style="width:27%;">
                                                    <a class="trending-shortcut__childTag" style="font-size:14px;"  data-adbPos="3" href="/gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Gifts</a>
                                                 </div>
                                                <div style="width:27%;">
                                                  <a class="trending-shortcut__childTag"  style="font-size:14px;" data-adbPos="4"  href="/combos;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Combos</a>
                                                </div>
                                                 <div style="width:33%;">
                                                    <a class="trending-shortcut__childTag" style="font-size:14px;"  data-adbPos="5" href="/chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolates</a>
                                                 </div>
                                                  <div style="width:33%;">
                                                      <a class="trending-shortcut__childTag"  data-adbPos="8" href="/birthday-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Gifts</a>
                                                  </div>
                                                 <a class="trending-shortcut__childTag"   data-adbPos="7" href="/personalised-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalized Gifts</a>
                                                 <a class="trending-shortcut__childTag"   data-adbPos="6" href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Gifts</a>
                                                </div>
                                          </div>
                                      </div>
                               </div>
                            </form>


                        </div>
                        <div class="col l6" style="padding-right: 0;position: relative;">
                            <ul class=" hide-on-med-and-down nav-options">

                                <li>

                                                           <div class="left" style="padding-left:4px;">

                                                                 <style>
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.hide-arrow input[type="number"].indiaSearchPin {
    -moz-appearance: textfield;
}

inputBorder.tt-menu {
    max-height: calc(100dvh - 67vh) !important;
    overflow-y: auto !important;
}


#country-search {
    border-bottom: none !important;
}

#country-search {
    border-bottom: none !important;
}

.separator-desktop {
    display: flex;
    align-items: center;
    margin-top: -3px;
    margin-left: 110px;
    width: calc(100% - 216px);
    margin-bottom: 15px;
}

.separator-popular-cities {
    display: flex;
    align-items: center;
}

.separator-desktop hr,
.separator-popular-cities hr {
    flex-grow: 1;
    height: 2px;
    background-color: #cbc2c2;
    border: none;
}

.address-input[type=radio] {
    display: none;
}

.address-input[type=radio]+span:before,
.address-input[type=radio]+span:after {
    content: "";
    display: inline-block;
    width: 20px;
    height: 20px;
    background: transparent;
    border: 2px solid #5a5a5a;
    border-radius: 50%;
    margin-right: 10px;
    visibility: hidden;
}

.address-input[type=radio]:checked+span:before {
    background: transparent linear-gradient(135deg, #52AA07 0%, #246301 100%) 0% 0% no-repeat padding-box;
    visibility: hidden;
}

.separator-desktop .circle_or {
    margin: 0 0;
    display: flex;
    justify-content: center;
    align-items: center;
    width: 30px;
    height: 30px;
    border: 1px solid #707070 !important;
    border-radius: 50%;
    font-weight: bold;
    color: #33333;
    padding: 23px;
}

.open-address-modal {
    width: 100%;
    min-height: 100%;
    background: white;
    top: 0 !important;
    z-index: 99999;
}

.onEdit {
    font-size: 13px;
}

#ymDivCircle {
    z-index: 999 !important;
}

.citySearchContainer {
    background-color: #F2F3E8;
    height: 43px;
    margin-top: -16px;
}

.citySearchCmn {
    width: 100%;
    display: flex;
    box-sizing: border-box;
    flex-grow: 0;
}

.citySearchFirst {
    align-items: center;
    justify-content: center;
    max-width: 25%;
    flex-basis: 18%;
}

.citySearchFirstDivide {
    flex-grow: 0;
    max-width: 50%;
    flex-basis: 50%;
}

.citySearchSecond {
    width: 100%;
    max-height: 43px;
    margin-left: 0px;
}

.citySearchSecondCmn {
    color: #333;
    justify-content: flex-start;
    align-items: flex-start;
    display: flex;
}

.citySearchLoc {
    align-items: center;
    justify-content: center;
    display: inline-flex;
    height: 52px;
    width: 100%;
    padding: 14px 8px;
    border-radius: 4px;
}



.city-search__input {
    align-items: center;
    justify-content: center;
    display: inline-flex;
    height: 43px;
    text-transform: none;
    width: 100%;
    padding: 6px 8px;
    border: 1px solid #D5D5D5;
}

.citysearchModal {
    top: unset !important;
    bottom: 0 !important;
    width: 100% !important;
    z-index: 1003 !important;
    max-height: fit-content !important;
    border-radius: 20px;
}

.citysearchModal.bottom-sheet {
    left: 50%;
    top: 50% !important;
    transform: translate(-50%, -50%);
    width: 727px !important;
    height: fit-content !important;
    right: 50% !important;
    border-radius: 20px;
    overflow-y: visible;
}

.citysearchModal.bottom-sheet.active {
    bottom: 0;
    transform: translateY(100%);
}

.citysearchModal.bottom-sheet .modal-header .divider {
    margin: 0 auto;
    max-width: 40px;
    border: 2px solid #9e9e9e;
    border-radius: 10px;
    margin-bottom: 10px;

}

.selectOption :first-child {
    padding: 0;
    text-align: left;
}

.selectOption :nth-child(2) {
    text-align: right;
    padding: 0
}

.continueShopping {
    color: white !important;
    text-align: center;
    height: 47px !important;
    line-height: 47px !important;
    font-size: 14px;
    opacity: 1 !important;
    background-color: #9E9E9E;
    pointer-events: auto;
}

#deliveryLocModal {
    z-index: 999999 !important;
    top: unset !important;
    bottom: 0;
    min-height: 100% !important;
    background-color: white !important;
}

#deliveryCountryCity {
    z-index: 999999 !important;
    top: 0 !important;
    width: 100% !important;
}

#citySelectionByName {
    z-index: 999999 !important;
    top: 0 !important;
    width: 100% !important;
}

#indiaSearchPin {
    border: none !important;
    padding: 0px !important;
}



.inputBorder {
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: rgb(255 255 255) 0px 0px 5px !important;
    border-radius: 3px;
    display: flex;
    line-height: 40px;
    height: 47px;
    position: relative;
    width: 100%;
}

.inputBorderInter {
    border-radius: 3px;
    display: flex;
    line-height: 40px;
    height: 47px;
    position: relative;
    width: 100%;
}

.inputBorder .twitter-typeahead,
.inputBorderInter .twitter-typeahead {
    position: unset !important;
}

.inputBorder .tt-suggestion a,
.inputBorderInter .tt-suggestion a {
    display: initial;
}

.inputBorder .tt-suggestion::before,
.inputBorderInter .tt-suggestion::before {
    content: "";
    white-space: nowrap;
    display: inline-block;
    width: 13px;
    height: 18px;
    background-image: url('https://assets.winni.in/groot/2023/10/25/mobile/icon-material-location.png');
    background-size: contain;
    margin-right: 10px;
    vertical-align: text-top;
    cursor: pointer;
    background-repeat: no-repeat, repeat;
    margin-top: 2px;
}

.inputBorder .tt-suggestion:hover:before,
.inputBorderInter .tt-suggestion:hover:before {
    cursor: pointer;
    background-image: url('https://assets.winni.in/groot/2022/04/26/pin-hover.png');
    vertical-align: text-top;
    width: 18px;
    height: 20px;
    margin-top: 2px;
    white-space: nowrap;
}


.inputBorder .tt-menu,
.inputBorderInter .tt-menu {
    margin: 0px 0 0 0px !important;
    box-shadow: 0 6px 12px 0 rgb(0 0 0 / 20%);
    width: 100%;
    left: 0 !important;
    right: 0 !important;
     background: #EFEFEF !important;
        border: 1px solid #bfbdbd !important;
        padding-left: 20px !important;
        padding-right: 20px !important;
          max-height: calc(100dvh - 67vh) !important;
            overflow-y: auto !important;
}

.inputBorder .tt-highlight,
.inputBorderInter .tt-highlight {
    font-weight: 600 !important;
}

.staticSuggestion {
    border-top: 3px solid #f3f3f3 !important;
    color: #2178CF;
    font-size: 14px;
    text-align: left
}

.staticSuggestion * {
    padding: 10px;
    border-bottom: 1px solid #f3f3f3 !important;
}

.suggestionTxt {
    vertical-align: bottom;
}

#indiaCityByName {
    border: none !important;
}

.inputBorder pre[aria-hidden="true"] {
    position: unset !important;
}

.radio-btn__div [type=radio].with-gap:checked+span:before,
.radio-btn__div [type=radio].with-gap:checked+span:after {
    border: 1px solid #333333 !important;
    margin-left: 4px !important;
    height: 21px !important;
    width: 21px !important;
    opacity: 1 !important;
}


.radio-btn__div [type=radio].with-gap:checked+span:after,
.radio-btn__div [type=radio].with-gap:checked+span:after {
    background: transparent linear-gradient(135deg, #52AA07 0%, #246301 100%) 0% 0% no-repeat padding-box !important;
    height: 21px !important;
    width: 21px !important;
    opacity: 1 !important;

}

.radio-btn__div [type=radio].with-gap:not(:checked)+span:after,
.radio-btn__div [type=radio].with-gap:not(:checked)+span:before {
    border: 2px solid #5a5a5a !important;
    height: 21px !important;
    width: 21px !important;
    opacity: 1 !important;
}

.countryFlagDesign {
    width: 45px !important;
    height: 25px !important;
    margin-top: 1px;
}

.tt-dataset tt-dataset-states {
    background: #EFEFEF 0% 0% no-repeat padding-box !important;
}

.inputBorder.tt-menu {
    background: #EFEFEF !important;
    border: 1px solid #bfbdbd !important;
    padding-left: 20px !important;
    padding-right: 20px !important;
}

.inputBorder .tt-suggestion,
.inputBorderInter .tt-suggestion {
    border-bottom: 1px solid #cdcccc !important;
    padding: 17px !important;
    padding-left: 0px !important;
    margin-left: -4px !important;
    font-size: 18px !important;
}

@media only screen and (min-width: 320px) and (max-width: 350px) {

    .inputBorder .tt-suggestion,
    .inputBorderInter .tt-suggestion {
        font-size: 11px !important;
    }
}

@media only screen and (min-width: 351px) and (max-width: 400px) {

    .inputBorder .tt-suggestion,
    .inputBorderInter .tt-suggestion {
        font-size: 14px !important;
    }
}

@media only screen and (min-width: 341px) and (max-width: 386px) {
    .selectDeliveryLocationText {
        font-size: 14px !important;
    }

    .clearAll {
        font-size: 14px !important;
    }
}

@media only screen and (min-width: 320px) and (max-width: 341px) {
    .selectDeliveryLocationText {
        font-size: 14px !important;
    }

    .clearAll {
        font-size: 14px !important;
    }
}

.clearAllDesign {
    margin-top: 27px !important;
    font-size: 16px !important;
    font-weight: 600 !important;
}

.fontWeightText {
    font-weight: 600 !important;
}

.backgroundChange {
    background: white !important;
}

.emptyDeliveryLocationArea {
    pointer-events: none
}

#mobileCountryCitySearch .modal-overlay {
    display: block !important;
}

.bold-city__name {
    display: block;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: bold;
}

.city-name-text {
    font-size: 12px;
    letter-spacing: 0px;
    color: #333333;
    opacity: 1;
    text-align: center;
}


.border-remove-from-bottom {
    border-bottom-left-radius: inherit;
    border-bottom-right-radius: inherit;
}

::placeholder {
    color: #333333;
    opacity: 1;
}

:-ms-input-placeholder {
    color: #333333;
}

::-ms-input-placeholder {
    color: #333333;
}


.listPinCode-desktop:last-child {
    border-bottom: none;
    list-style-type: none;
    padding: 11px 19px 12px 19px;
}

.not-logged-class {
    top: 883px;
    left: 893px;
    height: 54px;
    border-radius: 6px;
    opacity: 1;
    border: 0px solid #FFE3ED;
    padding: 0px;
    margin-left: 8px;
}

.text-button-set-not-logged {
    top: 896px;
    left: 940px;
    width: 312px;
    height: 28px;
    text-align: left;
    font: normal normal medium 20px/25px Poppins;
    letter-spacing: -0.2px;
    color: #333333;
    opacity: 1;
    font-weight: bold;
    font-size: 16px;
    font-style: inherit;
}

.lock-png {
    top: 896px;
    left: 910px;
    width: 18px;
    height: 24px;
    opacity: 1;
}

.lock-png {
    vertical-align: middle;
    margin-right: 10px;
    width: 18px;
    height: 21px;
}

:root {
    --negative-margin-top: -10px;
}

.js-saved-address-margin {
    margin-top: var(--negative-margin-top);
    padding-top: 13px;
    font-weight: 700;
}

.listPinCode-desktop {
    list-style-type: none;
    padding-bottom: 11px;
    padding-top: 12px;
    padding-left: 19px;
    padding-right: 19px;
    font-size: 17px;
    width:auto !important;
}

.bold-text {
    font-weight: bold;
}

.address-not-found {
    padding: 10px 7px 0px 19px;
    list-style-type: none;
}

.add-design-desktop-padding {
    padding-bottom: 4px;
    padding-top: 3px;
}

.add-border-not-found-margin {
    margin-top: -17px;
}

.default-list-item {
    padding-top: 12px;
    padding-left: 19px;
    padding-left: 19px;
    list-style-type: none;
    font-weight: bold;
}


.listPinCode-desktop {
    cursor: pointer;
}

#countryListForDesktop {
    margin-left: 108px;
    caret-color: transparent;
    border: 1px solid #333333;
    background: #FAFAFA;
    max-height: calc(100dvh - 66vh);
    padding: 0px;
    top: 227px;
    width: calc(100% - 269px);
    position: absolute;
    overflow-y: auto;
    overflow-x: hidden;
    z-index: 1005;
    scrollbar-width: thin;
}

.contryImg {
    width: 49px;
    height: 30px;
}

.main-div-listPincode:hover {
    border: 1px solid #BFDBA9;
    list-style-type: none;
    padding: 6px;
    background: #F1FFE7;
    border-radius: 5px;
}

.main-div-listPincode {
    padding: 6px;
    border: 1px solid transparent;
    word-wrap: break-word;
}

.d-space {
    padding: 6px 6px 0px 5px !important;
    margin-bottom: 10px;
    cursor: pointer;
}

.dropdown-country-list {
    display: none;
}

.show-dropdown {
    display: block;
}

.countryListPage {
    height: auto;
    padding: 20px !important;
    border: none !important;
    border-top: none !important;
    margin: 0px !important;
    background: #FAFAFA 0% 0% no-repeat padding-box;
    border-radius: none !important;
}

#wrapper-model-geo-address .modal {
    overflow-y: hidden !important;
    max-height: fit-content !important;
}

.desktop-d-know-pincode {
    font-size: 20px !important;
}

.desktop-d-see-pincode {
    width: 17px !important;
}

.listPinCode-desktop {
    position: relative;
}

.listPinCode-desktop::after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 90%;
    transform: translateX(-94%);
    width: 90%;
    border-bottom: 1px solid #ccc;
}

.span-text_d-pincode {
    font-size: 17px;
}

#deliveryInCitySearcModal .modal-overlay {
    z-index: 1002 !important;
   opacity: 0.5 !important;
}


 .text-long-truncate{
         display: inline-block;
          width: auto;
          white-space: nowrap;
          text-overflow: ellipsis;
          font-size: 14px;
          text-align: left;
          font-weight: 600;
      }
.citySearchLoc-desktop {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-right: 0px;
}
.citySearchSecondCmn__desktop {
    align-items: center;
         display: flex;
         justify-content: space-between;
}
.span-border-left{
   border-left: 2px solid #dcdcdc;
    height: 43px;
    margin-left: 20px;
}
.current_city_desktop{
    margin-left: 6px;
}
.strip-alignment-div{
    display: flex;
    justify-content: center;
    align-items: center;
    border-left: 1px solid #dcdcdc;
    margin-left: 29px;
}
 .addressList-desktop-deliveryIn.modal-close{
	width:auto !important;
  }

  #wrapper-model-geo-address > .modal-overlay{
      z-index: 1004 !important;
      opacity: 0 !important;
  }

.inputBorderInterDesktop{
    display: flex;
    line-height: 40px;
    height: 40px;
    position: relative;
    width: 100%;
    caret-color: black;
}
</style>
<div data-target="openCitySearchModal" id="deliveryLocModal" class="modal-trigger citySearchContainer citySearchCmn desktop-deliveryIn-modal__main citySearchSecondCmn__desktop hide " style="background: transparent linear-gradient(115deg, #FFE3ED 0%, #D9F0FF 100%) 0% 0% no-repeat padding-box;;box-shadow: 0px 0px 6px #00000029;margin-top:0px;" >
    <div class="citySearchCmn citySearchFirst citySearchSecondCmn__desktop ">
        <div class="citySearchCmn"  style="gap: 2px;padding-left: 12px;"> <img id="countryFlagIcon" class="hide" src="https://assets.winni.in/groot/2024/01/13/mobile/india-icon.png" alt="indian flag" style="width:36px; height:22px"/><span id="countryThreeLetterIsoCode" style="margin-left: 4px;font-weight: 600;">IND</span> </div>
    </div>
    <div class="citySearchCmn citySearchSecond citySearchSecondCmn__desktop strip-alignment-div">
        <div class="citySearchLoc">
            <span style="width: 100%;  display: inherit; align-items: inherit;justify-content: inherit;">
                <span style="display: inherit; margin-left: -4px; margin-right: 8px;">
                    <div style="flex-grow: 0; max-width: 8.333333%;flex-basis: 8.333333%;"><img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/newpin.png" style="vertical-align:sub;width:17px; height:auto;margin-left: 10px;filter: brightness(0.5);" alt="New Location"/></div>
                </span>
                <div  style="flex-grow: 0;max-width: 83.333333%; flex-basis: 83.333333%;">
                <span class="citySearchSecondCmn editLoc iconCheck current_city_desktop" data-sessionCity="" data-sessionState="" data-currentUri="http://www.winni.in/WEB-INF/jsp/error/404.jsp" style="font-size: 14px;text-align: left;font-weight: 600;"> Choose Delivery Location</span>
								</div>
                <span style="display: inherit;margin-left: 8px;margin-right: -4px;" class=""> <div  class="citySearchSecondCmn" style="flex-grow: 0;max-width: 8.333333%;flex-basis: 8.333333%;">
                        <span class="imgTopNormal hide" src="" alt="arrow Button" style="width:16px;height:auto"></span>
                        <img class="imgTopEdit hide " src="https://assets.winni.in/groot/2023/05/3/citysearchicons/newpen.png" alt="new Pen" style="margin-right:5px;width:16px;height:auto"/>
                    </div>
                </span>
            </span>
        </div>
    </div>
</div>
<div id="deliveryInCitySearcModal">
    <div class="citysearchModal modal  bottom-sheet deliveryInSearchCity desktop-deliveryIn-modal__main" id="openCitySearchModal"  style="min-height:208px;overflow-y:visible!important;border-radius: 20px;">
        <div class="modal-dialog">
            <div class="modal-header"  style="border-radius: 20px 20px 0px 0px;padding: 20px 20px 8px; float: left;width: 100%;background:#F3F7F8 0% 0% no-repeat padding-box;height:70px;">
                <div class="modal-title" style="font-size:23px;font-weight:600;text-align: center;letter-spacing: 0px; color: #333333;opacity: 1;display:flex; justify-content:center;">
                    Select Delivery Location
                </div>
                <span class="modal-close" id="closeOpenCitySearchModal" style="top: 27px;right: 24px;position: absolute;filter: brightness(0.5);" id="openCitySearchModalCloseIcon">
                    <img src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon"  style="max-width: 14px!important;" />
                </span>
            </div>
            <div class="modal-content" style="padding:27px 27px 30px !important;border-radius:20px;">
                <div class="modal-body">
                    <div style="margin-top: 17px;color: #333333;padding: 42px 0 5px 5px;font-size:18px;text-align:center;color:#333333;font-weight: 500;font-family: sans-serif;">
                        Select a delivery location to see product availability
                    </div>
                    <div class='row selectOption' style="display: flex;justify-content: center;margin: 8px 141px 25px 112px;">
                        <div class="col m5 radio-btn__div">
                            <label>
                                <input id="withIndia" class="with-gap" name="with-india" type="radio" />
                                <span style="color: #333333;font-weight: 600;font-size: 18px;padding-top: 3px;">Within India</span>
                            </label>
                        </div>
                        <div class="col m5 radio-btn__div">
                            <label>
                                <input id="outSideIndia" class="with-gap" name="outside-india" type="radio" />
                                <span  class="input-span__radio-btn__div" style="color: #333333;font-weight: 500;font-size: 18px;padding-top: 3px;">Outside India</span>
                            </label>
                        </div>
                    </div>
                    <div style="display:flex;justify-content:center;">
                        <div class='withInIndia common-cursor__pointer'  style='width: calc(100% - 215px);caret-color:transparent;border: 1px solid #D5D5D5;background: #EFEFEF; margin-bottom: 5px;border-radius: 4px;'>
                            <div class="citySearchLoc enterDeliveryLocation replace-indiaSearch-input  edit-icon"  style="width:100%;background: #EFEFEF 0% 0% no-repeat padding-box;border: 1px solid #333333;                                                                                                                                     }">
                                <span style="width: 100%;  display: inherit; align-items: inherit;justify-content: inherit;">
                                    <span style='margin-right: 14px;'>
                                        <div style="max-width: 8.333333%;flex-basis: 8.333333%;">
                                            <img src="https://assets.winni.in/groot/2023/10/23/location-black.png"  alt="location-blck__icon"  style="width:20px; height:auto;vertical-align: text-bottom;filter: contrast(0.5);" />
                                        </div>
                                    </span>
                                    <div style='max-width: 83.333333%; flex-basis: 83.333333%;'>
                                        <span class="citySearchSecondCmn onEdit fw600 current_city_desktop" style="color:#333;margin-left: -3px;text-align: left;font-size: 16px;font-family:sans-serif;">
                                            Enter  Pincode
                                       </span>
                                    </div>
                                    <span>
                                        <div class="citySearchSecondCmn edit-icon" style="max-width: 8.333333%;flex-basis: 8.333333%;">
                                            <img class="imgNormal" src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png"  alt="arrow Button" style="width:18px;height:auto;filter:brightness(0.5);" />
                                            <img class="imgEdit hide common-cursor__pointer" src="https://assets.winni.in/groot/2023/05/3/citysearchicons/editicon.png" alt="edit-icon" style="width:18px;height:auto;margin-left: 12px;" />
                                        </div>
                                    </span>
                                </span>
                            </div>
                            <div style="width: 100%;" class=" hide pincode-search__div">
                                <div class="row byPincode" style="margin:0">
                                    <div class="col s12 inputBorder enterDeliveryPincode hide-arrow" style="border: 1px solid #707070;border-radius: 4px;opacity: 1;height:52px;padding:2px;">
                                        <span style='padding:12px'>
                                            <img src="https://assets.winni.in/groot/2023/10/25/mobile/icon-material-location.png"  alt="icon-material-location" style="vertical-align:super;width:15px;font-size:30px;filter:contrast(0.5);" />
                                        </span>
                                        <input type="number" maxlength="6" class="indiaSearchPin" inputmode="numeric" value="" id="indiaSearchPin" data-input-type="pincode"  placeholder="Enter  Pincode" style="font-size: 16px;color:#000;font-weight:lighter;font-family:sans-serif;"  oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" autofocus/>
                                        <span style='position:relative;display:flex;padding:12px;display:none;'>
                                            <img class="clearCitySearch hide" src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon"  style="vertical-align:bottom;width:16px;height:16px;font-size:30px; pointer-events:auto" />
                                        </span>
                                        <span>
                                            <img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png"  alt="search-icon" style="width: 18px;margin-right: 7px; margin-top: 14px; vertical-align: center;filter:brightness(0.5);" />
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="common-cursor__pointer" style="display:flex;justify-content:center;">
                        <div class='outSideCountry hide hide-countryList__div showCountryList countrySearchInput' id="searchTheCountryListDesktop" style='width: calc(100% - 215px);caret-color:transparent;border: 1px solid #696060;background: #EFEFEF; margin-bottom: 15px;border-radius: 4px;height: 52px; padding: 5px;'>
                            <div class="citySearchLoc  replace-country-input" style="width:100%;display:flex;">
                                <span  style="width: 100%;  display: inherit; align-items: inherit;justify-content: inherit;">
                                    <span style='margin-right: 14px;'>
                                        <div style="max-width: 8.333333%;flex-basis: 8.333333%;">
                                            <img id="replaceGlobeImage" src="https://assets.winni.in/groot/2023/10/25/mobile/icon-ionic-ios-globe.png"  alt="globe"  style="width:26px; height:auto;vertical-align: text-bottom;margin-bottom: 6px;" />
                                        </div>
                                    </span>
                                    <div style='max-width: 83.333333%; flex-basis: 83.333333%;'>
                                        <span class="citySearchSecondCmn onEditCountry" style="font-weight:600;color:#333;margin-left: 8px;font-size: 18px;text-align: left;margin-bottom: 10px;">
                                         Select  Country
                                        </span>
                                    </div>
                                    <span>
                                        <div class="citySearchSecondCmn" style="max-width: 8.333333%;flex-basis: 8.333333%;margin-bottom: 11px;">
                                            <img class="imgNormalCountry" src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png"  alt="arrow Button" style="width:19px;height:auto;filter: contrast(0.5);" />
                                            <img class="imgEditCountry hide"  src="https://assets.winni.in/groot/2023/05/3/citysearchicons/editicon.png" alt="edit-icon" style="width:19px;height:auto;filter: contrast(0.5);" />
                                        </div>
                                    </span>
                                </span>
                            </div>
                             <div class="country-search-div" style="width: 100%;display:none;">
                                  <div class="inputBorderInterDesktop" style="background-color:rgb(239, 239, 239) !important">
                                        <span style='padding: 8px 0px 0px 0px;padding-left: 14px;'>
                                            <img src="https://assets.winni.in/groot/2023/10/25/mobile/icon-ionic-ios-globe.png" alt="icon-building"   style="vertical-align:text-bottom;width:26px;margin-bottom: 6px;" />
                                        </span>
                                        <input val="" type="text" maxlength="30" class="searchTheCountryClass"  id="searchTheCountryDesktop"  placeholder="Search Country" style="height: 40px;font-size: 17px;max-width:100%;border-bottom:none;padding-left:25px !important; font-weight:500;background:#EFEFEF;color:black;caret-color: black;" />
                                        <span style='position:relative;display:flex;padding:12px;display:none;'>
                                            <img class="clearCountryCitySearch hide" src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon" style="vertical-align:bottom;width:16px;height:16px;font-size:30px; pointer-events:auto" />
                                        </span>
                                        <span>
                                            <img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png" alt="search-icon"  style="vertical-align: middle;width: 19px;margin-right: 15px;filter: contrast(0.5);" />
                                        </span>
                                    </div>
                                </div>
                             </div>
                    </div>
                    <div id="countryListForDesktop" class="outSideCountry dropdown-country-list">
                        <style>
.country-container {
    display: flex !important;
    align-items: center !important;
}

.contryImg {
    margin-right: 10px !important;
}

.contryText {
    font-size: 16px !important;
    color:#333333;
}

.contryImg {
    width: 40px !important;
    height: 22px !important;
}

.contryText{
  padding: 0px 0px 0px 20px;
}
.countryListPageDI {
     padding: 0px 10px 10px 10px !important;
}
.countryBorder-desktop{
  display: inline-block;
  position: relative;
}

.countryBorder-desktop:after {
    position: absolute;
    content: '';
    border-bottom: 0.8px solid #333333;
    width: 95%;
    transform: translateX(-52%);
    bottom: -6px;
    left: 52%;
}
#noResultFoundDesktop{
    font-size: 15px;
    width: 85vw;
    margin-left: 6px;
    height: 0px;
    margin-bottom: 22px;
    margin-top: 6px;
}
</style>
<div class="row  countryListPageDI countrySpace countryShowHide allCountrySelected" style="height:auto;padding: 24px 24px;border-top: none;margin: 0px -6px 0px;background: #EFEFEF 0% 0% no-repeat padding-box;border-radius: 0px 0px 4px 4px;">
                    <div class="countryShowHide" id="selectedCountrySearch" style="width: 100%;">
                    </div>
            <div class="col s12 12 d-space countryBorder-desktop" id="usa">
                <div class="country-container"  data-countryPath="/usa"  style="padding: 6px; display: block;">
                    <img class="contryImg" data-countrythreelettername="USA" src="https://assets.winni.in/groot/2023/10/25/mobile/country/usa.jpg" alt="USA">
                    <span class="contryText">USA</span>
                </div>
            </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="canada">
                        <div class="country-container" data-countryPath="/canada"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="CAN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/canada.jpg" alt="canada"/>
                            <span class=' contryText'>Canada</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="australia">
                        <div class="country-container" data-countryPath="/australia"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="AUS" src="https://assets.winni.in/groot/2023/10/25/mobile/country/australia.jpg" alt="australia"/>
                            <span class=' contryText'>Australia</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="uae">
                        <div class="country-container" data-countryPath="/uae"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="ARE" src="https://assets.winni.in/groot/2023/10/25/mobile/country/uae.jpg" alt="uae"/>
                            <span class='contryText'>UAE</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="uk">
                        <div class="country-container" data-countryPath="/uk"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="GBR" src="https://assets.winni.in/groot/2023/10/25/mobile/country/uk.jpg" alt="uk"/>
                            <span class=' contryText'>UK</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="japan">
                        <div class="country-container" data-countryPath="/japan"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="JPN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/japan.jpg" alt="japan"/>
                            <span class=' contryText'>Japan</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="indonesia">
                        <div class="country-container" data-countryPath="/indonesia"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="IDN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/indonesia.jpg" alt="indonasia"/>
                            <span class=' contryText'>Indonesia</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="south-africa">
                        <div class="country-container" data-countryPath="/south-africa"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="ZAF" src="https://assets.winni.in/groot/2023/10/25/mobile/country/south-aftrica.jpg" alt="south-africa"/>
                            <span class=' contryText'>South-Africa</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="germany">
                        <div class="country-container" data-countryPath="/germany"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="DEU" src="https://assets.winni.in/groot/2023/10/25/mobile/country/germany.jpg" alt="germany"/>
                            <span class=' contryText'>Germany</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="singapore">
                        <div class="country-container" data-countryPath="/singapore"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="SGP" src="https://assets.winni.in/groot/2023/10/25/mobile/country/singapore.jpg" alt="singapore"/>
                            <span class=' contryText'>Singapore</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="new-zealand">
                        <div class="country-container" data-countryPath="/new-zealand"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="NZL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/new-zeland.jpg" alt="new-zeland"/>
                            <span class=' contryText'>New-Zealand</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="kuwait">
                        <div class="country-container" data-countryPath="/kuwait"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="KWT" src="https://assets.winni.in/groot/2023/10/25/mobile/country/kuwait.jpg" alt="china"/>
                            <span class=' contryText'>kuwait</span>
                      </div>
                    </div>

                    <div class="col s12 12 d-space   countryBorder-desktop"  id="philippines">
                        <div class="country-container" data-countryPath="/philippines"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="PHL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/philippines.jpg" alt="philippines"/>
                            <span class=' contryText'>Philippines</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="ireland">
                        <div class="country-container" data-countryPath="/ireland"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="IRL" class="responsive-img lazyload img-desk" alt="Ireland" src="https://assets.winni.in/groot/2023/10/25/mobile/country/ireland.jpg"/>
                            <span class=' contryText'>Ireland</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="malaysia">
                        <div class="country-container" data-countryPath="/malaysia"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="MYS" src="https://assets.winni.in/groot/2023/10/25/mobile/country/malasia.jpg" alt="malaysia"/>
                            <span class=' contryText'>Malaysia</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="nepal">
                        <div class="country-container" data-countryPath="/nepal"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="NPL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/nepal.jpg" alt="nepal"/>
                            <span class=' contryText'>Nepal</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space countryBorder-desktop"  id="saudi-arabia">
                        <div class="country-container" data-countryPath="/saudi-arabia"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="SAU" class="contryImg" src="https://assets.winni.in/groot/2023/10/25/mobile/country/saudi-arabia.jpg" alt="sauid-ariba"/>
                            <span class='contryText'>Saudi Arabia</span>
                      </div>
                    </div>
                     <div class="col s12 12 d-space   countryBorder-desktop"  id="france">
                        <div class="country-container" data-countryPath="/france/gifts"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="FRA" src="https://assets.winni.in/groot/2023/10/25/mobile/country/france.jpg" alt="france"/>
                            <span class=' contryText'>France</span>
                      </div>
                    </div>
                    <div class="col s12 12 d-space   countryBorder-desktop"  id="bahrain">
                        <div class="country-container" data-countryPath="/bahrain/gifts"  style="padding: 6px; display: block;">
                            <img class="contryImg" data-countryThreeLetterName="BHR" src="https://assets.winni.in/groot/2023/10/25/mobile/country/bahrain.jpg" alt="bahrain"/>
                            <span class=' contryText'>Bahrain</span>
                      </div>
                    </div>
                     <div class="col s12 m12 l12" id="noResultFoundDesktop" style="display:none;">
                      Sorry, we do not have this location covered
                    </div>
                </div></div>
                    <div style="display:flex;justify-content:center">
                        <div class='outSideCountryCity hide common-cursor__pointer' style='width:calc(100% - 213px);opacity:0.5;caret-color:transparent;border: none;background: #EFEFEF; margin-bottom: 20px;border-radius: 4px;height:52px;padding:3px;'>
                            <div class="citySearchLoc countryCityContainer replace-country-city-input country-city-edit-click" style="width:100%;border: 1px solid #333;border-radius: 4px;">
                                <span  style="width: 100%;  display: inherit; align-items: inherit;justify-content: inherit;">
                                    <span style='margin-right: 14px;'>
                                        <div style="max-width: 8.333333%;flex-basis: 8.333333%;">
                                            <img id="replaceBuildingImage"  src="https://assets.winni.in/groot/2023/10/25/mobile/building.png"  alt="building"  style="width:26px; height:auto;vertical-align: text-bottom;" />
                                        </div>
                                    </span>
                                    <div style='max-width: 83.333333%; flex-basis: 83.333333%;'>
                                        <span class="citySearchSecondCmn onEditCountryCity" style="margin-left: 20px;font-size: 18px;text-align: left;">
                                            Select Delivery City
                                        </span>
                                    </div>
                                    <span>
                                        <div class="citySearchSecondCmn" style="max-width: 8.333333%;flex-basis: 8.333333%;">
                                             <img class="imgNormalCountryCity"  src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png"  alt="arrow Button" style="width:19px;height:auto;filter: contrast(0.5);;" />
                                            <img class="imgEditCountryCity hide" src="https://assets.winni.in/groot/2023/05/3/citysearchicons/editicon.png" alt="editicon" style="width:19px;height:auto;filter: contrast(0.5);                                                                                         " />
                                        </div>
                                    </span>
                                </span>
                            </div>
                            <div class="hide country-city-search-div" style="width: 100%;border: 1px solid #333;border-radius:4px;">
                                <div class="inputBorderInter" style="background-color:rgb(239, 239, 239) !important">
                                    <span style='padding:12px 0px 0px 0px;;padding-left: 12px;'>
                                        <img src="https://assets.winni.in/groot/2023/10/25/mobile/building.png" alt="icon-building"   style="vertical-align:super;width:26px;font-size:30px;" />
                                    </span>
                                    <input autocomplete="off" type="text" value="" id="countryCitySearchDesktop"  placeholder="Search Delivery City" style="font-size: 17px;max-width:100%;border-bottom:none;padding-left:25px !important; font-weight:500;background:#EFEFEF;color:black;" />
                                    <span style='position:relative;display:flex;padding:12px;display:none;'>
                                        <img class="clearCountryCitySearch hide" src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon" style="vertical-align:bottom;width:16px;height:16px;font-size:30px; pointer-events:auto" />
                                    </span>
                                    <span>
                                        <img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png" alt="search-icon"  style="vertical-align: -8px;width: 18px;margin-right: 15px;filter: brightness(0.5);" />
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row withInIndia" style="margin-top: 2px;">
                        <div class="col m6 l6 common-cursor__pointer" style="display: grid; align-content: space-evenly;justify-content: center;">
                            <div class="unselected modal-trigger static-text-deliveryIn" data-target="popularCitiesModal"  style="padding:6px 10px 0;color: #039BE5;font-size:16px;text-align:left;align-items: flex-end;margin-left:44px;">
                                Don't Know Pincode?
                            </div>
                        </div>
                        <div class="col m6 l6">
                            <div class="js-detect-location__active" style="display: flex;justify-content: space-between;">
                                <div id="detectLocationText" class="static-text-deliveryIn" style="color: #039BE5;font-size:15px;margin-left: 0px;margin-left:0px;padding:7px;">
                                    <div class="wrapper-confirm-location" style="font-size: 16px;">
                                        <button class="btn-current-location adbCancelRemove" onclick="fetchCurrentLocation()" style="font-weight: 500;margin-left: 47px;font-size: 16px;color: #039BE5;border: none;box-shadow: none; border-radius: none; background: none;display: flex;align-items: center; gap: 5px;">
                                            <img src="https://assets.winni.in/groot/2024/02/12/mobile/icon-material-my-location.png"  style="width: 17px;" alt="icon-material-my-location" />
                                            Detect my location
                                        </button>
                                    </div>
                                </div>
                                <div id="model-geolocaion-notification"> </div>
                                <div id="wrapper-model-geo-address" >
                                    <span class="adbInitialRemove modal-trigger" id="btn-model-confirm-geo-address"
                                        data-target="model-confirm-geo-address"></span>
                                    <div class="modal detect-location-modal-height" id="model-confirm-geo-address" style="overflow:hidden!important;height:fit-content !important;">
                                        <span class="close-detect_location common-cursor__pointer" style="top: 27px;right: 27px;position: absolute;" aria-label="Close">
                                            <img src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon" style="width: 16px;">
                                        </span>
                                        <div class="wrapper-glocation">
                                            <svg width="64" height="64" viewBox="0 0 9 12" class=""  xmlns="http://www.w3.org/2000/svg">
                                                <path fill="#2874f0" class=""  d="M4.2 5.7c-.828 0-1.5-.672-1.5-1.5 0-.398.158-.78.44-1.06.28-.282.662-.44 1.06-.44.828 0 1.5.672 1.5 1.5 0 .398-.158.78-.44 1.06-.28.282-.662.44-1.06.44zm0-5.7C1.88 0 0 1.88 0 4.2 0 7.35 4.2 12 4.2 12s4.2-4.65 4.2-7.8C8.4 1.88 6.52 0 4.2 0z" fill-rule="evenodd"></path>
                                            </svg>
                                            <span class="span-location-found">Location found</span>
                                            <div class="location-address-1" id="address-line-1"></div>
                                            <div class="location-address-2" id="address-line-2"></div>
                                        </div>
                                        <div style="cursor:auto;padding:0 24px 24px; float: left; width: 100%;">
                                            <button
                                                class="adbCancelRemove close-detect_location model-cancel-bt model-cancel-hover">Cancel</button>
                                            <button class="model-cancel-bt model-confirm-bt bt-confirm-suggested-address-ckPin" id="bt-confirm-suggested-address-ckPin"
                                                onclick="fillSuggestedGeoAddress()">Confirm</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="separator-desktop" id="addressCountOne">
                        <hr>
                        <div class="circle_or">OR</div>
                        <hr>
                    </div>
                    <div id="user-saved-addresses" class="loggedUser" style="display: none;">
                        <div class="common-cursor__pointer" id="openSavedAdd" style='position: relative;caret-color:transparent; margin-bottom: 8px;border-radius: 4px 0px 4px 0px;'>
                               <div style="display:flex;justify-content:center">
                                               <div style='width: calc(100% - 216px);caret-color:transparent;border: 1px solid #333333;background: #EFEFEF; margin-bottom: 5px;border-radius: 4px;'>
                                                   <div class="citySearchLoc" style="width:100%"  id="indianPincodeSearchInputDesktop">
                                                       <span  style="width: 100%;  display: inherit; align-items: inherit;justify-content: inherit;">
                                                           <div style='max-width: 83.333333%; flex-basis: 83.333333%;' class="">
                                                               <span class="saved-delivery-address" style="color:#333;margin-left: -20px;font-size: 18px;text-align: left;font-weight:500;font-family: sans-serif;">
                                                                 Select from saved addresses
                                                               </span>
                                                           </div>
                                                       </span>
                                                      <span>
                                                       <div class="citySearchSecondCmn" style="max-width: 8.333333%;flex-basis: 8.333333%;margin-right: 5px;">
                                                           <img class="" src="https://assets.winni.in/groot/2023/04/26/citysearch/right-angle-arrow.png"  alt="arrow Button" style="width:16px;height:auto;filter:brightness(0.5);" />
                                                       </div>
                                                   </span>
                                                   </div>
                                               </div>
                                           </div>
                            <div class="row" style="clear: both;">
                                <div class="col s12 m12">
                                    <div class=" hide" id="addressUserSavedDesktop" style="">
                                        <div
                                            style="scrollbar-width: none;color: #333333;font-weight:500;width:calc(100% - 216px);border: 1px solid grey;position:absolute;right: 108px;margin-left: 0;top: 49px;caret-color: transparent;border: 1px solid #333333;margin-bottom: 8px;border-radius: 0px;background: #EFEFEF;">
                                            <div id="addressList-desktop-deliveryIn" style="margin-top: 1px;max-height:23vh;overflow:auto;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div id="userLogOut" class="login-prompt isAnonymous" style="margin-bottom:20px;display: flex; justify-content: start;margin-left: 109px;">
                            <div class="login-message" style="display:flex;font-size: 17px; color: #333333; ">Login to view saved addresses.
                                <a href='/customer/login' style="color:#039be5;padding: 0px 5px;font-size:16px;">Login</a>
                            </div>
                        </div>
                        <div style="display: flex;justify-content: center;width: calc(100% - 4px);margin-left: 1px;">
                            <div class='continueShopping shoppingIndia ' style="width: calc(100% - 214px) !important;height: 33px;line-height: 50px !important;font-size: 17px;border-radius: 4px;opacity: 1;height: 50px !important;">
                                Continue Shopping
                            </div>
                        </div>
                        <div style="display: flex;justify-content: center;">
                            <a class="shoppingCountry continueShopping hide" style="border-radius: 4px;width: calc(100% - 217px) !important;height: 50px !important;background: #9E9999 0% 0% no-repeat padding-box!important;line-height: 50px !important;font-size: 17px;opacity: 1!important;" href=" /">
                            <span style="color:white;"> Continue Shopping</span>
                            </a>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <input id="redirectHostURL" type="hidden" value="/;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >
 <input id="currentCitySelected" type="hidden" value="" >
<style>
    #deliveryCountry .modal-content::-webkit-scrollbar{
        background-color: transparent!important;
    }
    @media only screen and (max-width:765px){
        .modal-desktop-show {
            display: none
        }
        .modal-mobile-show{
            display: block
        }
        .countrySpace .d-space a{
            pointer-events:none!important;
        }
        .countrySpace .d-space{

            padding: 0px 0 15px!important;
            width:100%!important;
        }
        .countrySpace .d-space img {
           width: 48px;
           height: 25px;
        }
        .countrySearchInput{
            border:none!important;
        }
        .countrySelected{
            padding:0;
        }
        #countrySelected img{
                  width: 48px;
                  height: 25px;
        }
        .inputBorderInternational{
            width: 100%;
            background: #ffffff;
            border: 1px solid #cacaca;
            display: flex;
            line-height: 51px;
            height: 54px!important;
            position: relative;
            border-radius: 4px 4px 0px 0px;

        }
        #deliveryCountry{
            z-index: 999999!important;
            top:0!important;
            width:100%!important;
            height: -webkit-fill-available;
            max-height: 100% ;
        }
        .contryImg{
            display:inline-block;
            vertical-align:middle;
        }
        .contryText{
            vertical-align:middle;
            display:inline-block;
            padding-left: 12px;
           font-size: 15px;
            color:#555555;
            font-weight: 600;
        }
    }
            .countryShowHide{
            display:none;
            }
            .countryBorder{
                border-bottom: 1px solid #cacaca;
                margin-bottom: 14px;
            }
@media only screen
  and (min-width: 375px) {
    #set-left-arrow-width {
        width: 20px!important;
        font-size: 30px!important;
    }
}
@media only screen and (min-width: 320px) and (max-width: 495px) {
    .noresults {
       font-size: 20px;
       text-align: center;
       margin-top: 4px;
       color: black;
       margin-left: 2%;
    }
}
.noresult-found{
  display:block !important;
}
.tt-menu{
    overflow-y: scroll;
    max-height: 363px;
}
</style>
<div class="modal fade overide-css" id="deliveryCountry"  style="width:100%!important;min-height:100vh;background: white;" >
    <div class="modal-dialog">
        <div class="modal-content" style="padding: 0;float:left;width:100%;">
            <div class="modal-header" style="position:sticky;top:0;z-index:99999;background-color: white;width: 100%; padding:0;">
                <button type="button" class=" modal-close" aria-label="Close" style="position: absolute;left: 8px;top: 21px;border:none; background: none; cursor: pointer;">
                <span aria-hidden="true" style="font-size:30px;">
                   <img  class="closeEvent" id="set-left-arrow-width" src="https://assets.winni.in/groot/2023/10/25/mobile/icon-feather-arrow-left.png" alt="icon-feather-arrow-left" style="width: 29px;font-size: 30px;"/>
                </span>
                </button>
                <div class="selectCountryText" style="padding:0px 0px 0px 58px;font-weight:bold;color:#333333;left:0;right:0;margin:0 auto;background-color: #DA0E68;height: 80px;line-height: 77px;font-size: 20px;background: transparent linear-gradient(116deg, #FFE3ED 0%, #D9F0FF 100%) 0% 0% no-repeat padding-box;">
                    Select Country
                </div>
                <div style="width: 100%;padding: 0px 24px;margin-top: 34px;">
                    <div class="inputBorderInternational">
                        <span style='padding: 9px;padding-left: 23px;'>
                          <img  src="https://assets.winni.in/groot/2023/10/25/mobile/icon-material-location.png" alt="icon-material-location" style="vertical-align:super;width:10px;font-size:30px;"/>
                        </span>
                        <input type="text" class="countrySearchInput" id="searchTheCountryListMobile" autocomplete="off" placeholder="Search Country" style="height: 3.5rem;" >
                          <span style='padding:12px'>
                          <img  src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png" alt="search-icon" style="vertical-align: 10px;width:13px;font-size:30px;margin-right: 16px;"/>
                          </span>
                    </div>
                </div>
            </div>
            <div class="modal-body" style="padding: 0 ;width: 100%;position: relative;background: white;height: calc(100vh - 267px);overflow-y: auto;">
              <div class="row  countryListPageInternational countrySpace countryShowHide allCountrySelected" style="height:auto;padding: 24px 24px;border: 1px solid #cacaca;border-top: none;margin: 0px 24px 22px;background: #FAFAFA 0% 0% no-repeat padding-box;border-radius: 0px 0px 4px 4px;">
                    <div class="countryShowHide" id="selectedCountrySearch" style="width: 100%;">
                    <div class="row" style="margin-bottom:0px;">
                     <div class="col m12 s12 " style="padding: 0px 34px 0px 14px;border-bottom: 1px solid #cacaca;padding-left: 0px;margin-bottom: 15px;">
                    <span class="col  currentCity" id="countrySelected" style="display: block;padding: 12px 2px;padding-bottom: 14px;"> </span>
                    <span style="position:absolute;right: 16%;top: 30px;">
                      <img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/tickmark.png" alt="tickmark-icon" style="width:40px; height: 33px"/>
                    </span>
                     </div>
                   </div>
                </div>

                  <div class="col s12 12 d-space modal-close countryBorder" id="usa" >
                      <a href="/usa;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                          <img class="contryImg" data-countryThreeLetterName="USA" src="https://assets.winni.in/groot/2023/10/25/mobile/country/usa.jpg" alt="USA"/>
                          <span class='contryText'>USA</span>
                      </a>
                  </div>

                    <div class="col s12 12 d-space   modal-close countryBorder"  id="canada">
                        <a href="/canada;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="CAN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/canada.jpg" alt="canada"/>
                            <span class=' contryText'>Canada</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="australia">
                        <a href="/australia;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="AUS" src="https://assets.winni.in/groot/2023/10/25/mobile/country/australia.jpg" alt="australia"/>
                            <span class=' contryText'>Australia</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="uae">
                        <a href="/uae;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="ARE" src="https://assets.winni.in/groot/2023/10/25/mobile/country/uae.jpg" alt="uae"/>
                            <span class='contryText'>UAE</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="uk">
                        <a href="/uk;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="GBR" src="https://assets.winni.in/groot/2023/10/25/mobile/country/uk.jpg" alt="uk"/>
                            <span class=' contryText'>UK</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="japan">
                        <a href="/japan;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="JPN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/japan.jpg" alt="japan"/>
                            <span class=' contryText'>Japan</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="indonesia">
                        <a href="/indonesia;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="IDN" src="https://assets.winni.in/groot/2023/10/25/mobile/country/indonesia.jpg" alt="indonasia"/>
                            <span class=' contryText'>Indonesia</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="south-africa">
                        <a href="/south-africa;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="ZAF" src="https://assets.winni.in/groot/2023/10/25/mobile/country/south-aftrica.jpg" alt="south-africa"/>
                            <span class=' contryText'>South-Africa</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="germany">
                        <a href="/germany;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="DEU" src="https://assets.winni.in/groot/2023/10/25/mobile/country/germany.jpg" alt="germany"/>
                            <span class=' contryText'>Germany</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="singapore">
                        <a href="/singapore;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="SGP" src="https://assets.winni.in/groot/2023/10/25/mobile/country/singapore.jpg" alt="singapore"/>
                            <span class=' contryText'>Singapore</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="new-zealand">
                        <a href="/new-zealand;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="NZL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/new-zeland.jpg" alt="new-zeland"/>
                            <span class=' contryText'>New-Zealand</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="kuwait">
                        <a href="/kuwait;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="KWT" src="https://assets.winni.in/groot/2023/10/25/mobile/country/kuwait.jpg" alt="china"/>
                            <span class=' contryText'>kuwait</span>
                        </a>
                    </div>

                    <div class="col s12 12 d-space   modal-close countryBorder"  id="philippines">
                        <a href="/philippines;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="PHL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/philippines.jpg" alt="philippines"/>
                            <span class=' contryText'>Philippines</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="ireland">
                        <a href="/ireland;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="IRL" class="responsive-img lazyload img-desk" alt="Ireland" src="https://assets.winni.in/groot/2023/10/25/mobile/country/ireland.jpg"/>
                            <span class=' contryText'>Ireland</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="malaysia">
                        <a href="/malaysia;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="MYS" src="https://assets.winni.in/groot/2023/10/25/mobile/country/malasia.jpg" alt="malaysia"/>
                            <span class=' contryText'>Malaysia</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="india">
                        <a href="/;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="IND" src="https://assets.winni.in/groot/2023/10/25/mobile/country/india.jpg" alt="india"/>
                            <span class=' contryText'>India</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="nepal">
                        <a href="/nepal;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="NPL" src="https://assets.winni.in/groot/2023/10/25/mobile/country/nepal.jpg" alt="nepal"/>
                            <span class=' contryText'>Nepal</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space modal-close countryBorder"  id="saudi-arabia">
                        <a href="/saudi-arabia;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="SAU" class="contryImg" src="https://assets.winni.in/groot/2023/10/25/mobile/country/saudi-arabia.jpg" alt="sauid-ariba"/>
                            <span class='contryText'>Saudi Arabia</span>
                        </a>
                    </div>
                     <div class="col s12 12 d-space   modal-close countryBorder"  id="france">
                        <a href="/france/gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="FRA" src="https://assets.winni.in/groot/2023/10/25/mobile/country/france.jpg" alt="france"/>
                            <span class=' contryText'>France</span>
                        </a>
                    </div>
                    <div class="col s12 12 d-space   modal-close countryBorder"  id="bahrain">
                        <a href="/bahrain/gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="display: block;">
                            <img class="contryImg" data-countryThreeLetterName="BHR" src="https://assets.winni.in/groot/2023/10/25/mobile/country/bahrain.jpg" alt="bahrain"/>
                            <span class=' contryText'>Bahrain</span>
                        </a>
                    </div>
                    <div class="col s12 m12 l12 hide" id="noResultFound" style="font-size: 15px;width: 85vw;margin-left: -23px;height: 0px; margin-bottom: 0px;margin-top: -11px">
                       Sorry, we do not have this location covered
                     </div>
                </div></div>
        </div>
    </div> 
</div> <style>
          #popularCitiesModal {
              border-radius: 20px 20px 20px 20px !important;
              max-height: 100vh !important;
              width: 727px;
              overflow: auto;
              left: 50% !important;
              top: 50% !important;
              transform: translate(-50%, -50%) !important;
              right: 50%;
          }
            .city-name-font-desktop{
              font-size:18px;
            }
            .popular-city-overlay .modal-overlay{
               pointer-events:none
            }
        </style>
<div class="popular-city-overlay">

        <div class="modal fade" id="popularCitiesModal" >
            <div class="modal-dialog">
                <div class="modal-content" style="padding:0px;">
                    <div class="modal-header"  style="height:68px;padding: 22px 20px 8px; float: left;width: 100%;background:#F3F7F8 0% 0% no-repeat padding-box;border-radius: 20px 0px 0px 0px;">
                        <div class="modal-title"   style=" font-size:22px;font-weight:600;text-align: center;letter-spacing: 0px; color: #333333;opacity: 1;display:flex; justify-content:center;">
                            Select Delivery Location
                        </div>
                        <span class="modal-close popular-cities-close-btn" style="top: 27px;right: 38px;position: absolute;">
                            <img src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon"  style="max-width: 17px!important;">
                        </span>
                    </div>
                    <div class="byName hide" style="line-height: 55px;text-align:center;margin: 0px auto;margin-bottom: -6px;font-size: 18px;font-weight: 500;color:#33333;font: italic normal normal 20px/65px Poppins;">
                        Enter area or locality to get the pincode.
                    </div>
                    <div class="inputBorder byName hide" style="width: calc(100% - 320px);margin:0 auto;height:52px;border: 1px solid grey;">
                        <span style='padding:12px'>
                            <img src="https://assets.winni.in/groot/2023/10/25/mobile/icon-material-location.png" alt="icon-material-location" style="vertical-align:super;width:18px;font-size:34px;" />
                        </span>
                        <input autocomplete="off" type="text" maxlength="30"  class="indiaCityByName" value="" id="indiaCityByName" data-input-type="cityName" placeholder="Enter Delivery Area or Locality" style="font-size: 18px;color:#33333;border:1px solid #33333;font-weight:500;padding-left:0px !important;" />
                        <span style='position:relative;display:flex;padding:12px;display:none;'>
                            <img class="clearCitySearch hide" src="https://assets.winni.in/groot/2021/12/15/close.png" alt="close-icon" style="vertical-align:bottom;width:18px;height:16px;font-size:30px; pointer-events:auto" />
                        </span>
                        <span>
                            <img src="https://assets.winni.in/groot/2023/05/3/citysearchicons/searicon.png" alt="search-icon" style="margin-top:14px;width: 20px;margin-right: 15px; filter: brightness(0.5);" />
                        </span>
                    </div>
                    <div class="hide" id="popularCities" style="display:block;flex-direction:column;align-items:center;">
                        <div class="popular-cities__container" style="padding: 24px;margin-left: 16px;">
                            <div class="separator-popular-cities" style="width: 98%;">
                                <hr>
                            </div>
                            <div class='popular-cities' style='padding-bottom:1%;margin:10px auto;cursor: pointer;padding-right: 2%;'>
                                <div class="adbPoularHead" style="padding: 0% 0% 2.5%;font-size:20px;color:#333333;text-align:center;font-weight:lighter;margin-right:0px;">
                                    Popular Cities
                                </div>
                                <div class='row adbCitySelect' style="margin-bottom:12px">
                                    <div style="width: 16.6666666667% !important"  class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="delhi">
                                            <img alt="Delhi" class="responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/delhi-ncr.jpg" />
                                            <div class="truncate city-name center-align city-name-font-desktop">Delhi</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="mumbai">
                                            <img alt="mumbai" class="responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/mumbai.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Mumbai</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="chennai">
                                            <img alt="Chennai" class="responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/chennai.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Chennai</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="bangalore">
                                            <img alt="Bangalore" class="responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/bangalore.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Bangalore</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="hyderabad">
                                            <img alt="Hyderabad" class="responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/hyderabad.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Hyderabad</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="kolkata">
                                            <img alt="Kolkata" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/kolkata.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Kolkata</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row adbCitySelect" style="margin-bottom: 0">
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="chandigarh">
                                            <img alt="Chandigarh" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/chandigarh.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Chandigarh</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="ahmedabad">
                                            <img alt="Ahmedabad" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/ahmedabad.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Ahmedabad</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="jaipur">
                                            <img alt="Jaipur" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/jaipur.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Jaipur</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="pune">
                                            <img alt="Pune" class=" responsive-img"
                                                src="https://assets.winni.in/groot/2024/7/18/pune.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Pune</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="lucknow">
                                            <img alt="Patna" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/lucknow.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Lucknow</div>
                                        </div>
                                    </div>
                                    <div style="width: 16.6666666667% !important"
                                        class='col s2 center-align modal-close popular-city'>
                                        <div class="bg-city" data-city-name="nagpur">
                                            <img alt="Nagpur" class=" responsive-img "
                                                src="https://assets.winni.in/groot/2024/7/18/nagpur.jpg" />
                                            <div class=" truncate city-name center-align city-name-font-desktop">Nagpur</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  </div>
</div>
                                                           <input type="hidden" value="Delivery In" />

                                                   </li>

                                                <li class="hdr-crt-qty right" style="position: relative;margin-left: 6px;">
                                    <a href="/checkout/adv/cart;jsessionid=486A8842E4390D8EFB2D8B423AA04561" class="adbHeaderLink clearfix">
                                         <span class=" adbHeaderLink dropdown-trigger" data-hover="true" data-belowOrigin="false" data-target="dropdownCart" data-constrainWidth="false">
                                        <div class="left bg-cart" style="position: absolute;left: 0px;bottom: -22px;">
                                        </div>
                                          </span>
                                        <div class="left" style="background: #ED217C;padding: 3px 8px;border-radius: 50%;margin-left:4px;">
                                            <div style="color:white; line-height: 16px;"><span id="cart_item">0</span>
                                            </div>
                                        </div>
                                        <input type="hidden" value="Cart Item" />
                                        </a>
                                </li>
                                   <ul id="dropdownCart" class='dropdown-content profile-dropdown-cart cartLeft' style="padding: 0px 20px 8px 10px;margin-top:-30px;width:40px!important;border-radius:6px!important;min-width:70px;">
                                        <div style="margin-top: 7px;text-align: left;padding-left: 7px">
                                            <div>
                                                <div style="text-align: center;font-weight: 600;font-size: 16px;">Cart</div>
                                            </div>

                                        </div>
                                    </ul>

                             <li class="hdr-crt-qty right" style="margin-left: 20px;">
                                    <a href="/wishlist;jsessionid=486A8842E4390D8EFB2D8B423AA04561" class="adbHeaderLink clearfix">
                                        <div class="left" style="position: relative;">
                                         <span class=" adbHeaderLink dropdown-trigger" data-hover="true" data-belowOrigin="false" data-target="dropdownwishlist" data-constrainWidth="false">
                                             <img  alt="without-heart" id="setImageWithHeartDesktop" class="hoverEffectOnHeart"  src="https://assets.winni.in/groot/2024/01/usp/without-heart.png" style="margin-top: 3px;margin-right: 2px;position: absolute;right: -9px;top: 5px;" >
                                             <input value="https://assets.winni.in/groot/2024/01/usp/with-heart.png" type="hidden" id="add_wishlist" />
                                             <input value="https://assets.winni.in/groot/2024/01/usp/without-heart.png" type="hidden" id="delete_wishlist" />
                                        </span>
                                        </div>
                                        <div class="left" style="background: #ED217C;border-radius: 50%;padding: 3px 8px;">
                                            <div style="color:white; line-height: 16px;"><span id="wishlist_item">0</span>
                                            </div>
                                        </div>
                                        <input type="hidden" value="Cart Item" />
                                        </a>
                                </li>
                                  <ul id="dropdownwishlist" class='dropdown-content profile-dropdown-wishlist' style="padding: 0px 20px 8px 10px;margin-top:-30px;width:40px!important;border-radius:6px!important">
                                                                                                            <div style="margin-top: 7px;text-align: left;padding-left: 7px">

                                                                                                                <div>
                                                                                                                    <div style="text-align: left;font-weight: 600;font-size: 16px">Wishlist</div>
                                                                                                                </div>

                                                                                                            </div>
                                                                                                        </ul>



                                 <li class="right">
                                                                    <span>
                                                                        <span class="adbHeaderLink dropdown-trigger" data-hover="true" data-belowOrigin="false" data-target="dropdownprofile" data-constrainWidth="false">
                                                                            <div class="left profileImageHeader">
                                                                                <img alt="user-icon-grey" class="profileImage" src="https://assets.winni.in/groot/2023/11/20/user-icon-grey.png" style="margin-top: 10px;width: 23px;"   onmouseover="hoverImage(this)" onmouseout="unhoverImage(this)">
                                                                            </div>
                                                                            <input type="hidden" value="My Profile" />
                                                                        </span>
                                                                        <ul id="dropdownprofile" class='dropdown-content profile-dropdown profileLeft' style="padding: 0px 20px 8px 10px;margin-top:-30px;border-radius:5px!important;">
                                                                            <div style="margin-top: 10px;text-align: left;border-bottom: 1px solid #f0f0f0;padding-bottom: 10px;padding-left: 7px">
                                                                                <div class="loggedUser" style="display: none;">
                                                                                    <div style="text-align: left;font-weight: 600;font-size: 14px"><span style="font-weight: 400;word-break:break-word;">Hello,</span> <span id="userName"> </span></div>
                                                                                    <div style="text-align: left;font-size: 15px" id="userEmailId"></div>
                                                                                    <input type="hidden" value="Logged-in" id="loggedin"/>
                                                                                </div>
                                                                                <div class="isAnonymous">
                                                                                    <div style="text-align: left;font-weight: 600;font-size: 25px">Welcome</div>
                                                                                    <div style="color: #3E4152;font-size:14px;">To access account and manage orders</div>
                                                                                    <input type="hidden" value="Guest" id="guest"/>
                                                                                    <a id="loginPageRedirect" class="adbHeaderLink pr-0" href="/customer/login;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="padding-left: 0;margin-top: 5px">
                                                                                        <button style="background: #ffffff;border: 1px solid #d4d0d0;color: #ED217C;padding: 2px 10px;font-size: 14px">Signup/Login</button>
                                                                                    </a>
                                                                                </div>

                                                                            </div>
                                                                            <div style="padding-top: 5px;">
                                                                                <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px;"><a class="adbHeaderLink" href="/my-winni/user-mywinni-info;jsessionid=486A8842E4390D8EFB2D8B423AA04561">My Winni</a></div>
                                                                                <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px"><a class="adbHeaderLink" href="/my-winni/orders/list;jsessionid=486A8842E4390D8EFB2D8B423AA04561">My Orders</a></div>
                                                                                <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px"><a class="adbHeaderLink" href="/my-winni/saved-address;jsessionid=486A8842E4390D8EFB2D8B423AA04561">My Address Book</a></div>
                                                                                <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px"><a class="adbHeaderLink" href="/my-winni/wallet;jsessionid=486A8842E4390D8EFB2D8B423AA04561">My Wallet</a></div>
                                                                                <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px"><a class="adbHeaderLink" href="/my-winni/reminder/list;jsessionid=486A8842E4390D8EFB2D8B423AA04561">My Reminder</a></div>
                                                                            </div>
                                                                            <div class="loggedUser">
                                                                                <div style="padding-top: 5px;border-top: 1px solid #f0f0f0;">
                                                                                    <div class="profile-dropdown-content" style="color: #3E4152;margin-bottom: 5px">
                                                                                        <a class="adbLogout pr-0" id="logoutFromProfile" href="javascript:;" data-uri="/customer/logout;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Logout</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                        </ul>
                                                                    </span>
                                                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

             <div class="row" style="margin:0 auto!important; background: #F7F7F7 0% 0% no-repeat padding-box!important;">
                         <div class="col m12" style="margin:0 auto!important;">
                             <style>
    nav .multi-column-menu  .menu-column-title:before{
        content: "";
        position: absolute;
        width: 99%;
        height: 1px;
        bottom: 0;
        left: 1%;

    }
    nav #dropdownfth{
        left: 0!important;
    }
    nav #dropdownann{
        left: 241px!important;
    }
    nav #dropdownfsd{
        left: 0!important;
    }
    nav #dropdownflw{
        left: 0!important;
    }
     nav #dropdownflwRakhi{
            left: 0!important;
        }
    nav #dropdownbdy{
        left:95px !important;
    }
    nav .menu-column-title{
        position:relative;
        padding-top:0;
        line-height:28px;
        margin-bottom:12px!important;
        margin-top:14px!important;
        padding-bottom:0;
        font-weight:700;
        color: #000000!important;
        text-transform: capitalize;
        font-size:13px;
    }
    nav .menu-column-title-inter{
        padding-left:11px;
        padding-top:4px;
        font-weight:700;
        color: #000000!important;
        text-transform:uppercase;
    }
    nav .multi-column-menu ul{
        max-height:370px!important;
        overflow-y:auto;
        display:block;
    }
    nav .dropdown-content{
        overflow:hidden!important
    }
    nav .dropdown-content.col.s2{
        margin-top:-13px;
        display:grid;
        min-height:370px!important
    }
    nav .dropdown-content ::-webkit-scrollbar{
        width: 5px;
        background-color: rgba(0,0,0,.09);
        border-radius: 100px;
    }
    nav .dropdown-content ::-webkit-scrollbar-thumb {
        padding:0 5px 0;
        background:rgb(158 158 158 / 35%);
        border-radius: 100px;
        width:5px!important;
    }
    nav .multi-column-menu .col.s2:nth-child(2n) , nav .multi-column-menu .col.s3:nth-child(2n) , nav .multi-column-menu .col.s4:nth-child(2n) , nav .multi-column-menu .col.s6:nth-child(2n) {
        background-color: #f5f5f5;
        background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
    }
    nav .multi-column-menu .col.s2 , nav .multi-column-menu .col.s3 , nav .multi-column-menu .col.s4 , nav .multi-column-menu .col.s6 {
        padding:0 10px 10px!important
    }
    .international-dropdwn .col.s2 {
        padding:0 0 10px!important
    }
    nav .multi-column-menu{
        display:flex;
        padding:1px 0 0!important;
        height:auto!important;
    }
    .itemsAlignment{
        margin-left:0px!important;
        width:20%!important;
    }
    .boldGiftLink{
        font-weight:600;
        font-size: 14px!important;
    }
    .showAllItem{
    overflow: visible!important;
    }
   .moving-border::before{
        content: "";
            display: block;
            border-top: 2px solid #b0b6b9;
            Width: 140px;
            top: -15px;
            left: 16px;
            opacity: 0.4;
            position: absolute;
            padding-top:10px;
  }
  .moving-border-cake-combo::before{
               content: "";
              display: block;
              border-top: 2px solid #b0b6b9;
              Width: 140px;
              top: -8px;
              left: 16px;
              opacity: 0.4;
              position: absolute;
              padding-top:10px;
  }
  @media screen and (min-width: 1200px) and (max-width: 1366px) {
    #dropdownfsd {
      margin-bottom: 0px!important;
      padding-bottom: 0px!important;
    }
      .FontItem{
      font-size:15px!important;
      }
        #showAllItem li {
            margin-bottom: -10px!important;
            padding-bottom:-10px!important;
             margin-top: -10px!important;
             padding-top:-10px!important;

            }

  }
    .FontItem{
      font-size:13px!important;
      }
      #showAllItem li {
          margin-bottom: 0px!important;
          padding-bottom:0px!important;
           margin-top: 0px!important;
           padding-top:0px!important;

          }
          .ListPositionRelative{
          position:relative!important;
          }
          .yellowStrip{
          position:absolute;
          top:12px;
          width:3px!important;
          height:11px!important;
          line-height:10px!important
          }
          nav #dropPersonalised{
              left:0!important;
          }
          nav #dropdownchocolate{
                left:0!important;
            }
            nav #dropdownDiwali{
                left:0!important;
            }
              nav #dropdown1{
                    left:0!important;
                }
                nav #dropdownann{
                 left:5%!important;
                }
                nav #dropdownbdy{
                 left:0!important;
                }
                 nav #dropdownann{
                  left:0!important;
                }
                nav #OccasionsDropdownann{
                 left:0!important;
                }
                .borderBottomForCategories:hover{
                    background-color: inherit;
                    color: #ED217C;
                    border-bottom:2px solid #ED217C!important;
                }
                .header-secondary {
                    background: #F7F7F7;
                }
                .header-secondary .nav-wrapper ul li a {
                    border-bottom: 2px solid transparent;
                    padding-left: 16px;
                    padding-right: 5px;
                }
                .design-same-day-delivery{
                    width:100%;
                    padding-bottom:5px;
                    height:250px;
                    border-bottom-left-radius: 8px;
                    border-bottom-right-radius: 8px;
                    border-top-left-radius: 5px;
                    border-top-right-radius: 5px;
                }
 nav #OccasionsDropdownann{
                 left:0!important;
                }
                .showAllItem {
                    padding-left: 10px;
                    padding-top: 0px;
                    margin-top: -5px !important;
                  }

                  .showAllItem li {
                    white-space: nowrap;
                  }
                   .international-text-rakhi{
                                      padding-left: 10px;
                                      padding-top: 0px;
                                      margin-top: -5px !important;
                                    }

                                  .international-text-rakhi{
                                      white-space: nowrap;
                                    }
                                    .rounded-6{
                                        border-radius:6px;
                                    }
                                    .height-200{
                                        height:200px !important;
                                    }
                                    .position-relative{
                                      position:relative!important;
                                    }
                                    .flower-box__title{
                                       padding-top:10px;
                                       cursor:auto !important;
                                       position:relative;
                                       padding-left: 13px!important;;
                                       padding-bottom:0px;
                                    }
                                     nav #dropdownFathersDay{
                                        left:0!important;
                                    }
</style>
<nav class="header-secondary hide-on-med-and-down" style="background: #F7F7F7 0% 0% no-repeat padding-box!important;max-width:1600px!important;margin:0 auto!important">
        <div class="nav-wrapper" style="max-width:1600px!important;margin:0auto!important">
            <div style="display:inline-block; display: none; padding-top:8px; margin-left:12px;" class="scroll-logo">
                <a href="/;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                <img alt="not-load-icon"  src="https://assets.winni.in/groot/2023/03/13/desktop/header-default/hearts-six-thousand-into-two-fifty-six-svgtopng.png" height="30">
            </a>
        </div>
                  <ul class="hide-on-med-and-down">
                  <li>
                      <a class="dropdown-trigger" data-hover="true" data-belowOrigin="true" data-target="dropdownsameday" data-constrainWidth="false">
                          <span style="font-weight: 700; font-size: 14px; color: #C91E39!important; font-weight: bold; text-transform: uppercase;">Express</span>
                      </a>
                           <ul id='dropdownsameday' class='dropdown-content multi-column-drop-menu'  style="height:365px!important;min-width:200px !important; background-repeat: no-repeat;background-attachment: relative;background-position: right bottom;">
                              <div class="row m-0">
                                  <ul>
                                      <li><a style="font-weight: 700; font-size: 13px; color:#333 !important; font-weight: bold;" href="/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Same Day Delivery </a></li>
                                      <li ><a style="background-color: #f5f5f5;background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);" href="/cake/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes </a></li>
                                      <li><a href="/flowers/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flowers </a></li>
                                      <li><a style="background-color: #f5f5f5;background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);" href="/plants/same-day-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Plants </a></li>
                                      <li><a href="/combos/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Combos </a></li>
                                      <li><a style="background-color: #f5f5f5;background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);" href="/gifts/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Gifts Same Day </a></li>
                                  </ul>
                              </div>
                           </ul>
                    </li>
            <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdownfsd" data-constrainWidth="false" >
                    CAKES
                </a>
                <ul id='dropdownfsd' class='dropdown-content multi-column-drop-menu'  style="margin-bottom:0px;padding-bottom:0px;height:300px!important;min-width:1300px!important; background-repeat: no-repeat;background-attachment: relative;background-position: right bottom;">
                    <div class="row m-0 multi-column-menu">
                        <div class="col s2 margin-bottom-for-cake" style="width:27%;margin-left:8px;">
                            <div class="menu-column-title columnTopTitle" style="font-weight:700;padding-left:13px;font-size:13px;">Cakes By Type</div>
                            <ul class="showAllItem" style="padding-left:15px;padding-top:0px;margin-top:-10px!important">
                                  <li class="ListPositionRelative">
                                      <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottom" href="/eggless-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Eggless Cakes</a>
                                 </li>
                                  <li><a class="FontItem marginPaddingBottomForOtherCategory"  href="/midnight-cake-delivery-in-india;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Midnight Cakes</a></li>
                                    <li class="ListPositionRelative">  <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/photo-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Photo Cakes</a></li>
                                    <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/heart-shape-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Heart Shape Cakes </a></li>
                                    <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/designer-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Designer Cakes </a></li>
                                      <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/fondant-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Fondant Cakes</a></li>
                                      <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/dry-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Dry Cakes</a></li>
                                       <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/cup-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">CupCakes</a></li>
                                      <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/pastry;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Pastry</a></li>
                                      <li><a style="padding-top:0px;margin-bottom:-80px!important;padding-bottom:-80" class="FontItem marginPaddingBottomForOtherCategory" href="/cake/jar-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Jar Cakes</a></li>
                            </ul>
                        </div>
                        <div class="col s2 margin-bottom-for-cake" style="width:25%;background:white;margin-bottom:-60px;padding-bottom:-60px;">
                            <div class="menu-column-title" style="font-weight:700;font-size:13px;">Cakes By Flavour</div>
                            <ul class="showAllItem" style="padding-top:0px;margin-top:0px;margin-top:-10px!important">

                                <li class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/chocolate-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate Cakes</a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/truffle-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Truffle Cakes </a></li>
                                 <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/black-forest-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Black Forest Cakes </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/rasmalai-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Rasmalai Cakes</a></li>
                                <li  class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/butterscotch-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Butterscotch Cakes</a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/red-velvet-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Red Velvet Cakes </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/vanilla-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Vanilla Cakes</a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/pineapple-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Pineapple Cakes </a></li>
                                  <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/fruit-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Fruit Cakes</a></li>
                                  <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/coffee-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Coffee Cakes  </a></li>
                                  <li style="margin-bottom:-80px;padding-bottom:-80px;"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/kitkat-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Kitkat Cakes</a></li>
                            </ul>
                        </div>
                        <div class="col s2 margin-bottom-for-cake" style="width:25%;background:white;">
                            <div class="menu-column-title" style="font-weight:700;font-size:13px;"> Cakes By Theme</div>
                            <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                              <li class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/kids-cake-shop;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Kids Cakes</a></li>
                              <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/unicorn-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Unicorn Cakes</a></li>
                               <li class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/half-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Half Cakes</a></li>
                              <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/barbie-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Barbie Doll Cakes </a></li>
                               <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/multi-tier;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Tier Cakes</a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/cartoon-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cartoon Cakes</a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/spiderman-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Spiderman Cakes</a></li>
                            </ul>
                        </div>
                        <div class="col s2 margin-bottom-for-cake" style="width:35%;background:white;">
                            <div class="menu-column-title" style="font-size:13px;">Cake By Occasion</div>
                            <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/birthday-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Cakes  </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/anniversary-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Cakes  </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/1st-birthday-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">First Birthday Cakes </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/anniversary-cakes/1st;jsessionid=486A8842E4390D8EFB2D8B423AA04561">First Anniversary Cakes  </a></li>
                                <li style="margin-bottom:30px;"><a class="FontItem marginPaddingBottomForOtherCategory" href="/anniversary-cakes/25th;jsessionid=486A8842E4390D8EFB2D8B423AA04561">25th Anniversary Cakes  </a></li>
                               <li class="moving-border-cake-combo FontItem marginPaddingBottomForOtherCategory fs13 fw600 flower-box__title">Cake Combos</li>
                             <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/combos/cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cake Combos </a></li>
                              <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cakes-and-flowers-delivery-in-india;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes And Flowers </a></li>
                              <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/combos/cakes-and-chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes and Chocolates</a></li>
                              <li ><a class="FontItem marginPaddingBottomForOtherCategory" href="/combos/cakes-and-teddies;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes and Teddies </a></li>
                            </ul>
                        </div>
                        <div class="col s2 margin-bottom-for-cake" style="width:35%;background: #FCFCFC 0% 0% no-repeat padding-box;border: 1px solid #CECECE;border-right:none;border-top:none;opacity: 1;">
                            <div class="menu-column-title" style="color:#FF4E89!important;font-size:13px;margin-left:13px;">Top Trending Links</div>
                            <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important;margin-left:13px;">
                                <li class="ListPositionRelative"> <img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/pinata-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Pinata Cakes </a></li>
                                <li><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/pull-me-up-cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Pull Me Up Cakes</a></li>
                                <li style="margin-bottom:74px;"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/bento-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Bento Cake</a></li>
                                  <li class="moving-border" style="position:relative;">
                                 <a class="FontItem marginPaddingBottomForOtherCategory" href="/cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="font-weight: 600; font-size: 14px!important;">All Cakes</a></li>
                                <li style="font-weight: 600; font-size: 14px;"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cake/best-sellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Best Seller Cakes</a></li>
                            </ul>
                        </div>
                        <div class="col m4 s4" style="width:40%;background: #FCFCFC 0% 0% no-repeat padding-box;margin-bottom:-60px;padding-bottom:-60px;">
                            <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;"><a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/cake/new-arrivals;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/08/desktop/cakes/new-arrivals.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                </a></li>
                                <li style="margin-bottom:-10px;padding-bottom:-10px;margin-top:-6px;border-radius:6px!important;"><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/cake/premium-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/08/desktop/cakes/premium-cakes.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                            </ul>
                        </div>
                    </div>
                </ul>
            </li>
            <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdownflw" data-constrainWidth="true">
                    FLOWERS
                </a>
                <ul id='dropdownflw' class='dropdown-content multi-column-drop-menu' style='margin-bottom:0px;padding-bottom:0px;min-width:1270px !important;height:300px!important' >
                    <div class="row m-0 multi-column-menu" >
                        <div class="col s2" style="width:23%;margin-left:8px;">
                            <div class="menu-column-title columnTopTitle" style="font-weight:700;padding-left:12px;font-size:13px;">By Type</div>
                            <ul class="showAllItem" style="padding-left:12px;padding-top:0px;margin-top:-10px!important">
                                  <li>
                                      <a class="FontItem" href="/flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Flowers & Bouquets</a>
                                   </li>
                                  <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/roses;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Roses</a></li>
                                  <li><a class="FontItem" href="/flowers/orchids;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Orchids </a></li>
                                  <li><a class="FontItem" href="/flowers/lilies;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Lilies </a></li>
                                  <li><a class="FontItem" href="/flowers/gerberas;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Gerberas </a></li>
                                  <li><a class="FontItem" href="/flowers/carnations;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Carnations </a></li>
                                  <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/mixed;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Assorted Flowers</a></li>
                            </ul>
                        </div>
                        <div class="col s2" style="width:20%;background:white!important;" >
                            <div class="menu-column-title columnTopTitle" style="font-weight:700;padding-left:13px;font-size:13px;">By Occasion</div>
                            <ul class="showAllItem" style="padding-left:15px;padding-top:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/birthday-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/anniversary-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary</a></li>
                                <li><a class="FontItem" class="FontItem" href="/flowers/i-am-sorry;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >I am Sorry </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/love-and-affection;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Love & Affection </a></li>
                                <li><a class="FontItem" href="/flowers/wedding;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Wedding </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/congratulations;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Congratulation</a></li>
                                <li><a class="FontItem" href="/flowers/thank-you;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Thank You </a></li>
                                <li><a class="FontItem" href="/flowers/sympathy-n-funeral;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Sympathy </a></li>
                            </ul>
                        </div>
                        <div class="col s2" style="width:20%">
                            <div class="menu-column-title columnTopTitle" style="font-weight:700;font-size:13px;">By Color</div>
                            <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/red;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Red Flowers</a></li>
                                <li><a class="FontItem" href="/flowers/pink;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Pink Flowers </a></li>
                                <li><a class="FontItem" href="/flowers/yellow;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Yellow Flowers </a></li>
                                 <li><a class="FontItem" href="/flowers/white;jsessionid=486A8842E4390D8EFB2D8B423AA04561">White Flowers </a></li>
                                <li><a class="FontItem" href="/flowers/purple;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Purple Flowers </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/mixed;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Mixed Flowers </a></li>
                            </ul>
                        </div>
                        <div class="col s2" style="width:24%;background:white!important;">
                            <div class="menu-column-title columnTopTitle" style="font-weight:700;padding-left:13px;font-size:13px;">Flower By Collection </div>
                            <ul class="showAllItem" style="padding-left:15px;padding-top:0px;margin-top:-10px!important">
                              <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/premium;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Premium Flowers </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/flowers/basket;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Basket Arrangements </a></li>
                                <li><a class="FontItem" href="/flowers/exotic;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Exotic Flowers </a></li>
                                <li><a class="FontItem" style="margin-bottom:30px;" href="/flowers/box;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flower Boxes </a></li>
                                 <li class="moving-border-cake-combo fw600 fs13 flower-box__title marginPaddingBottomForOtherCategory ">Flower Combos</li>
                                  <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/cakes-and-flowers-delivery-in-india;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Flowers And Cake</a></li>
                                 <li><a class="FontItem" href="/combos/flowers-and-chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flowers and Chocolates </a></li>
                                  <li><a class="FontItem" href="/combos/flowers-and-teddies;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Flowers and Teddies </a></li>
                                   <li><a class="FontItem" href="/combos/flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flower Combos</a></li>
                            </ul>
                        </div>
                        <div class="col s2" style="background: #FCFCFC 0% 0% no-repeat padding-box;border: 1px solid #CECECE;border-right:none;border-top:none;opacity: 1;width:25%;">
                           <div class="menu-column-title columnTopTitle" style="font-weight:700;padding-left:13px;font-size:13px;color:#FF4E89!important;">Top Trending Links</div>
                            <ul class="showAllItem" style="padding-left:15px;padding-top:0px;margin-top:-10px!important">
                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/roses;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Roses</a></li>
                            <li><a class="FontItem" href="/birthday-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Birthday Flowers</a></li>
                            <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem" href="/anniversary-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Flowers</a></li>
                             <li><a class="FontItem" href="/combos/flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flower Combos </a></li>
                               <li><a class="FontItem" href="/flowers/mixed;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Mixed Flowers </a></li>
                            </ul>
                        </div>
                        <div class="col m4 s4" style="width:30%;background: #FCFCFC 0% 0% no-repeat padding-box;">
                           <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                               <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;"><a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/flowers/best-sellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                               <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/16/desktop/best-seller-flowers.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                               </a></li>
                               <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important;"><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/flowers/premium;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/16/desktop/premium-flowers-image.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                           </ul>
                       </div>
                    </div>
                </ul>
            </li>
                       <li>
                           <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropplants" data-constrainWidth="false">
                               PLANTS
                           </a>
                                       <ul id='dropplants' class='dropdown-content multi-column-drop-menu' style="min-width:1130px!important">
                                           <div class="row m-0 multi-column-menu" style="margin-left:10px!important;">
                                               <div class="col s3" style="background-color:white!important;width:28%">
                                                   <div style="padding-left:15px;" class="menu-column-title">By Type</div>
                                                   <ul class="showAllItem" style="padding-left:15px;padding-top:0px;margin-top:-10px!important">
                                                       <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/plants;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Plants</a></li>
                                                       <li><a href="/plants/indoor;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Indoor Plants</a></li>
                                                        <li><a href="/plants/outdoor;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Outdoor Plants</a></li>
                                                        <li><a href="/plants/personalised;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalised Plants</a></li>
                                                         <li><a href="/plants/premium;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Premium Plants</a></li>
                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/plants/low-maintenance;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Low Maintenance Plants</a></li>
                                                         <li><a href="/plants/air-purifier;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Air Purifier Plants</a></li>
                                                         <li><a href="/plants/flowering;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flowering Plants</a></li>
                                                          <li><a href="/plants/Succulent;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Succulent Plants</a></li>
                                                           <li><a href="/plants/new-arrivals;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Arrivals</a></li>
                                                   </ul>
                                               </div>
                                               <div class="col s3" style="background:white!important;width:19%">
                                                   <div class="menu-column-title">By Name</div>
                                                   <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                       <li><a href="/plants/bamboo;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Lucky Bamboo</a></li>
                                                       <li><a href="/plants/money;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Money Plants</a></li>
                                                       <li><a href="/plants/jade;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Jade Plants</a></li>
                                                        <li><a href="/plants/syngonium;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Syngonium</a></li>
                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/plants/Bonsai;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Bonsai Plants</a></li>
                                                       <li><a href="/plants/rose;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Rose Plants</a></li>
                                                       <li><a href="/plants/cactus;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cactus Plants</a></li>
                                                       <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/plants/set;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Plant Set</a></li>
                                                   </ul>
                                               </div>
                                               <div class="col s3" style="background:white!important;width:22%">
                                                   <div class="menu-column-title">By Occasions</div>
                                                   <ul class="showAllItem" style="background-color:white!important;margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                       <li><a href="/plants/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday</a></li>
                                                       <li><a href="/plants/anniversary;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary</a></li>
                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/plants/good-luck;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Good Luck</a></li>
                                                       <li><a href="/plants/house-warming;jsessionid=486A8842E4390D8EFB2D8B423AA04561">House Warming</a></li>

                                                   </ul>
                                               </div>
                                               <div class="col s3" style="background:white!important;width:22%">
                                                   <div class="menu-column-title">By Planters</div>
                                                   <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                     <li><a href="/planters/ceramic;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Ceramic Planters</a></li>
                                                       <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/planters/metal;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Metal Planters</a></li>
                                                       <li><a href="/planters/glass;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Glass Planters</a></li>
                                                       <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/planters/self-watering;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Self Watering Planters</a></li>
                                                   </ul>
                                               </div>
                                                <div class="col s3" style="width:30%;background: #FCFCFC 0% 0% no-repeat padding-box;">
                                                   <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                                       <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;"><a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/plants/same-day-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                                       <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/16/desktop/same-day-plants.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                                       </a></li>
                                                       <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/best-selling-plants;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon" src="https://assets.winni.in/groot/2023/11/16/desktop/best-seller-plants.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                                                   </ul>
                                              </div>
                                           </div>
                                       </ul>
                                   </li>
             <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropgifts" data-constrainWidth="false">
                    GIFTS
                </a>
                <ul id='dropgifts' class='dropdown-content  multi-column-drop-menu' style="background-image: url('https://assets.winni.in/groot/2023/03/13/desktop/header-default/gift-img.jpg');background-repeat: no-repeat;background-position: right bottom; min-width:1180px !important">
                    <div class="row m-0 multi-column-menu">
                         <div class="col s2" style="background:white!important;margin-left:22px!important;">
                            <div class="menu-column-title" >Gifts</div>
                            <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/best-selling-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Best Seller Gifts</a></li>
                                   <li><a href="/gifts/home-decor;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Home Decor</a></li>
                                  <li><a href="/gifts/jewellery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Jewellery</a></li>
                                  <li><a href="/gifts/perfumes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Perfumes & Fragrances</a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/gifts/baskets;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Gift Basket</a></li>
                                <li><a href="/gifts/soft-toys;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Soft toys </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/gifts/handbags;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Handbags & Wallets </a></li>
                                <li><a href="/gifts/idols-and-figurines;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Idols and Figurines </a></li>
                                 <li><a href="/gifts/candles-and-Diffusers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Diffuser & candles</a></li>
                               <li><a href="/gifts/greeting-cards;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Greeting Cards</a></li>
                            </ul>
                        </div>

                       <div class="col s2 showAllItem" style="background:white!important;">
                          <div class="menu-column-title">Featured Gifts </div>
                          <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                              <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Arrival</a></li>
                              <li><a href="/gifts/gift-hampers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Gifts Hampers</a></li>
                              <li><a href="/sweets;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Sweets</a></li>
                              <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/dry-fruits;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Dryfruits</a></li>
                              <li><a href="/chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolates</a></li>
                          </ul>
                      </div>

                        <div class="col s2 showAllItem" style="background:white!important;">
                            <div class="menu-column-title">By Recipient </div>

                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                               <li><a href="/gifts/for-her;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Her</a></li>
                                <li><a href="/gifts/for-him;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Him</a></li>
                                <li><a href="/gifts/for-husband;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Husband</a></li>
                                <li><a href="/gifts/for-wife;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Wife</a></li>
                                <li><a href="/gifts/for-kids;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Kids</a></li>
                                 <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"> <a href="/romantic-couple-gifts/ct/150;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Couples</a></li>
                            </ul>
                        </div>
                        <div class="col s2" style="background:white!important;">
                            <div class="menu-column-title">By Occasions </div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li><a href="/birthday-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Gifts</a></li>
                                <li><a href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary</a></li>
                                <li><a href="/gifts/wedding;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Wedding gifts </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/love-romance/ct/171;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Love & Romance</a></li>
                            </ul>
                        </div>
                        <div class="col s3" style="width:22%;background:white!important;">
                            <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;">
                                <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/16/desktop/gifts/all-gifts.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                </a>
                                </li>
                                <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/gifts/gift-hampers;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/16/desktop/gifts/gift-hampers.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                            </ul>
                       </div>
                    </div>
                </ul>
            </li>
            <li>
                        <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropPersonalised" data-constrainWidth="false">
                            PERSONALIZED GIFTS
                        </a>
                            <ul id='dropPersonalised' class='dropdown-content  multi-column-drop-menu' style="background-image: url('https://assets.winni.in/groot/2023/03/13/desktop/header-default/gift-img.jpg');background-repeat: no-repeat;background-position: right bottom; min-width:1080px !important">
                                <div class="row m-0 multi-column-menu">

                                    <div class="col s2" style="width:20%;margin:0;background:white!important;margin-left:22px!important;">
                                        <div class="menu-column-title">Personalized Gifts </div>
                                        <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                            <li><a href="/personalised-gifts/mugs;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Mugs</a></li>
                                            <li><a href="/personalised-gifts/cushions;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cushions</a></li>
                                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/personalised-gifts/water-bottles;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Water Bottles</a></li>
                                            <li><a href="/personalised-gifts/key-chains;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Key chains</a></li>
                                            <li><a href="/personalised-clocks;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Clocks</a></li>
                                            <li><a href="/personalised-gifts/chocolate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolates</a></li>
                                              <li><a href="/gifts/engraved-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Engraved Gifts </a></li>
                                               <li><a href="/personalised-tshirts;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> T-Shirts</a></li>
                                            <li><a href="/personalised-gifts/stationery;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Stationery Gifts</a></li>
                                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/personalised-gifts/accessories;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalised Accessories</a></li>
                                        </ul>
                                    </div>
                                     <div class="col s2" style="width:20%;background:white!important;">
                                            <div class="menu-column-title">Special Gifts </div>
                                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                <li><a href="/personalised-gifts/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Arrival</a></li>
                                                <li><a href="/personalised-gifts/photo-frames;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Photo Frames</a></li>
                                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/gifts/led-frames;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Led Frames</a></li>
                                                <li><a href="/personalised-gifts/photo-to-art;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Photo to Art</a></li>
                                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/personalised-gifts/caricatures;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Caricatures</a></li>
                                                <li><a href="/personalised-gifts/combo;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalized Combos </a></li>
                                                <li><a href="/gifts/glassware;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Glassware </a></li>
                                            </ul>
                                        </div>
                                    <div class="col s2" style="width:20%;background:white!important;">
                                        <div class="menu-column-title">By Recipient </div>
                                        <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                           <li><a href="/personalised-gifts/for-her;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Her</a></li>
                                            <li><a href="/personalised-gifts/for-him;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Him</a></li>
                                            <li><a href="/personalised-gifts/for-husband;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Husband</a></li>
                                            <li><a href="/personalised-gifts/for-wife;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> For Wife</a></li>
                                           <li><a href="/personalised-gifts/for-kids;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Kids</a></li>
                                            <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/personalised-gifts/for-couples;jsessionid=486A8842E4390D8EFB2D8B423AA04561">For Couples</a></li>
                                        </ul>
                                    </div>
                                    <div class="col s2" style="width:20%;background:white!important;">
                                        <div class="menu-column-title">By Occasions</div>
                                        <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                            <li><a href="/birthday-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Gifts</a></li>
                                            <li><a href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary</a></li>
                                            <li><a href="/gifts/wedding;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Wedding gifts </a></li>
                                            <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/love-romance/ct/171;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Love & Romance</a></li>
                                        </ul>
                                    </div>
                                    <div class="col s3" style="width:26%;background:white!important;">
                                       <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                           <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;">
                                           <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/personalised-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                           <img class="showList" alt="not-load-icon"   src="https://assets.winni.in/groot/2023/11/20/personalized/all-personalised.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                           </a>
                                           </li>
                                           <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/personalised-gifts/bestsellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/20/personalized/best-sellers.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                                       </ul>
                                  </div>
                                </div>
                            </ul>
                        </li>
                   <li>
                     <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdownchocolate" data-constrainWidth="false">
                         CHOCOLATES
                     </a>
                     <ul id='dropdownchocolate' class='dropdown-content multi-column-drop-menu' style='min-width:1130px !important'>
                          <div class="row m-0 multi-column-menu">

                                                             <div class="col s2" style="width:20%;margin:0;background:white!important;margin-left:26px!important;">
                                                                 <div class="menu-column-title">By Type </div>
                                                                 <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                                      <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Chocolates</a></li>
                                                                      <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/bestsellers-chocolate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Best Seller Chocolates</a></li>
                                                                      <li><a href="/personalised-gifts/chocolate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalised Chocolates</a></li>
                                                                        <li><a href="/chocolate-bouquet;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate Bouquet</a></li>
                                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/premium;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Premium Chocolates</a></li>
                                                                          <li><a href="/chocolates/hampers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate Hampers</a></li>
                                                                           <li><a href="/chocolates/new-arrivals;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Arrival</a></li>

                                                                 </ul>
                                                             </div>
                                                              <div class="col s2" style="width:20%;background:white!important;">
                                                                     <div class="menu-column-title">By Flavour </div>
                                                                     <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                                         <li><a href="/chocolates/dark;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Dark Chocolates</a></li>
                                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/milk;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Milk Chocolates </a></li>
                                                                         <li><a href="/chocolates/white;jsessionid=486A8842E4390D8EFB2D8B423AA04561">White Chocolates</a></li>
                                                                         <li><a href="/chocolates/sugar-free;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Sugar Free Chocolates</a></li>
                                                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/hand-made;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Hand Made Chocolates</a></li>
                                                                     </ul>
                                                                 </div>
                                                             <div class="col s2" style="width:24%;background:white!important;">
                                                                 <div class="menu-column-title">By Brand</div>
                                                                 <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                                    <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/winni-exclusive;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Winni Exclusive Chocolates</a></li>
                                                                    <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/cadbury;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cadbury Chocolates</a></li>
                                                                     <li><a href="/chocolates/ferrero-rocher;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Ferrero Rocher Chocolates</a></li>
                                                                     <li><a href="/chocolates/jus-trufs;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Jus Trufs Chocolates</a></li>
                                                                    <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/velvet-fine;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Velvet Fine Chocolates</a></li>
                                                                 </ul>
                                                             </div>
                                                             <div class="col s2" style="width:20%;background:white!important;">
                                                                 <div class="menu-column-title">By Combos </div>
                                                                 <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                                                     <li><a href="/chocolates-combo;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate Combos</a></li>
                                                                     <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/combos/cakes-and-chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate And Cakes</a></li>
                                                                     <li><a href="/combos/flowers-and-chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Chocolate And Flowers </a></li>

                                                                 </ul>
                                                                  <div class="menu-column-title">By Occasions</div>
                                                                   <ul>
                                                                       <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Chocolate</a></li>
                                                                           <li><a href="/chocolates/anniversary;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Chocolate</a></li>
                                                                   </ul>
                                                             </div>
                                                             <div class="col s3" style="width:26%;background:white!important;">
                                                                <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                                                    <li  style="margin-top:10px;margin-bottom:0px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;">
                                                                    <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/bestsellers-chocolate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                                                    <img alt="not-load-icon"  class="showList" src="https://assets.winni.in/groot/2023/11/20/chocolate/best-seller.jpg" style="width:100%;padding-bottom:5px;height:200px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                                                    </a>
                                                                    </li>
                                                                    <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/chocolates/same-day-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon" src="https://assets.winni.in/groot/2023/11/20/chocolate/same-day-delivery.jpg" style="width:100%;height:200px!important;border-radius:6px;" ></a></li>
                                                                </ul>
                                                           </div>
                                                         </div>
                     </ul>
                 </li>
            <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdown1" data-constrainWidth="false">
                    COMBOS
                </a>
                <ul id='dropdown1' class='dropdown-content multi-column-drop-menu'  style="min-width:1200px!important;background-repeat: no-repeat;background-attachment: relative;background-position: right bottom;">
                    <div class="row m-0 multi-column-menu">
                        <div class="col s4" style="margin-left:18px!important;">
                            <div class="menu-column-title">Combos By Type</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li><a href="/combos;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Combos</a></li>
                                <li ><a href="/combos/best-sellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Best Seller</a></li>
                                <li><a href="/combos/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Arrival</a></li>
                                <li><a href="/premium-combos;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Premium Combos</a></li>
                                <li><a href="/gifts/gift-hampers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Gift Hampers</a></li>
                            </ul>
                        </div>
                        <div class="col s4" style="background:white;width:35%;">
                            <div class="menu-column-title">Exclusive Combos</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/combos/cake;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Cake Combos </a></li>
                                <li><a href="/combos/flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Flower Combos</a></li>
                                <li><a href="/chocolates-combo;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Chocolate Combos</a></li>
                                <li><a href="/combos/plant;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Plant Combos</a></li>
                                <li><a href="/combos/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Express Combos Delivery</a></li>
                                <li><a href="/personalised-gifts/combo;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalised Combos Gifts</a></li>

                            </ul>
                        </div>
                        <div class="col s4" >
                            <div class="menu-column-title">Featured Combos</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                              <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a class="FontItem marginPaddingBottomForOtherCategory" href="/cakes-and-flowers-delivery-in-india;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Cakes And Flowers </a></li>
                                 <li><a class="FontItem" href="/combos/flowers-and-chocolates;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Flowers and Chocolates </a></li>
                                   <li><a class="FontItem" href="/room-full-of-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Room Full Of Flowers </a></li>
                                   <li><a class="FontItem" href="/room-full-of-teddies;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Room Full Of Teddies </a></li>
                            </ul>
                              <div class="menu-column-title">Occasion Combo</div>
                                <ul>
                                       <li><a class="FontItem" href="/anniversary/combos;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Combo </a></li>
                                         <li><a class="FontItem" href="/combos/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Birthday Combo </a></li>
                                  </ul>
                        </div>
                           <div class="col s4" style="width:36%;background:white!important;padding-left:0px;padding-right:0px!important;">
                                <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                 <li  style="margin-top:30px;margin-bottom:20px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;padding-left:0px;">
                                 <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/combos/best-sellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                 <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/20/combos/best-seller-combos.jpg" style="width:100%;padding-bottom:5px;height:250px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                 </a>
                                 </li>
                                </ul>
                                </div>
                                <div class="col s4" style="margin-top:35px;width:36%;background:white!important;padding-left:0px!important;margin-left:0px!important">
                                <ul class="showAllItem row" style="margin-bottom:20px;padding-bottom:0px;">
                                <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important;"><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/combos/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img alt="not-load-icon"  class="showList" src="https://assets.winni.in/groot/2023/11/20/combos/express-combo-delivery.jpg" style="width:100%;height:245px!important;border-radius:6px;" ></a></li>

                        </ul>
                        </div>
                    </div>
                </ul>
            </li>

            <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdownbdy" data-constrainWidth="false">
                    BIRTHDAY
                </a>
                <ul id='dropdownbdy' class='dropdown-content multi-column-drop-menu'  style="min-width:1090px!important;">
                    <div class="row m-0 multi-column-menu">
                        <div class="col s4" style="width: 31%;margin:0;margin-left:23px!important;">
                            <div class="menu-column-title">Gift By Type</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/birthday-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">All Birthday Gifts</a></li>
                                 <li><a href="/birthday/best-sellers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Best Seller</a></li>
                                    <li><a  href="/cake/photo-cake/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Photo Cakes </a></li>
                                    <li><a  href="/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Same Day Delivery </a></li>
                                      <li><a href="/cake/1st-birthday-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">First Birthday Cakes </a></li>
                                         <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/gifts/balloons-decoration;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Balloon Decoration</a></li>
                                          <li><a href="/birthday-gifts/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Birthday New Arrival</a></li>

                            </ul>
                        </div>
                        <div class="col s4" style="width:37%;margin:0;background:white;">
                            <div class="menu-column-title">Gift By Collection</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/birthday-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Birthday Cakes</a></li>
                           <li><a href="/birthday-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Birthday Flowers</a></li>
                                <li><a href="/combos/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Combos </a></li>
                              <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/birthday-gifts/personalised;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalized Birthday Gifts</a></li>
                                 <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/chocolates/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Birthday Chocolates</a></li>
                                   <li><a href="/plants/birthday;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Birthday Plants</a></li>


                            </ul>

                        </div>
                        <div class="col s4" style="width:33%;margin:0;">
                            <div class="menu-column-title">By Recipient</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li><a href="/birthday-gifts/for-wife;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Wife </a></li>
                                <li><a href="/birthday-gifts/for-husband;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Husband  </a></li>
                                <li><a href="/birthday-gifts/for-kids;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Kids</a></li>
                                 <li><a href="/birthday-gifts/for-her;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Her </a></li>
                                 <li><a href="/birthday-gifts/for-him;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Him</a></li>
                            </ul>
                        </div>
                       <div class="col s4" style="width:40%;background:white!important;padding-left:0px;padding-right:0px!important;">
                              <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                               <li  style="margin-top:30px;margin-bottom:18px;padding-bottom:0px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;padding-left:0px;">
                               <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/birthday-gifts/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                               <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/20/birthday/birthday-new-arrival.jpg" style="width:100%;padding-bottom:5px;height:250px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                               </a>
                               </li>
                              </ul>
                              </div>
                              <div class="col s4" style="margin-top:35px;width:40%;background:white!important;padding-left:0px!important;margin-left:0px!important">
                              <ul class="showAllItem row" style="margin-bottom:18px;padding-bottom:0px;">
                              <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/birthday-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/11/20/birthday/all-birthday-cakes.jpg" style="width:100%;height:245px!important;border-radius:6px;" ></a></li>

                      </ul>
                      </div>
                    </div>
                </ul>
            </li>
            <li>
                <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="dropdownann" data-constrainWidth="false" >
                    ANNIVERSARY
                </a>
                <ul id='dropdownann' class='dropdown-content multi-column-drop-menu' style='min-width:1190px !important'>
                    <div class="row m-0 multi-column-menu">
                        <div class="col s4" style="width:45%;margin-left:25px!important;">
                            <div class="menu-column-title">Gift By Type</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >All Anniversary Gifts </a></li>
                                <li><a href="/bestsellers-anniversary;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Best Seller Anniversary</a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/cake/photo-cake/anniversary;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Photo Cake </a></li>
                                  <li><a  href="/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Same Day Delivery</a></li>
                                  <li><a  href="/balloon-decorations;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Balloon Decorations </a></li>
                                  <li><a  href="/anniversary-gifts/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">  Anniversary New Arrival  </a></li>
                                    <li><a  href="/romantic-couple-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Romantic & Couple Gifts </a></li>
                            </ul>
                        </div>
                        <div class="col s4" style="background:white;width:50%;">
                            <div class="menu-column-title">Gift By Collection</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/anniversary-cakes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Cakes</a></li>
                                <li><a href="/anniversary-flowers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Flowers</a></li>
                                <li><a href="/anniversary/combos;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Combos </a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/anniversary-gifts/personalised;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Personalised Anniversary Gifts</a></li>
                                <li><a href="/anniversary-cakes/1st;jsessionid=486A8842E4390D8EFB2D8B423AA04561">First Anniversary Cakes</a></li>
                                <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/anniversary-cakes/25th;jsessionid=486A8842E4390D8EFB2D8B423AA04561">25th Anniversary Cakes</a></li>
                                <li><a href="/chocolates/anniversary;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Anniversary Chocolates</a></li>
                            </ul>
                        </div>
                        <div class="col s4">
                            <div class="menu-column-title">By Relation</div>
                            <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                <li><a href="/anniversary-gifts/for-wife;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Wife</a></li>
                                <li><a href="/anniversary-gifts/for-husband;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Husband</a></li>
                                <li><a href="/anniversary-gifts/for-parents;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Parents</a></li>
                                <li><a href="/anniversary-gifts/for-bhaiya-bhabhi;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Bhaiya Bhabhi</a></li>
                                <li><a href="/anniversary-gifts/for-didi-jiju;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Didi Jiju</a></li>
                                <li><a href="/anniversary-gifts/for-grand-parents;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Grand Parents</a></li>
                            </ul>
                        </div>
                         <div class="col s4" style="width:44%;background:white!important;padding-left:0px;padding-right:0px!important;">
                              <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                               <li  style="margin-top:30px;margin-bottom:0px;padding-bottom:18px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;padding-left:0px;">
                               <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/anniversary-gifts/new-arrival;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                               <img class="showList" alt="new-arrival" src="https://assets.winni.in/groot/2023/11/20/anniversary/new-arrival.jpg" style="width:100%;padding-bottom:5px;height:250px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                               </a>
                               </li>
                              </ul>
                              </div>
                              <div class="col s4" style="margin-top:35px;width:45%;background:white!important;padding-left:0px!important;margin-left:0px!important">
                              <ul class="showAllItem row" style="margin-bottom:18px;padding-bottom:0px;">
                              <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img alt="anniversary-gifts" class="showList" src="https://assets.winni.in/groot/2023/11/20/anniversary/all-anniversary-gifts.jpg" style="width:100%;height:245px!important;border-radius:6px;" ></a></li>

                      </ul>
                      </div>

                    </div>
                </ul>
            </li>
             <li style="border-right: 1px solid #dfdfdf;">
                            <a class="dropdown-trigger borderBottomForCategories" data-hover="true" data-belowOrigin="true" data-target="OccasionsDropdownann" data-constrainWidth="false" style="margin-right:22px;">
                                OCCASIONS
                            </a>
                            <ul id='OccasionsDropdownann' class='dropdown-content multi-column-drop-menu' style='min-width:1190px !important'>
                                <div class="row m-0 multi-column-menu">
                                    <div class="col s4" style="width:45%;margin-left:25px!important;">
                                        <div class="menu-column-title">Festivals</div>
                                        <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                          <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a  href="/send-rakhi;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Rakshabandhan - 9 Aug</a></li>
                                          <li><a  href="/ganeshchaturthi;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Ganesh Chaturthi - 26 Aug</a></li>
                                          <li><a  href="/navratri;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Navratri - 22 Sep</a></li>
                                          <li><a  href="/dussehra;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Dussehra - 2 Oct </a></li>
                                          <li><a href="/karva-chauth;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Karwa Chauth - 10 Oct</a></li>
                                          <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a  href="/diwali;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Diwali - 20 Oct</a></li>
                                          <li><a  href="/bhai-dooj;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Bhai Dooj - 23 Oct</a></li>
                                          <li><a  href="/christmas;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Christmas - 25 Dec</a></li>
                                          <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/lohri;jsessionid=486A8842E4390D8EFB2D8B423AA04561" >Lohri - 13 Jan</a></li>
                                          <li><a  href="/makar-sankranti;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Makar Sankranti - 14 Jan</a></li>
                                          <li><a  href="/holi/ct/240;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Holi - 14 Mar </a></li>
                                        </ul>
                                    </div>
                                    <div class="col s4" style="background:white;width:50%;">
                                        <div class="menu-column-title">Special Occasions</div>
                                        <ul class="showAllItem" style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                             <li><a href="/gifts/parents-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Parent's Day - 27 Jul</a></li>
                                             <li><a href="/friendship-day-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Friendship Day - 3 Aug </a></li>
                                             <li><a href="/gifts/independence-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Independence Day - 15 Aug</a></li>
                                             <li><a href="/teachers-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Teacher's Day - 5 Sep</a></li>
                                             <li><a href="/boss-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Boss Day - 16 Oct</a></li>
                                             <li><a href="/childrens-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Children's Day - 14 Nov</a></li>
                                             <li><a href="/new-year;jsessionid=486A8842E4390D8EFB2D8B423AA04561">New Year - 1 Jan </a></li>
                                             <li><a href="/republic;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Republic Day - 26 Jan</a></li>
                                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/valentine;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Valentine's Day - 14 Feb </a></li>
                                             <li><a href="/gifts/womens-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Women's Day - 8 Mar</a></li>
                                             <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/gifts/mothers-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Mother's Day - 11 May </a></li>
                                             <li><a href="/gifts/fathers-day;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Father's Day - 15 Jun</a></li>
                                        </ul>
                                    </div>
                                    <div class="col s4">
                                        <div class="menu-column-title">Emotions</div>
                                        <ul style="margin-bottom:0px;padding-bottom:0px;margin-top:-10px!important">
                                            <li><a href="/appreciation/ct/212;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Appreciation</a></li>
                                            <li><a href="/gifts/for-friends;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Friends</a></li>
                                            <li class="ListPositionRelative"><img class="yellowStrip" alt="yellow strip" src="https://assets.winni.in/groot/2023/11/08/desktop/rectangle.png"><a href="/congratulations/ct/167;jsessionid=486A8842E4390D8EFB2D8B423AA04561"> Congratulations</a></li>
                                            <li><a href="/love-and-affection/ct/215;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Love & Affection</a></li>
                                        </ul>
                                    </div>
                                     <div class="col s4" style="width:44%;background:white!important;padding-left:0px;padding-right:0px!important;">
                                          <ul class="showAllItem row" style="margin-bottom:0px;padding-bottom:0px;">
                                           <li  style="margin-top:30px;margin-bottom:0px;padding-bottom:18px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;padding-left:0px;">
                                           <a class="FontItem marginPaddingBottomForOtherCategory"  style="border-bottom-left-radius: 8px;border-bottom-right-radius: 8px;" href="/birthday-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561">
                                           <img class="showList" alt="not-load-icon"  src="https://assets.winni.in/groot/2023/12/29/birthday-header.jpg" style="width:100%;padding-bottom:5px;height:250px!important;border-bottom-left-radius: 8px!important;border-bottom-right-radius: 8px!important;border-top-left-radius: 5px!important;border-top-right-radius: 5px!important;" >
                                           </a>
                                           </li>
                                          </ul>
                                          </div>
                                          <div class="col s4" style="margin-top:35px;width:45%;background:white!important;padding-left:0px!important;margin-left:0px!important">
                                          <ul class="showAllItem row" style="margin-bottom:18px;padding-bottom:0px;">
                                          <li style="border-radius:6px!important;margin-bottom:-4px;padding-bottom:-4px;margin-top:-6px;border-radius:6px!important; "><a class="FontItem marginPaddingBottomForOtherCategory" style="border-radius:6px!important;" href="/anniversary-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img alt="not-load-icon"  class="showList" src="https://assets.winni.in/groot/2023/12/29/anniversary-header.jpg" style="width:100%;height:245px!important;border-radius:6px;" ></a></li>
                                  </ul>
                                  </div>
                                </div>
                            </ul>
                        </li>
                  <li>
            <li style="position: relative;border-bottom:none!important;">
                                            <a class="adbHeaderLink" href="/express-delivery;jsessionid=486A8842E4390D8EFB2D8B423AA04561" style="border-bottom:none!important;">
                                                <div class="left bg-express_delivery_1 ">

                                                </div>
                                                <input type="hidden" value="Delivery In 2 hours" />
                                            </a>
                                        </li>
                                    </li>
        </ul>
    </div>
</nav>
</div>
                     </div>
                 </div>

    </div>

</header>
<div class="hidden-div-for-fixed-header"></div>
<div id="searchModal" class="modal">
    <div class="modal-content">
        <form action="/search;jsessionid=486A8842E4390D8EFB2D8B423AA04561" method="GET" autocomplete="off">
            <div class="row" style="margin-bottom:0;">
                <div class="input-field col s9">
                  <input id="searchInp" type="text" class="validate" name="q">
                    <label for="searchInp" >Search for gifts</label>
                </div>
                <div class="input-field col s3 center-align">
                    <button type="submit" class="btn">Search</button>
                </div>
            </div>
        </form>
    </div>
</div>
<input type="hidden" value="" id="adobeCurrentCityName"/>
<input type="hidden" value="" id="adbSearchQueryIcon"/>
<input type="hidden" value="" id="adbSearchQueryKey"/>
<input type="hidden" value="" id="adobeSuccgoogle"/>
<input type="hidden" value="" id="customerEmail"/>
<input type="hidden" value="" id="customerId"/>
<input type="hidden" value="" id="customerName"/>
<input type="hidden" value="" id="customerMobile"/>
<input type="hidden" value="" id="customerCountryCode"/>
<input type="hidden" id="emlHsh" value=""/>
<input type="hidden" id="mblHsh" value=""/>
<input type="hidden" value="" id="logutCust"/>


</header>

    <main>
        <style>
            .error-fontsize{
                font-size:95px;
            }
            @media (min-width:1px) and (max-width: 513px){
                .error-width{
                    margin-left: 0px;          
                    width:auto;
                }
                .error-fontsize{
                    font-size:65px;
                }     
            }
            @media (min-width:513px) and (max-width: 991px){
                .error-width{
                    margin-left: 0px;
                    width: 350px;
                }
                .error-fontsize{
                    font-size:95px;
                }
            }
        </style>
        <div class="container" style="padding:50px 0;">
            <div class="section" style="padding-bottom:0; background-color: #FFF;">
                <div class="row" style="margin-left: 10%;">
                    <div class="col l6 m6 s12" style="padding-left: 20px;">
                        <div style="color:#EEE;" class="error-fontsize"><b>Oops!</b></div>
                        <div class="error-width" style="color: #333;font-size: 17px;margin-top: -20px;"><p>It’s looking like you may have taken a wrong turn. Don’t worry... it happens to the best of us.</p></div>
                        <div style="color:#333; font-size:16px; margin-top:40px;height: 150px;">
                            <p>Looks like the page you requested does not exist or has moved. We suggest you check if the URL is correct.</p>
                            <p>We can help. Call us on +91-7829463510</p>
                            <!--<p>We can help. Call us on 01762410700 </p>-->
                            <p>Take me back to <a href="/;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Winni Homepage</a></p>
                        </div>
                    </div>


                    <div class="col l6 m6 s12">
                        <div><img class="responsive-img" src='https://assets.winni.in/groot/2023/06/06/four-hundred/cartoon-astronaut.jpg' alt='404 lost astronaut cartoon'></div>
                        <div class="error-fontsize .center-align" style="color:#EEE; margin-top:-30px; margin-left: 60px;"><b>404</b></div>
                    </div>
                </div>   
            </div>
        </div>
        <input type="hidden" id="ntCustEmail" value="">
        <input type="hidden" id="ntCustId" value="">
    </main>

    <style>
    .image-alignment{
       height: 23px!important;
    }
    .text-margin{
        margin-left: 10px;
    }
    .widthForImage{
        width: 19%!important;
    }
    .title{
    margin-bottom:0px !important;
    font-weight:600;
    color: #666666;
    }
    .footerTextColor{
      color: #707070!important;
    }
    .imageWidth{
    margin-top: 20px;
    width: 8%!important;
    padding-right:4px!important;
    padding-left:4px!important;
    }
     @media screen and (min-device-width: 1366px){
        .contactWithUS{
        width: 22%!important;

        }
        .imageWidth{
              margin: 21px 7px 1px 0px;
        }
}
 @media screen and (min-device-width: 1200px) and (max-device-width: 1366px) {
  .allRight{
   font-size: 14px!important;
  }
  }
  .backgroundDesktop{
  background: #F5F5F5 0% 0% no-repeat padding-box!important;
  }
  .imageHeight{
  height: 45px!important;
  }
  .logoImageWidth{
  width:24px!important;
  }
  .textAlignment{
  vertical-align: super;
  color: #333333;
  font-weight:700
  }

</style>
<div class="footer-image-for-corporate-desktop backgroundDesktop">
    <div class="row footer-highlights margin-top-n-20 backgroundDesktop" style="max-width: 1600px; margin: 0 auto">
        <div class="col s12 m12 l4 highlight valign-wrapper">
            <div class="iconContainer left">
            <img class="responsive-img lazyload imageHeight" alt="happy-delivery-icon" src="https://assets.winni.in/groot/2023/07/19/desktop/happy-delivery.png">
            </div>
            <div style="margin-top: -6px;">
                <div class="title">700+ Cities</div>
                <div class="sub-title">Happily Delivering</div>
            </div>
        </div>
        <div class="col s12 m12 l4 highlight valign-wrapper">
            <div class="iconContainer left ">
            <img  class="responsive-img lazyload"  alt="secure-payment"  src="https://assets.winni.in/groot/2023/07/19/desktop/secure-payment.png" style="height: 50px;">
            </div>
            <div>
                <div class="title">100% Secure Payments</div>
                <div class="sub-title">All Major Credit & Debit Cards Accepted</div>
            </div>
        </div>
        <div class="col s12 m12 l4 valign-wrapper" style="padding:20px 18px 15px;">
            <div class="iconContainer left">
          <img class="responsive-img lazyload imageHeight" alt="customer-across"  src="https://assets.winni.in/groot/2023/07/19/desktop/customer-across-the-world.png">
            </div>
            <div>
                <div class="title">20,000,000</div>
                <div class="sub-title">Customers Across The World</div>
            </div>
        </div>
    </div>
</div>
<footer class="desktop" style="background: #FAFAFA 0% 0% no-repeat">
    <div class="container">
        <div class="row" style="max-width: 100%">
            <div class="col m9 l9 s9 "  style="margin:20px 0 0 ">
                <div style class="left">
                 <img class="responsive-img lazyload" alt="logo"  src="https://assets.winni.in/groot/2023/07/19/desktop/logo.png" style="max-width: 72%">
                </div>
            </div>

        </div>
        <div class="row links  adobeFooterEvent" style="margin-bottom:10px">
            <div class="col l3 s12">
                <ul style="border-right: 2px solid #dfdcdc;width:70%">
                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Our Company</li>
                    <li><a class="footerTextColor" href="/about-us;jsessionid=486A8842E4390D8EFB2D8B423AA04561">About Us</a></li>
                    <li><a class="footerTextColor" href="/careers;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Careers</a></li>
                     <li><a class="footerTextColor" href="/contact-us;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Contact Us</a></li>
                     <li><a class="footerTextColor" href="/affiliate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Affiliate Program</a></li>
                     <li><a class="footerTextColor" href="/press;jsessionid=486A8842E4390D8EFB2D8B423AA04561">In News</a></li>
                </ul>
            </div>
            <div class="col l3 s12">
                <ul style="border-right: 2px solid #dfdcdc;width:70%">

                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Quick Links</li>
                <li><a class="footerTextColor" href="/wishes;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Wishes</a></li>
                <li><a class="footerTextColor" href="/sitemap;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Sitemap</a></li>
                     <li><a class="footerTextColor" href="/celebrate-relations;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Blog - Celebrate Relations</a></li>
                   <li><a class="footerTextColor" href="/corporate;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Corporate Order</a></li>
                      <li><a class="footerTextColor" href="/franchise;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Franchise Enquiry</a></li>

                </ul>
            </div>
            <div class="col l3 s12">
                <ul>
                 <li style="color: #000000;font-size:16px;font-weight:600;padding-bottom: 10px;">Policy & Security</li>
                  <li><a class="footerTextColor" href="/s/faq;jsessionid=486A8842E4390D8EFB2D8B423AA04561">FAQ</a></li>
                   <li><a class="footerTextColor" href="/s/terms-and-conditions;jsessionid=486A8842E4390D8EFB2D8B423AA04561#refundPolicy">Refund Policy</a></li>
                   <li><a class="footerTextColor" href="/s/privacy-policy;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Privacy Policy</a></li>
                      <li><a class="footerTextColor" href="/bug-bounty;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Bug Bounty</a></li>
                </ul>
            </div>
            <div class="col l3 s12" style="margin-top: 38px;">
                <ul>
                     <li><a class="footerTextColor" href="/data-security;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Data Security</a></li>
                    <li><a class="footerTextColor" href="/s/terms-and-conditions;jsessionid=486A8842E4390D8EFB2D8B423AA04561#cancelPolicy">Cancellation Policy</a></li>
                    <li><a class="footerTextColor" href="/s/terms-and-conditions;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Terms and Conditions</a></li>
                    <li><a class="footerTextColor" href="/s/payments-and-security;jsessionid=486A8842E4390D8EFB2D8B423AA04561">Payments and Security</a></li>
                </ul>
            </div>
        </div>
    </div>
<div style="background: #F5F5F5 0% 0% no-repeat padding-box;float:left;width:100%">
    <div class="container" >
    <div class="row" style="margin-bottom:0px;margin-top: 20px;">
   <div class="col m6 l6">
                   <div class="row">
                    <div class="col m2 contactWithUS" style="margin-top: 20px;">
                         <span style="color: #0D0D0D;font-weight:600;font-size: 15px;">Connect with Us</span>
                      </div>
                       <div class="col m2 imageWidth" style="margin-top: 20px;width: 6%;">
                           <a  target="_BLANK" rel="nofollow" href="https://www.facebook.com/WinniGifts">
                               <div>
                                <img class="responsive-img lazyload logoImageWidth"  alt="facebook" src="https://assets.winni.in/groot/2023/07/19/desktop/facebook.png">
                               </div>
                           </a>
                       </div>
                        <div class="col m2 imageWidth" style="  margin-left: -25px!important;width: 6%;important">
                          <a   target="_BLANK" rel="nofollow" href="https://www.instagram.com/winnigifts/">
                              <div class="">
                                  <img class="responsive-img lazyload logoImageWidth"  alt="instagram" src="https://assets.winni.in/groot/2023/07/19/desktop/instagram.png">
                              </div>
                          </a>
                      </div>
                       <div class="col m2 imageWidth" style=" margin-left: -25px!important;width: 6%;important">
                           <a target="_BLANK" rel="nofollow" href="https://www.youtube.com/channel/UCsXnWQIHuO3DOr-AhtftD2w">
                               <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="youtube" src="https://assets.winni.in/groot/2023/07/19/desktop/youtube.png" style="height: 24px;">
                               </div>
                           </a>
                       </div>
                        <div class="col m2 imageWidth" style="margin-left: -25px!important;width: 6%;important">
                          <a   target="_BLANK" rel="nofollow" href="https://www.linkedin.com/company/winni">
                              <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="linkdin" src="https://assets.winni.in/groot/2023/07/19/desktop/linkdin.png">
                              </div>
                          </a>
                      </div>
                       <div class="col m2 imageWidth" style=" margin-left: -25px!important;width: 6%;!important">
                           <a  target="_BLANK" rel="nofollow" href="https://twitter.com/winni_gifts">
                               <div>
                                 <img class="responsive-img lazyload logoImageWidth" alt="twiter" src="https://assets.winni.in/groot/2023/12/14/desktop/twiter.png">
                               </div>

                           </a>
                       </div>
                       <div class="col m2 imageWidth" style="margin-left: -25px;width: 6%;">
                          <a  target="_BLANK" rel="noopener"  href="https://www.whatsapp.com/channel/0029VaAqyET72WTsWYuAqe3Z">
                                <img class="responsive-img lazyload logoImageWidth" alt="whatsapp" src="https://assets.winni.in/groot/2024/04/23/mobile/black-whatsapp-icon.png">
                          </a>
                       </div>
                   </div>

   </div>
   <div class="col m6 l6" style="margin-top: 10px;padding-left: 8%;">
   <div style="color: #333333;font-size:19px">Experience Winni on mobile</div>
   </div>
    </div>
    <div class="row allRight" style="margin-bottom: 10px;" >
    <div class="col m6 s6" style="margin-top: -15px;">
       <div style="color: #0D0D0D;font-size: 15px;">&copy; 2013 - <span >2025</span> Winni.in. All Rights Reserved</div>
    </div>
    <div class="col m6 s6" style="padding-left: 8%;">
          <div class="row" style="margin-top: -33px;">
          <div class="col s6 m4" style="padding-right: 0px;">
           <a  target="_BLANK" href="https://play.google.com/store/apps/details?id=in.winni.app&referrer=utm_source%3Dwinni-website%26utm_medium%3Dweb-link">
           <img class="responsive-img lazyload" alt="google-play" src="https://assets.winni.in/groot/2023/07/19/desktop/google-play.png" style="width: 86%;">
          </a>
          </div>
          <div class="col s6 m4" style="padding-left: 0px;margin-left: 27px;">
           <a  target="_BLANK" href="https://apps.apple.com/in/app/winni-cake-flowers-gifts/id1080301515">
            <img class="responsive-img lazyload" alt="app-store" src="https://assets.winni.in/groot/2023/07/19/desktop/app-store.png" style="width: 86%;">
           </a>
           </div>
          </div>
        </div>
    </div>

    </div>
    </div>
    <div style="background: #E8E8E8 0% 0% no-repeat padding-box;">
      <div class="container" >
        <div class="row links  adobeFooterEvent" style="margin-bottom:0px">
             <div class="col m3 widthForImage">
                   <ul>
                       <li><a href="/contact-us;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="responsive-img image-alignment" src="https://assets.winni.in/groot/2023/07/19/desktop/help.png" alt="Help Center"> <span class="text-margin textAlignment" >Help Center</span></a></li>
                   </ul>
               </div>
                <div class="col m3 widthForImage">
                   <ul>
                       <li><a target="_BLANK" href="https://docs.google.com/forms/d/e/1FAIpQLScPw-OEiQkqHUA_Jrhc6DBJgAsVgkI6u9RJDgK7x3-XBsyyBQ/viewform"><img class="responsive-img image-alignment" src="https://assets.winni.in/groot/2023/07/19/desktop/vendor-tie.png" alt="Vendor Tie Up"> <span class="text-margin textAlignment">Vendor Tie-ups</span></a></li>
                   </ul>
               </div>
                 <div class="col m3  widthForImage">
                   <ul>
                       <li><a href="/corporate;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="responsive-img image-alignment" src="https://assets.winni.in/groot/2023/07/19/desktop/corporate-order.png" alt="Corporate Order"> <span class="text-margin textAlignment">Corporate Order</span></a></li>
                   </ul>
               </div>
            <div class="col m3 widthForImage">
                <ul>
                    <li><a href="/franchise;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="responsive-img image-alignment" src="https://assets.winni.in/groot/2023/07/19/desktop/franchise-enquiry.png" alt="Franchise Enquiry"> <span class="text-margin textAlignment">Franchise Enquiry</span> </a></li>
                </ul>
            </div>

            <div class="col m3 widthForImage">
                <ul>
                    <li><a href="/press;jsessionid=486A8842E4390D8EFB2D8B423AA04561"><img class="responsive-img image-alignment" src="https://assets.winni.in/groot/2023/07/19/desktop/winni-news.png" alt="In News"> <span class="text-margin textAlignment"> Winni in News</span></a></li>
                </ul>
            </div>

        </div>
        </div>
        </div>

        <div style="color: #333333;text-align:center;background: #F5F5F5 0% 0% no-repeat padding-box;padding-top:25px;padding-bottom:25px"> Company Name: Dhawala Online Solutions Private Limited | CIN: U51109KA2012PTC065653 | Regd. Office Address: 3rd Floor, PLOT. NO # 128/P2, EPIP Industrial Area Whitefield,
       <div> Sonnenahalli Village, Bangalore &minus; 560066 | Contact no. +91 &minus; 7829463510 | E-mail: info@winni.in</div></div>

<input type="hidden" id="emlHsh" value=""/>
    <input type="hidden" id="mblHsh" value=""/>
    <input type="hidden" id="internaCountry" value=""/>
    <input type="hidden" id="productName" value=""/>
    <input type="hidden" id="categoryName" value=""/>
    <input type="hidden" id="totalProductsSearch" value=""/>
    <input type="hidden" id="deviceType" value=""/>
    <script type="text/javascript">
        var webAppLogin = {
            loginUriFooter: "/cs/customer/login;jsessionid=486A8842E4390D8EFB2D8B423AA04561",
        };
    </script>
</footer>
<script src="https://assets.winni.in/coreast/constant/js/vnd/lazysizes-5.3.0.min.js"></script>
    <script defer src="https://assets.winni.in/coreast/constant/js/vnd/jquery-3.7.1.min.js"></script>
    <script defer src="/assets/js/thor/adv-initialize.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>
    <script defer src="https://assets.winni.in/coreast/constant/js/vnd/materialize-1.0.1.min.js"></script>
    <script defer src="/assets/js/thor/mixpanel-event.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>


<script defer src="https://assets.winni.in/coreast/constant/js/vnd/slick-1.8.1.min.js"></script>
            <link rel="stylesheet" type="text/css" href="https://assets.winni.in/coreast/constant/css/vnd/slick-1.8.1.min.css">
        <script defer src="https://assets.winni.in/coreast/constant/js/vnd/infinite-scroll-4.0.1.pkgd.min.js"></script>
        <script defer src="https://assets.winni.in/coreast/constant/js/vnd/typeahead-0.11.1.js"></script>
        <script defer src="https://assets.winni.in/coreast/constant/js/vnd/handlebars.min-v4.7.6.js"></script>
        <script defer src="https://assets.winni.in/coreast/constant/js/vnd/money-0.2.min.js"></script>
        <script defer src="https://assets.winni.in/coreast/constant/js/vnd/accounting-0.4.2.min.js"></script>
        <script defer src="/assets/js/thor/currency.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>
        <script defer src="/assets/js/thor/main.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>
        <script defer type="text/javascript" src="/assets/js/thor/geolocation.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>
        <script defer src="/assets/js/thor/city-pincode-search.js;jsessionid=486A8842E4390D8EFB2D8B423AA04561"></script>
        <script>
            window.cityUrl = '/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.cartItemsByAjax = '/gift-box/home-xhr;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.searchQueryUrl = '/search/queries/%QUERY.json';
            window.recentSearchUrl = '/search;jsessionid=486A8842E4390D8EFB2D8B423AA04561?q=';
            window.recentViewedproductUri = '/catalog/product/recently-viewed/top;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.allCitiesUrl = '/app/cityName;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.changeCityUrl = '/change-city/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.changeCurrentCityUrl = '/xhr/change-city;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.advstit = '/advstrprcs;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.customerGiftcard = '/api/v2/customer-giftcard;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.newsFilterUri = '/news/filter/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.exchangemoney = {"AUD":0.0179,"AED":0.0425,"SGD":0.0149,"QAR":0.0421,"EUR":0.0101,"GBP":0.0086,"MYR":0.0491,"USD":0.0116,"CAD":0.0158,"NZD":0.0192,"INR":1.0000,"THB":0.3774};
            window.currConSymble = {"AUD":"$","AED":"د.إ","SGD":"$","QAR":"ر.ق","EUR":"€","GBP":"£","MYR":"RM","USD":"$","CAD":"$","NZD":"$","INR":"₹","THB":"฿"};
            window.saveGoogleCoordinatesUri = '/save/google/coords;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.setUserCityUri = '/xhr/set/user/city;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.checkUserPin = '/xhr/check/user/pin;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.setCountryUri = '/xhr/set/user/country;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.searchIndianCity = '/search/indianCity/queries/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.getCountryIdUri = '/xhr/get-country-id;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.searchInternationalCity = '/intern/search/location/beforeCheckout/queries;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.allGiftsPageUrl = '/courier-gifts;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.previousButtonUrl = '/previous/survey/question/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.nextButtonUrl = '/add/survey/response/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
            window.finishButtonUrl = '/finish/survey/question/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.reviewHelpfulUrl = '/checked-helpful/;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.fetchGeoAddressUri = '/geo/address;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.saveUserDemographicResponseUri = '/xhr/save/user-demographic;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.savedAdressedUri = '/get-address-customer;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.contactUsUrl = '/contact-us;jsessionid=486A8842E4390D8EFB2D8B423AA04561';
			window.isEnabledUserDemographic=true;
			window.isLimeChatEnabled=true;
			
			window.currentCountryId=41;
</script>

<script type="text/javascript">
    dataLayer.push({
        'user_id': '',
        'crm_id': ''
    });
    const SERVER_CODES = {
        
          'INVALID_REQUEST':3001,
        
          'SESSION_EXPIRED':2001,
        
          'DELIVERY_SLOT_EXPIRED':1001,
        
    };
     const SERVER_CODES_MESSAGE = {
        2001:'session expired',
        1001:'delivery time slot expired',
        3001:'Invalid Request',
        
    };
</script>
<script type="text/javascript">window.isMobileWeb = false;</script>
	</body>
</html>
