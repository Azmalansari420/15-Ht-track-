<!doctype html>
		<html lang="en-US">
		
	<head>

				<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="https://gmpg.org/xfn/11">
		
		<script type='text/javascript' id='asp-c65f18e5-js-before'>if ( typeof window.ASP == 'undefined') { window.ASP = {wp_rocket_exception: "DOMContentLoaded", ajaxurl: "https:\/\/www.sliderrevolution.com\/wp-admin\/admin-ajax.php", backend_ajaxurl: "https:\/\/www.sliderrevolution.com\/wp-admin\/admin-ajax.php", asp_url: "https:\/\/www.sliderrevolution.com\/wp-content\/plugins\/ajax-search-pro\/", upload_url: "https:\/\/www.sliderrevolution.com\/wp-content\/uploads\/asp_upload\/", detect_ajax: 0, media_query: "Y98z1C", version: "4.27.2", build: 5095, pageHTML: "", additional_scripts: [{"handle":"wd-asp-ajaxsearchpro","src":"https:\/\/www.sliderrevolution.com\/wp-content\/plugins\/ajax-search-pro\/js\/min\/plugin\/merged\/asp.min.js","prereq":false}], script_async_load: false, font_url: "https:\/\/www.sliderrevolution.com\/wp-content\/plugins\/ajax-search-pro\/css\/fonts\/icons\/icons2.woff2", init_only_in_viewport: true, highlight: {"enabled":false,"data":[]}, debug: false, instances: {}, analytics: {"method":"event","tracking_id":"","event":{"focus":{"active":true,"action":"focus","category":"ASP {search_id} | {search_name}","label":"Input focus","value":"1"},"search_start":{"active":false,"action":"search_start","category":"ASP {search_id} | {search_name}","label":"Phrase: {phrase}","value":"1"},"search_end":{"active":true,"action":"search_end","category":"ASP {search_id} | {search_name}","label":"{phrase} | {results_count}","value":"1"},"magnifier":{"active":true,"action":"magnifier","category":"ASP {search_id} | {search_name}","label":"Magnifier clicked","value":"1"},"return":{"active":true,"action":"return","category":"ASP {search_id} | {search_name}","label":"Return button pressed","value":"1"},"try_this":{"active":true,"action":"try_this","category":"ASP {search_id} | {search_name}","label":"Try this click | {phrase}","value":"1"},"facet_change":{"active":false,"action":"facet_change","category":"ASP {search_id} | {search_name}","label":"{option_label} | {option_value}","value":"1"},"result_click":{"active":true,"action":"result_click","category":"ASP {search_id} | {search_name}","label":"{result_title} | {result_url}","value":"1"}}}}};</script><meta name='robots' content='noindex, follow' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
	<!-- This site is optimized with the Yoast SEO Premium plugin v25.9 (Yoast SEO v26.1.1) - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Slider Revolution</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Slider Revolution" />
	<meta property="og:site_name" content="Slider Revolution" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://www.sliderrevolution.com/#website","url":"https://www.sliderrevolution.com/","name":"Slider Revolution","description":"More than just a WordPress slider","publisher":{"@id":"https://www.sliderrevolution.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.sliderrevolution.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https://www.sliderrevolution.com/#organization","name":"Slider Revolution","url":"https://www.sliderrevolution.com/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://www.sliderrevolution.com/#/schema/logo/image/","url":"https://www.sliderrevolution.com/wp-content/uploads/2020/09/SRlogo_large.png","contentUrl":"https://www.sliderrevolution.com/wp-content/uploads/2020/09/SRlogo_large.png","width":320,"height":320,"caption":"Slider Revolution"},"image":{"@id":"https://www.sliderrevolution.com/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//fonts.googleapis.com' />

<link rel='stylesheet' id='wp-block-library-css' href='https://www.sliderrevolution.com/wp-includes/css/dist/block-library/style.min.css?ver=6.8.2' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
.wp-block-audio :where(figcaption){color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio :where(figcaption){color:#ffffffa6}.wp-block-audio{margin:0 0 1em}.wp-block-code{border:1px solid #ccc;border-radius:4px;font-family:Menlo,Consolas,monaco,monospace;padding:.8em 1em}.wp-block-embed :where(figcaption){color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed :where(figcaption){color:#ffffffa6}.wp-block-embed{margin:0 0 1em}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:#ffffffa6}:root :where(.wp-block-image figcaption){color:#555;font-size:13px;text-align:center}.is-dark-theme :root :where(.wp-block-image figcaption){color:#ffffffa6}.wp-block-image{margin:0 0 1em}.wp-block-pullquote{border-bottom:4px solid;border-top:4px solid;color:currentColor;margin-bottom:1.75em}.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{color:currentColor;font-size:.8125em;font-style:normal;text-transform:uppercase}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;font-style:normal;position:relative}.wp-block-quote:where(.has-text-align-right){border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote:where(.has-text-align-center){border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote:where(.is-style-plain){border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-search__button{border:1px solid #ccc;padding:.375em .625em}:where(.wp-block-group.has-background){padding:1.25em 2.375em}.wp-block-separator.has-css-opacity{opacity:.4}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto}.wp-block-separator.has-alpha-channel-opacity{opacity:1}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table{margin:0 0 1em}.wp-block-table td,.wp-block-table th{word-break:normal}.wp-block-table :where(figcaption){color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table :where(figcaption){color:#ffffffa6}.wp-block-video :where(figcaption){color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video :where(figcaption){color:#ffffffa6}.wp-block-video{margin:0 0 1em}:root :where(.wp-block-template-part.has-background){margin-bottom:0;margin-top:0;padding:1.25em 2.375em}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<link rel='stylesheet' id='dashicons-css' href='https://www.sliderrevolution.com/wp-includes/css/dashicons.min.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='essgrid-blocks-editor-css-css' href='https://www.sliderrevolution.com/wp-content/plugins/essential-grid/admin/includes/builders/gutenberg/build/index.css?ver=1755513402' type='text/css' media='all' />
<link rel='stylesheet' id='lordicon-element-css-css' href='https://www.sliderrevolution.com/wp-content/plugins/lordicon-interactive-icons/dist/element.css?ver=1.0.0' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='sr7css-css' href='//www.sliderrevolution.com/wp-content/plugins/revslider/public/css/sr7.css?ver=6.7.37' type='text/css' media='all' />
<link rel='stylesheet' id='themepunch-beta-style-css' href='https://www.sliderrevolution.com/wp-content/plugins/themepunch-beta-tester/assets/css/style.css?ver=1.0' type='text/css' media='all' />
<style id='plvt-view-transitions-inline-css' type='text/css'>
@view-transition { navigation: auto; }
@media (prefers-reduced-motion: no-preference) {::view-transition-group(*) { animation-duration: 0.4s; }}
</style>
<link rel='stylesheet' id='zakra-style-css' href='https://www.sliderrevolution.com/wp-content/themes/zakra/style.css?ver=6.8.2' type='text/css' media='all' />
<style id='zakra-style-inline-css' type='text/css'>
@media screen and (min-width:1200px){.tg-container{max-width:1160px;}}a:hover, a:focus, .tg-primary-menu > div ul li:hover > a,  .tg-primary-menu > div ul li.current_page_item > a, .tg-primary-menu > div ul li.current-menu-item > a,  .tg-mobile-navigation > div ul li.current_page_item > a, .tg-mobile-navigation > div ul li.current-menu-item > a,  .entry-content a,  .tg-meta-style-two .entry-meta span, .tg-meta-style-two .entry-meta a{color:#f7345e;}.tg-primary-menu.tg-primary-menu--style-underline > div > ul > li.current_page_item > a::before, .tg-primary-menu.tg-primary-menu--style-underline > div > ul > li.current-menu-item > a::before, .tg-primary-menu.tg-primary-menu--style-left-border > div > ul > li.current_page_item > a::before, .tg-primary-menu.tg-primary-menu--style-left-border > div > ul > li.current-menu-item > a::before, .tg-primary-menu.tg-primary-menu--style-right-border > div > ul > li.current_page_item > a::before, .tg-primary-menu.tg-primary-menu--style-right-border > div > ul > li.current-menu-item > a::before, .tg-scroll-to-top:hover, button, input[type="button"], input[type="reset"], input[type="submit"], .tg-primary-menu > div ul li.tg-header-button-wrap a{background-color:#f7345e;}body{color:rgba(28,9,80,0.75);}button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover, #infinite-handle span:hover{background-color:#1e7ba6;}.tg-site-header .tg-site-header-top{color:#ffffff;}.tg-site-header .tg-site-header-top{background-color:#5e35b1;background-size:contain;}.tg-site-header, .tg-container--separate .tg-site-header{background-size:contain;}.tg-site-header{border-bottom-width:0px;}.main-navigation.tg-primary-menu > div ul li.tg-header-button-wrap a:hover{background-color:#1e7ba6;}.tg-page-header, .tg-container--separate .tg-page-header{background-position:center center;background-size:contain;}.tg-site-footer-widgets{background-color:#150a33;}.tg-site-footer .tg-site-footer-widgets .widget-title{color:#ffffff;}.tg-site-footer .tg-site-footer-widgets a{color:#a08fc3;}.tg-site-footer .tg-site-footer-widgets a:hover, .tg-site-footer .tg-site-footer-widgets a:focus{color:#c4b2ed;}.tg-site-footer .tg-site-footer-widgets{border-top-width:0px;}.tg-site-footer .tg-site-footer-widgets ul li{border-bottom-width:0px;}.tg-site-footer .tg-site-footer-bar{background-color:#5e35b1;}.tg-site-footer .tg-site-footer-bar{color:#ffffff;}.tg-scroll-to-top{background-color:#22c8e5;}.tg-scroll-to-top:hover{background-color:#f7345e;}
</style>
<link rel='stylesheet' id='child-style-css' href='https://www.sliderrevolution.com/wp-content/themes/SliderRevolution/style.css?ver=6.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://www.sliderrevolution.com/wp-content/themes/zakra/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-pagenavi-css' href='https://www.sliderrevolution.com/wp-content/plugins/wp-pagenavi/pagenavi-css.css?ver=2.70' type='text/css' media='all' />
<link rel='stylesheet' id='tp-fontello-css' href='https://www.sliderrevolution.com/wp-content/plugins/essential-grid/public/assets/font/fontello/css/fontello.css?ver=3.1.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='esg-plugin-settings-css' href='https://www.sliderrevolution.com/wp-content/plugins/essential-grid/public/assets/css/settings.css?ver=3.1.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='esg-tp-boxextcss-css' href='https://www.sliderrevolution.com/wp-content/plugins/essential-grid/public/assets/css/jquery.esgbox.min.css?ver=3.1.9.3' type='text/css' media='all' />
<style type="text/css">@font-face {font-family:Raleway;font-style:normal;font-weight:100;src:url(/cf-fonts/s/raleway/5.0.16/latin/100/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:100;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/100/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:100;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/100/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:100;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/100/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:100;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/100/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:200;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/200/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:200;src:url(/cf-fonts/s/raleway/5.0.16/latin/200/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:200;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/200/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:200;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/200/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:200;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/200/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:300;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/300/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:300;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/300/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:300;src:url(/cf-fonts/s/raleway/5.0.16/latin/300/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:300;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/300/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:300;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/300/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:400;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/400/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:400;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/400/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:400;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/400/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:400;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/400/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:400;src:url(/cf-fonts/s/raleway/5.0.16/latin/400/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:500;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/500/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:500;src:url(/cf-fonts/s/raleway/5.0.16/latin/500/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:500;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/500/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:500;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/500/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:500;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/500/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:600;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/600/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:600;src:url(/cf-fonts/s/raleway/5.0.16/latin/600/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:600;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/600/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:600;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/600/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:600;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/600/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:700;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/700/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:700;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/700/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:700;src:url(/cf-fonts/s/raleway/5.0.16/latin/700/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:700;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/700/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:700;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/700/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:800;src:url(/cf-fonts/s/raleway/5.0.16/latin/800/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:800;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/800/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:800;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/800/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:800;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/800/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:800;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/800/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:900;src:url(/cf-fonts/s/raleway/5.0.16/latin/900/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:900;src:url(/cf-fonts/s/raleway/5.0.16/vietnamese/900/normal.woff2);unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:900;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic/900/normal.woff2);unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:900;src:url(/cf-fonts/s/raleway/5.0.16/latin-ext/900/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Raleway;font-style:normal;font-weight:900;src:url(/cf-fonts/s/raleway/5.0.16/cyrillic-ext/900/normal.woff2);unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;font-display:swap;}</style>
<style type="text/css">@font-face {font-family:Sora;font-style:normal;font-weight:300;src:url(/cf-fonts/s/sora/5.0.16/latin/300/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Sora;font-style:normal;font-weight:300;src:url(/cf-fonts/s/sora/5.0.16/latin-ext/300/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Sora;font-style:normal;font-weight:400;src:url(/cf-fonts/s/sora/5.0.16/latin/400/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}@font-face {font-family:Sora;font-style:normal;font-weight:400;src:url(/cf-fonts/s/sora/5.0.16/latin-ext/400/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Sora;font-style:normal;font-weight:700;src:url(/cf-fonts/s/sora/5.0.16/latin-ext/700/normal.woff2);unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;font-display:swap;}@font-face {font-family:Sora;font-style:normal;font-weight:700;src:url(/cf-fonts/s/sora/5.0.16/latin/700/normal.woff2);unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;font-display:swap;}</style>
<link rel='stylesheet' id='sr_documentation_styles-css' href='https://www.sliderrevolution.com/wp-content/plugins/sr-documentation/sr-documentation-styles.css?ver=6.8.2' type='text/css' media='all' />
<script type="text/javascript" id="webtoffee-cookie-consent-js-extra">
/* <![CDATA[ */
var _wccConfig = {"_ipData":[],"_assetsURL":"https:\/\/www.sliderrevolution.com\/wp-content\/plugins\/webtoffee-cookie-consent\/lite\/frontend\/images\/","_publicURL":"https:\/\/www.sliderrevolution.com","_categories":[{"name":"Necessary","slug":"necessary","isNecessary":true,"ccpaDoNotSell":true,"cookies":[{"cookieID":"__cf_bm","domain":".onesignal.com","provider":"cloudflare.com"},{"cookieID":"wt_consent","domain":"www.sliderrevolution.com","provider":""},{"cookieID":"PHPSESSID","domain":"account.sliderrevolution.com","provider":""},{"cookieID":"cookietest","domain":"www.sliderrevolution.com","provider":"shopify.com"},{"cookieID":"euconsent","domain":"www.sliderrevolution.com","provider":"cookieyes.com"}],"active":true,"defaultConsent":{"gdpr":true,"ccpa":true},"foundNoCookieScript":false},{"name":"Functional","slug":"functional","isNecessary":false,"ccpaDoNotSell":true,"cookies":[],"active":true,"defaultConsent":{"gdpr":false,"ccpa":false},"foundNoCookieScript":false},{"name":"Analytics","slug":"analytics","isNecessary":false,"ccpaDoNotSell":true,"cookies":[{"cookieID":"_ga","domain":".sliderrevolution.com","provider":"google-analytics.com|googletagmanager.com\/gtag\/js"},{"cookieID":"_ga_*","domain":".sliderrevolution.com","provider":"google-analytics.com|googletagmanager.com\/gtag\/js"}],"active":true,"defaultConsent":{"gdpr":true,"ccpa":false},"foundNoCookieScript":false},{"name":"Performance","slug":"performance","isNecessary":false,"ccpaDoNotSell":true,"cookies":[],"active":true,"defaultConsent":{"gdpr":false,"ccpa":false},"foundNoCookieScript":false},{"name":"Advertisement","slug":"advertisement","isNecessary":false,"ccpaDoNotSell":true,"cookies":[{"cookieID":"YSC","domain":".youtube.com","provider":"youtube.com"},{"cookieID":"VISITOR_INFO1_LIVE","domain":".youtube.com","provider":"youtube.com"},{"cookieID":"VISITOR_PRIVACY_METADATA","domain":".youtube.com","provider":"youtube.com"}],"active":true,"defaultConsent":{"gdpr":false,"ccpa":false},"foundNoCookieScript":false},{"name":"Others","slug":"others","isNecessary":false,"ccpaDoNotSell":true,"cookies":[{"cookieID":"wpcaptcha_captcha_9039","domain":"www.sliderrevolution.com","provider":""}],"active":true,"defaultConsent":{"gdpr":false,"ccpa":false},"foundNoCookieScript":false}],"_activeLaw":"gdpr","_rootDomain":"","_block":"1","_showBanner":"1","_bannerConfig":{"GDPR":{"settings":{"type":"box","position":"bottom-left","applicableLaw":"gdpr","preferenceCenter":"center","selectedRegion":"ALL","consentExpiry":365,"shortcodes":[{"key":"wcc_readmore","content":"<a href=\"#\" class=\"wcc-policy\" aria-label=\"Cookie Policy\" target=\"_blank\" rel=\"noopener\" data-tag=\"readmore-button\">Cookie Policy<\/a>","tag":"readmore-button","status":false,"attributes":{"rel":"nofollow","target":"_blank"}},{"key":"wcc_show_desc","content":"<button class=\"wcc-show-desc-btn\" data-tag=\"show-desc-button\" aria-label=\"Show more\">Show more<\/button>","tag":"show-desc-button","status":true,"attributes":[]},{"key":"wcc_hide_desc","content":"<button class=\"wcc-show-desc-btn\" data-tag=\"hide-desc-button\" aria-label=\"Show less\">Show less<\/button>","tag":"hide-desc-button","status":true,"attributes":[]},{"key":"wcc_category_toggle_label","content":"[wcc_{{status}}_category_label] [wcc_preference_{{category_slug}}_title]","tag":"","status":true,"attributes":[]},{"key":"wcc_enable_category_label","content":"Enable","tag":"","status":true,"attributes":[]},{"key":"wcc_disable_category_label","content":"Disable","tag":"","status":true,"attributes":[]},{"key":"wcc_video_placeholder","content":"<div class=\"video-placeholder-normal\" data-tag=\"video-placeholder\" id=\"[UNIQUEID]\"><p class=\"video-placeholder-text-normal\" data-tag=\"placeholder-title\">Please accept cookies to access this content<\/p><\/div>","tag":"","status":true,"attributes":[]},{"key":"wcc_enable_optout_label","content":"Enable","tag":"","status":true,"attributes":[]},{"key":"wcc_disable_optout_label","content":"Disable","tag":"","status":true,"attributes":[]},{"key":"wcc_optout_toggle_label","content":"[wcc_{{status}}_optout_label] [wcc_optout_option_title]","tag":"","status":true,"attributes":[]},{"key":"wcc_optout_option_title","content":"Do Not Sell or Share My Personal Information","tag":"","status":true,"attributes":[]},{"key":"wcc_optout_close_label","content":"Close","tag":"","status":true,"attributes":[]}],"bannerEnabled":true},"behaviours":{"reloadBannerOnAccept":false,"loadAnalyticsByDefault":false,"animations":{"onLoad":"animate","onHide":"sticky"}},"config":{"revisitConsent":{"status":false,"tag":"revisit-consent","position":"bottom-left","meta":{"url":"#"},"styles":[],"elements":{"title":{"type":"text","tag":"revisit-consent-title","status":true,"styles":{"color":"#0056a7"}}}},"preferenceCenter":{"toggle":{"status":true,"tag":"detail-category-toggle","type":"toggle","states":{"active":{"styles":{"background-color":"#000000"}},"inactive":{"styles":{"background-color":"#D0D5D2"}}}},"poweredBy":{"status":false,"tag":"detail-powered-by","styles":{"background-color":"#EDEDED","color":"#293C5B"}}},"categoryPreview":{"status":false,"toggle":{"status":true,"tag":"detail-category-preview-toggle","type":"toggle","states":{"active":{"styles":{"background-color":"#000000"}},"inactive":{"styles":{"background-color":"#D0D5D2"}}}}},"videoPlaceholder":{"status":true,"styles":{"background-color":"#000000","border-color":"#000000","color":"#ffffff"}},"readMore":{"status":false,"tag":"readmore-button","type":"link","meta":{"noFollow":true,"newTab":true},"styles":{"color":"#000000","background-color":"transparent","border-color":"transparent"}},"auditTable":{"status":true},"optOption":{"status":true,"toggle":{"status":true,"tag":"optout-option-toggle","type":"toggle","states":{"active":{"styles":{"background-color":"#000000"}},"inactive":{"styles":{"background-color":"#FFFFFF"}}}},"gpcOption":false}}}},"_version":"3.4.3","_logConsent":"1","_tags":[{"tag":"accept-button","styles":{"color":"#FFFFFF","background-color":"#F7345E","border-color":"#F7345E"}},{"tag":"reject-button","styles":{"color":"#000000","background-color":"transparent","border-color":"#000000"}},{"tag":"settings-button","styles":{"color":"#F7345E","background-color":"transparent","border-color":"#F7345E"}},{"tag":"readmore-button","styles":{"color":"#000000","background-color":"transparent","border-color":"transparent"}},{"tag":"donotsell-button","styles":{"color":"#1863dc","background-color":"transparent","border-color":"transparent"}},{"tag":"accept-button","styles":{"color":"#FFFFFF","background-color":"#F7345E","border-color":"#F7345E"}},{"tag":"revisit-consent","styles":[]}],"_rtl":"","_lawSelected":["GDPR"],"_restApiUrl":"https:\/\/directory.cookieyes.com\/api\/v1\/ip","_renewConsent":"","_restrictToCA":"","_customEvents":"","_ccpaAllowedRegions":[],"_gdprAllowedRegions":[],"_closeButtonAction":"reject","_ssl":"1","_providersToBlock":[{"re":"youtube.com","categories":["advertisement"]}]};
var _wccStyles = {"css":{"GDPR":".wcc-overlay{background: #000000; opacity: 0.4; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 99999999;}.wcc-hide{display: none;}.wcc-btn-revisit-wrapper{display: flex; padding: 6px; border-radius: 8px; opacity: 0px; background-color:#ffffff; box-shadow: 0px 3px 10px 0px #798da04d;  align-items: center; justify-content: center;   position: fixed; z-index: 999999; cursor: pointer;}.wcc-revisit-bottom-left{bottom: 15px; left: 15px;}.wcc-revisit-bottom-right{bottom: 15px; right: 15px;}.wcc-btn-revisit-wrapper .wcc-btn-revisit{display: flex; align-items: center; justify-content: center; background: none; border: none; cursor: pointer; position: relative; margin: 0; padding: 0;}.wcc-btn-revisit-wrapper .wcc-btn-revisit img{max-width: fit-content; margin: 0; } .wcc-btn-revisit-wrapper .wcc-revisit-help-text{font-size:14px; margin-left:4px; display:none;}.wcc-btn-revisit-wrapper:hover .wcc-revisit-help-text {display: block;}.wcc-revisit-hide{display: none;}.wcc-preference-btn:hover{cursor:pointer; text-decoration:underline;}.wcc-cookie-audit-table { font-family: inherit; border-collapse: collapse; width: 100%;} .wcc-cookie-audit-table th, .wcc-cookie-audit-table td {text-align: left; padding: 10px; font-size: 12px; color: #000000; word-break: normal; background-color: #d9dfe7; border: 1px solid #cbced6;} .wcc-cookie-audit-table tr:nth-child(2n + 1) td { background: #f1f5fa; }.wcc-consent-container{position: fixed; width: 440px; box-sizing: border-box; z-index: 9999999; border-radius: 6px;}.wcc-consent-container .wcc-consent-bar{background: #ffffff; border: 1px solid; padding: 20px 26px; box-shadow: 0 -1px 10px 0 #acabab4d; border-radius: 6px;}.wcc-box-bottom-left{bottom: 40px; left: 40px;}.wcc-box-bottom-right{bottom: 40px; right: 40px;}.wcc-box-top-left{top: 40px; left: 40px;}.wcc-box-top-right{top: 40px; right: 40px;}.wcc-custom-brand-logo-wrapper .wcc-custom-brand-logo{width: 100px; height: auto; margin: 0 0 12px 0;}.wcc-notice .wcc-title{color: #212121; font-weight: 700; font-size: 18px; line-height: 24px; margin: 0 0 12px 0;}.wcc-notice-des *,.wcc-preference-content-wrapper *,.wcc-accordion-header-des *,.wcc-gpc-wrapper .wcc-gpc-desc *{font-size: 14px;}.wcc-notice-des{color: #212121; font-size: 14px; line-height: 24px; font-weight: 400;}.wcc-notice-des img{height: 25px; width: 25px;}.wcc-consent-bar .wcc-notice-des p,.wcc-gpc-wrapper .wcc-gpc-desc p,.wcc-preference-body-wrapper .wcc-preference-content-wrapper p,.wcc-accordion-header-wrapper .wcc-accordion-header-des p,.wcc-cookie-des-table li div:last-child p{color: inherit; margin-top: 0;}.wcc-notice-des P:last-child,.wcc-preference-content-wrapper p:last-child,.wcc-cookie-des-table li div:last-child p:last-child,.wcc-gpc-wrapper .wcc-gpc-desc p:last-child{margin-bottom: 0;}.wcc-notice-des a.wcc-policy,.wcc-notice-des button.wcc-policy{font-size: 14px; color: #1863dc; white-space: nowrap; cursor: pointer; background: transparent; border: 1px solid; text-decoration: underline;}.wcc-notice-des button.wcc-policy{padding: 0;}.wcc-notice-des a.wcc-policy:focus-visible,.wcc-notice-des button.wcc-policy:focus-visible,.wcc-preference-content-wrapper .wcc-show-desc-btn:focus-visible,.wcc-accordion-header .wcc-accordion-btn:focus-visible,.wcc-preference-header .wcc-btn-close:focus-visible,.wcc-switch input[type=\"checkbox\"]:focus-visible,.wcc-footer-wrapper a:focus-visible,.wcc-btn:focus-visible{outline: 2px solid #1863dc; outline-offset: 2px;}.wcc-btn:focus:not(:focus-visible),.wcc-accordion-header .wcc-accordion-btn:focus:not(:focus-visible),.wcc-preference-content-wrapper .wcc-show-desc-btn:focus:not(:focus-visible),.wcc-btn-revisit-wrapper .wcc-btn-revisit:focus:not(:focus-visible),.wcc-preference-header .wcc-btn-close:focus:not(:focus-visible),.wcc-consent-bar .wcc-banner-btn-close:focus:not(:focus-visible){outline: 0;}button.wcc-show-desc-btn:not(:hover):not(:active){color: #1863dc; background: transparent;}button.wcc-accordion-btn:not(:hover):not(:active),button.wcc-banner-btn-close:not(:hover):not(:active),button.wcc-btn-revisit:not(:hover):not(:active),button.wcc-btn-close:not(:hover):not(:active){background: transparent;}.wcc-consent-bar button:hover,.wcc-modal.wcc-modal-open button:hover,.wcc-consent-bar button:focus,.wcc-modal.wcc-modal-open button:focus{text-decoration: none;}.wcc-notice-btn-wrapper{display: flex; justify-content: flex-start; align-items: center; flex-wrap: wrap; margin-top: 16px;}.wcc-notice-btn-wrapper .wcc-btn{text-shadow: none; box-shadow: none;}.wcc-btn{flex: auto; max-width: 100%; font-size: 14px; font-family: inherit; line-height: 24px; padding: 8px; font-weight: 500; margin: 0 8px 0 0; border-radius: 2px; cursor: pointer; text-align: center; text-transform: none; min-height: 0;}.wcc-btn:hover{opacity: 0.8;}.wcc-btn-customize{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.wcc-btn-reject{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.wcc-btn-accept{background: #1863dc; color: #ffffff; border: 2px solid #1863dc;}.wcc-btn:last-child{margin-right: 0;}@media (max-width: 576px){.wcc-box-bottom-left{bottom: 0; left: 0;}.wcc-box-bottom-right{bottom: 0; right: 0;}.wcc-box-top-left{top: 0; left: 0;}.wcc-box-top-right{top: 0; right: 0;}}@media (max-width: 440px){.wcc-box-bottom-left, .wcc-box-bottom-right, .wcc-box-top-left, .wcc-box-top-right{width: 100%; max-width: 100%;}.wcc-consent-container .wcc-consent-bar{padding: 20px 0;}.wcc-custom-brand-logo-wrapper, .wcc-notice .wcc-title, .wcc-notice-des, .wcc-notice-btn-wrapper{padding: 0 24px;}.wcc-notice-des{max-height: 40vh; overflow-y: scroll;}.wcc-notice-btn-wrapper{flex-direction: column; margin-top: 0;}.wcc-btn{width: 100%; margin: 10px 0 0 0;}.wcc-notice-btn-wrapper .wcc-btn-customize{order: 2;}.wcc-notice-btn-wrapper .wcc-btn-reject{order: 3;}.wcc-notice-btn-wrapper .wcc-btn-accept{order: 1; margin-top: 16px;}}@media (max-width: 352px){.wcc-notice .wcc-title{font-size: 16px;}.wcc-notice-des *{font-size: 12px;}.wcc-notice-des, .wcc-btn{font-size: 12px;}}.wcc-modal.wcc-modal-open{display: flex; visibility: visible; -webkit-transform: translate(-50%, -50%); -moz-transform: translate(-50%, -50%); -ms-transform: translate(-50%, -50%); -o-transform: translate(-50%, -50%); transform: translate(-50%, -50%); top: 50%; left: 50%; transition: all 1s ease;}.wcc-modal{box-shadow: 0 32px 68px rgba(0, 0, 0, 0.3); margin: 0 auto; position: fixed; max-width: 100%; background: #ffffff; top: 50%; box-sizing: border-box; border-radius: 6px; z-index: 999999999; color: #212121; -webkit-transform: translate(-50%, 100%); -moz-transform: translate(-50%, 100%); -ms-transform: translate(-50%, 100%); -o-transform: translate(-50%, 100%); transform: translate(-50%, 100%); visibility: hidden; transition: all 0s ease;}.wcc-preference-center{max-height: 79vh; overflow: hidden; width: 845px; overflow: hidden; flex: 1 1 0; display: flex; flex-direction: column; border-radius: 6px;}.wcc-preference-header{display: flex; align-items: center; justify-content: space-between; padding: 22px 24px; border-bottom: 1px solid;}.wcc-preference-header .wcc-preference-title{font-size: 18px; font-weight: 700; line-height: 24px;}.wcc-google-privacy-url a {text-decoration:none;color: #1863dc;cursor:pointer;} .wcc-preference-header .wcc-btn-close{margin: 0; cursor: pointer; vertical-align: middle; padding: 0; background: none; border: none; width: auto; height: auto; min-height: 0; line-height: 0; text-shadow: none; box-shadow: none;}.wcc-preference-header .wcc-btn-close img{margin: 0; height: 10px; width: 10px;}.wcc-preference-body-wrapper{padding: 0 24px; flex: 1; overflow: auto; box-sizing: border-box;}.wcc-preference-content-wrapper,.wcc-gpc-wrapper .wcc-gpc-desc,.wcc-google-privacy-policy{font-size: 14px; line-height: 24px; font-weight: 400; padding: 12px 0;}.wcc-preference-content-wrapper{border-bottom: 1px solid;}.wcc-preference-content-wrapper img{height: 25px; width: 25px;}.wcc-preference-content-wrapper .wcc-show-desc-btn{font-size: 14px; font-family: inherit; color: #1863dc; text-decoration: none; line-height: 24px; padding: 0; margin: 0; white-space: nowrap; cursor: pointer; background: transparent; border-color: transparent; text-transform: none; min-height: 0; text-shadow: none; box-shadow: none;}.wcc-accordion-wrapper{margin-bottom: 10px;}.wcc-accordion{border-bottom: 1px solid;}.wcc-accordion:last-child{border-bottom: none;}.wcc-accordion .wcc-accordion-item{display: flex; margin-top: 10px;}.wcc-accordion .wcc-accordion-body{display: none;}.wcc-accordion.wcc-accordion-active .wcc-accordion-body{display: block; padding: 0 22px; margin-bottom: 16px;}.wcc-accordion-header-wrapper{cursor: pointer; width: 100%;}.wcc-accordion-item .wcc-accordion-header{display: flex; justify-content: space-between; align-items: center;}.wcc-accordion-header .wcc-accordion-btn{font-size: 16px; font-family: inherit; color: #212121; line-height: 24px; background: none; border: none; font-weight: 700; padding: 0; margin: 0; cursor: pointer; text-transform: none; min-height: 0; text-shadow: none; box-shadow: none;}.wcc-accordion-header .wcc-always-active{color: #008000; font-weight: 600; line-height: 24px; font-size: 14px;}.wcc-accordion-header-des{font-size: 14px; line-height: 24px; margin: 10px 0 16px 0;}.wcc-accordion-chevron{margin-right: 22px; position: relative; cursor: pointer;}.wcc-accordion-chevron-hide{display: none;}.wcc-accordion .wcc-accordion-chevron i::before{content: \"\"; position: absolute; border-right: 1.4px solid; border-bottom: 1.4px solid; border-color: inherit; height: 6px; width: 6px; -webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg); transition: all 0.2s ease-in-out; top: 8px;}.wcc-accordion.wcc-accordion-active .wcc-accordion-chevron i::before{-webkit-transform: rotate(45deg); -moz-transform: rotate(45deg); -ms-transform: rotate(45deg); -o-transform: rotate(45deg); transform: rotate(45deg);}.wcc-audit-table{background: #f4f4f4; border-radius: 6px;}.wcc-audit-table .wcc-empty-cookies-text{color: inherit; font-size: 12px; line-height: 24px; margin: 0; padding: 10px;}.wcc-audit-table .wcc-cookie-des-table{font-size: 12px; line-height: 24px; font-weight: normal; padding: 15px 10px; border-bottom: 1px solid; border-bottom-color: inherit; margin: 0;}.wcc-audit-table .wcc-cookie-des-table:last-child{border-bottom: none;}.wcc-audit-table .wcc-cookie-des-table li{list-style-type: none; display: flex; padding: 3px 0;}.wcc-audit-table .wcc-cookie-des-table li:first-child{padding-top: 0;}.wcc-cookie-des-table li div:first-child{width: 100px; font-weight: 600; word-break: break-word; word-wrap: break-word;}.wcc-cookie-des-table li div:last-child{flex: 1; word-break: break-word; word-wrap: break-word; margin-left: 8px;}.wcc-footer-shadow{display: block; width: 100%; height: 40px; background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #ffffff 100%); position: absolute; bottom: calc(100% - 1px);}.wcc-footer-wrapper{position: relative;}.wcc-prefrence-btn-wrapper{display: flex; flex-wrap: wrap; align-items: center; justify-content: center; padding: 22px 24px; border-top: 1px solid;}.wcc-prefrence-btn-wrapper .wcc-btn{flex: auto; max-width: 100%; text-shadow: none; box-shadow: none;}.wcc-btn-preferences{color: #1863dc; background: transparent; border: 2px solid #1863dc;}.wcc-preference-header,.wcc-preference-body-wrapper,.wcc-preference-content-wrapper,.wcc-accordion-wrapper,.wcc-accordion,.wcc-accordion-wrapper,.wcc-footer-wrapper,.wcc-prefrence-btn-wrapper{border-color: inherit;}@media (max-width: 845px){.wcc-modal{max-width: calc(100% - 16px);}}@media (max-width: 576px){.wcc-modal{max-width: 100%;}.wcc-preference-center{max-height: 100vh;}.wcc-prefrence-btn-wrapper{flex-direction: column;}.wcc-accordion.wcc-accordion-active .wcc-accordion-body{padding-right: 0;}.wcc-prefrence-btn-wrapper .wcc-btn{width: 100%; margin: 10px 0 0 0;}.wcc-prefrence-btn-wrapper .wcc-btn-reject{order: 3;}.wcc-prefrence-btn-wrapper .wcc-btn-accept{order: 1; margin-top: 0;}.wcc-prefrence-btn-wrapper .wcc-btn-preferences{order: 2;}}@media (max-width: 425px){.wcc-accordion-chevron{margin-right: 15px;}.wcc-notice-btn-wrapper{margin-top: 0;}.wcc-accordion.wcc-accordion-active .wcc-accordion-body{padding: 0 15px;}}@media (max-width: 352px){.wcc-preference-header .wcc-preference-title{font-size: 16px;}.wcc-preference-header{padding: 16px 24px;}.wcc-preference-content-wrapper *, .wcc-accordion-header-des *{font-size: 12px;}.wcc-preference-content-wrapper, .wcc-preference-content-wrapper .wcc-show-more, .wcc-accordion-header .wcc-always-active, .wcc-accordion-header-des, .wcc-preference-content-wrapper .wcc-show-desc-btn, .wcc-notice-des a.wcc-policy{font-size: 12px;}.wcc-accordion-header .wcc-accordion-btn{font-size: 14px;}}.wcc-switch{display: flex;}.wcc-switch input[type=\"checkbox\"]{position: relative; width: 44px; height: 24px; margin: 0; background: #d0d5d2; -webkit-appearance: none; border-radius: 50px; cursor: pointer; outline: 0; border: none; top: 0;}.wcc-switch input[type=\"checkbox\"]:checked{background: #1863dc;}.wcc-switch input[type=\"checkbox\"]:before{position: absolute; content: \"\"; height: 20px; width: 20px; left: 2px; bottom: 2px; border-radius: 50%; background-color: white; -webkit-transition: 0.4s; transition: 0.4s; margin: 0;}.wcc-switch input[type=\"checkbox\"]:after{display: none;}.wcc-switch input[type=\"checkbox\"]:checked:before{-webkit-transform: translateX(20px); -ms-transform: translateX(20px); transform: translateX(20px);}@media (max-width: 425px){.wcc-switch input[type=\"checkbox\"]{width: 38px; height: 21px;}.wcc-switch input[type=\"checkbox\"]:before{height: 17px; width: 17px;}.wcc-switch input[type=\"checkbox\"]:checked:before{-webkit-transform: translateX(17px); -ms-transform: translateX(17px); transform: translateX(17px);}}.wcc-consent-bar .wcc-banner-btn-close{position: absolute; right: 10px; top: 8px; background: none; border: none; cursor: pointer; padding: 0; margin: 0; min-height: 0; line-height: 0; height: auto; width: auto; text-shadow: none; box-shadow: none;}.wcc-consent-bar .wcc-banner-btn-close img{height: 10px; width: 10px; margin: 0;}.wcc-notice-group{font-size: 14px; line-height: 24px; font-weight: 400; color: #212121;}.wcc-notice-btn-wrapper .wcc-btn-do-not-sell{font-size: 14px; line-height: 24px; padding: 6px 0; margin: 0; font-weight: 500; background: none; border-radius: 2px; border: none; white-space: nowrap; cursor: pointer; text-align: left; color: #1863dc; background: transparent; border-color: transparent; box-shadow: none; text-shadow: none;}.wcc-consent-bar .wcc-banner-btn-close:focus-visible,.wcc-notice-btn-wrapper .wcc-btn-do-not-sell:focus-visible,.wcc-opt-out-btn-wrapper .wcc-btn:focus-visible,.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox:focus-visible{outline: 2px solid #1863dc; outline-offset: 2px;}@media (max-width: 440px){.wcc-consent-container{width: 100%;}}@media (max-width: 352px){.wcc-notice-des a.wcc-policy, .wcc-notice-btn-wrapper .wcc-btn-do-not-sell{font-size: 12px;}}.wcc-opt-out-wrapper{padding: 12px 0;}.wcc-opt-out-wrapper .wcc-opt-out-checkbox-wrapper{display: flex; align-items: center;}.wcc-opt-out-checkbox-wrapper .wcc-opt-out-checkbox-label{font-size: 16px; font-weight: 700; line-height: 24px; margin: 0 0 0 12px; cursor: pointer;}.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox{background-color: #ffffff; border: 1px solid black; width: 20px; height: 18.5px; margin: 0; -webkit-appearance: none; position: relative; display: flex; align-items: center; justify-content: center; border-radius: 2px; cursor: pointer;}.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox:checked{background-color: #1863dc; border: none;}.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox:checked::after{left: 6px; bottom: 4px; width: 7px; height: 13px; border: solid #ffffff; border-width: 0 3px 3px 0; border-radius: 2px; -webkit-transform: rotate(45deg); -ms-transform: rotate(45deg); transform: rotate(45deg); content: \"\"; position: absolute; box-sizing: border-box;}.wcc-opt-out-checkbox-wrapper.wcc-disabled .wcc-opt-out-checkbox-label,.wcc-opt-out-checkbox-wrapper.wcc-disabled input[type=\"checkbox\"].wcc-opt-out-checkbox{cursor: no-drop;}.wcc-gpc-wrapper{margin: 0 0 0 32px;}.wcc-footer-wrapper .wcc-opt-out-btn-wrapper{display: flex; flex-wrap: wrap; align-items: center; justify-content: center; padding: 22px 24px;}.wcc-opt-out-btn-wrapper .wcc-btn{flex: auto; max-width: 100%; text-shadow: none; box-shadow: none;}.wcc-opt-out-btn-wrapper .wcc-btn-cancel{border: 1px solid #dedfe0; background: transparent; color: #858585;}.wcc-opt-out-btn-wrapper .wcc-btn-confirm{background: #1863dc; color: #ffffff; border: 1px solid #1863dc;}@media (max-width: 352px){.wcc-opt-out-checkbox-wrapper .wcc-opt-out-checkbox-label{font-size: 14px;}.wcc-gpc-wrapper .wcc-gpc-desc, .wcc-gpc-wrapper .wcc-gpc-desc *{font-size: 12px;}.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox{width: 16px; height: 16px;}.wcc-opt-out-checkbox-wrapper input[type=\"checkbox\"].wcc-opt-out-checkbox:checked::after{left: 5px; bottom: 4px; width: 3px; height: 9px;}.wcc-gpc-wrapper{margin: 0 0 0 28px;}}.video-placeholder-youtube{background-size: 100% 100%; background-position: center; background-repeat: no-repeat; background-color: #b2b0b059; position: relative; display: flex; align-items: center; justify-content: center; max-width: 100%;}.video-placeholder-text-youtube{text-align: center; align-items: center; padding: 10px 16px; background-color: #000000cc; color: #ffffff; border: 1px solid; border-radius: 2px; cursor: pointer;}.video-placeholder-normal{background-image: url(\"\/wp-content\/plugins\/webtoffee-cookie-consent\/lite\/frontend\/images\/placeholder.svg\"); background-size: 80px; background-position: center; background-repeat: no-repeat; background-color: #b2b0b059; position: relative; display: flex; align-items: flex-end; justify-content: center; max-width: 100%;}.video-placeholder-text-normal{align-items: center; padding: 10px 16px; text-align: center; border: 1px solid; border-radius: 2px; cursor: pointer;}.wcc-rtl{direction: rtl; text-align: right;}.wcc-rtl .wcc-banner-btn-close{left: 9px; right: auto;}.wcc-rtl .wcc-notice-btn-wrapper .wcc-btn:last-child{margin-right: 8px;}.wcc-rtl .wcc-notice-btn-wrapper .wcc-btn:first-child{margin-right: 0;}.wcc-rtl .wcc-notice-btn-wrapper{margin-left: 0; margin-right: 15px;}.wcc-rtl .wcc-prefrence-btn-wrapper .wcc-btn{margin-right: 8px;}.wcc-rtl .wcc-prefrence-btn-wrapper .wcc-btn:first-child{margin-right: 0;}.wcc-rtl .wcc-accordion .wcc-accordion-chevron i::before{border: none; border-left: 1.4px solid; border-top: 1.4px solid; left: 12px;}.wcc-rtl .wcc-accordion.wcc-accordion-active .wcc-accordion-chevron i::before{-webkit-transform: rotate(-135deg); -moz-transform: rotate(-135deg); -ms-transform: rotate(-135deg); -o-transform: rotate(-135deg); transform: rotate(-135deg);}@media (max-width: 768px){.wcc-rtl .wcc-notice-btn-wrapper{margin-right: 0;}}@media (max-width: 576px){.wcc-rtl .wcc-notice-btn-wrapper .wcc-btn:last-child{margin-right: 0;}.wcc-rtl .wcc-prefrence-btn-wrapper .wcc-btn{margin-right: 0;}.wcc-rtl .wcc-accordion.wcc-accordion-active .wcc-accordion-body{padding: 0 22px 0 0;}}@media (max-width: 425px){.wcc-rtl .wcc-accordion.wcc-accordion-active .wcc-accordion-body{padding: 0 15px 0 0;}}.wcc-rtl .wcc-opt-out-btn-wrapper .wcc-btn{margin-right: 12px;}.wcc-rtl .wcc-opt-out-btn-wrapper .wcc-btn:first-child{margin-right: 0;}.wcc-rtl .wcc-opt-out-checkbox-wrapper .wcc-opt-out-checkbox-label{margin: 0 12px 0 0;}"}};
var _wccApi = {"base":"https:\/\/www.sliderrevolution.com\/wp-json\/wcc\/v1\/","nonce":"9cfbc14619"};
var _wccGCMConfig = {"_mode":"advanced","_urlPassthrough":"1","_debugMode":"","_redactData":"","_regions":[{"region":["ALL"],"analytics_storage":"Granted","ad_storage":"Denied","ad_user_data":"Denied","ad_personalization":"Denied","functionality_storage":"Granted","personalization_storage":"Denied","security_storage":"Granted"}],"_wccBypass":"","wait_for_update":"500","_isGTMTemplate":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/webtoffee-cookie-consent/lite/frontend/js/script.min.js?ver=3.4.3" id="webtoffee-cookie-consent-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/webtoffee-cookie-consent/lite/frontend/js/gcm.min.js?ver=3.4.3" id="webtoffee-cookie-consent-gcm-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/lordicon-interactive-icons/dist/element.js?ver=1.0.0" id="lordicon-element-js-js"></script>
<script type="text/javascript" id="tp-tools-js-before">
/* <![CDATA[ */
window.ESG ??={};ESG.E ??={};ESG.E.site_url='https://www.sliderrevolution.com';ESG.E.plugin_url='https://www.sliderrevolution.com/wp-content/plugins/essential-grid/';ESG.E.ajax_url='https://www.sliderrevolution.com/wp-admin/admin-ajax.php';ESG.E.nonce='a70631f7a4';ESG.E.tptools=false;ESG.E.waitTptFunc ??=[];ESG.F ??={};ESG.F.waitTpt=() =>{if ( typeof jQuery==='undefined' ||!window?._tpt?.regResource ||!ESG?.E?.plugin_url ||(!ESG.E.tptools && !window?.SR7?.E?.plugin_url) ) return setTimeout(ESG.F.waitTpt,29);if (!window._tpt.gsap) window._tpt.regResource({id:'tpgsap',url:ESG.E.tptools && ESG.E.plugin_url+'/public/assets/js/libs/tpgsap.js' ||SR7.E.plugin_url + 'public/js/libs/tpgsap.js'});_tpt.checkResources(['tpgsap']).then(() =>{if (window.tpGS && !_tpt?.Back){_tpt.eases=tpGS.eases;Object.keys(_tpt.eases).forEach((e) => {_tpt[e] ===undefined && (_tpt[e]=tpGS[e])});}ESG.E.waitTptFunc.forEach((f) =>{typeof f ==='function' && f();});ESG.E.waitTptFunc=[];});}
/* ]]> */
</script>
<script type="text/javascript" src="//www.sliderrevolution.com/wp-content/plugins/revslider/public/js/libs/tptools.js?ver=6.7.37" id="tp-tools-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="//www.sliderrevolution.com/wp-content/plugins/revslider/public/js/sr7.js?ver=6.7.37" id="sr7-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="plvt-view-transitions-js-after">
/* <![CDATA[ */
window.plvtInitViewTransitions=n=>{if(!window.navigation||!("CSSViewTransitionRule"in window))return void window.console.warn("View transitions not loaded as the browser is lacking support.");const t=(t,o,i)=>{const e=n.animations||{};return[...e[t].useGlobalTransitionNames?Object.entries(n.globalTransitionNames||{}).map((([n,t])=>[o.querySelector(n),t])):[],...e[t].usePostTransitionNames&&i?Object.entries(n.postTransitionNames||{}).map((([n,t])=>[i.querySelector(n),t])):[]]},o=async(n,t)=>{for(const[t,o]of n)t&&(t.style.viewTransitionName=o);await t;for(const[t]of n)t&&(t.style.viewTransitionName="")},i=()=>n.postSelector?document.querySelector(n.postSelector):null,e=t=>{if(!n.postSelector)return null;const o=(i=n.postSelector,e='a[href="'+t+'"]',i.split(",").map((n=>n.trim()+" "+e)).join(","));var i,e;const s=document.querySelector(o);return s?s.closest(n.postSelector):null};window.addEventListener("pageswap",(n=>{if(n.viewTransition){const s="default";let a;n.viewTransition.types.add(s),document.body.classList.contains("single")?a=t(s,document.body,i()):(document.body.classList.contains("home")||document.body.classList.contains("archive"))&&(a=t(s,document.body,e(n.activation.entry.url))),a&&o(a,n.viewTransition.finished)}})),window.addEventListener("pagereveal",(n=>{if(n.viewTransition){const s="default";let a;n.viewTransition.types.add(s),document.body.classList.contains("single")?a=t(s,document.body,i()):(document.body.classList.contains("home")||document.body.classList.contains("archive"))&&(a=t(s,document.body,window.navigation.activation.from?e(window.navigation.activation.from.url):null)),a&&o(a,n.viewTransition.ready)}}))};
plvtInitViewTransitions( {"postSelector":".wp-block-post.post, article.post, body.single main","globalTransitionNames":{"header":"header","main":"main"},"postTransitionNames":{".wp-block-post-title, .entry-title":"post-title",".wp-post-image":"post-thumbnail",".wp-block-post-content, .entry-content":"post-content"},"animations":{"default":{"useGlobalTransitionNames":true,"usePostTransitionNames":true}}} )
/* ]]> */
</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-B9KTVHW30V"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-B9KTVHW30V');
</script>

        <style>
          @font-face{font-family:"Material Icons"; font-style:normal; font-weight:400; src:url(//fonts.gstatic.com/s/materialicons/v41/flUhRq6tzZclQEJ-Vdg-IuiaDsNcIhQ8tQ.woff2) format("woff2")}rs-module .material-icons{font-family:"Material Icons"; font-weight:normal; font-style:normal;font-size:inherit; display:inline-block;  text-transform:none; letter-spacing:normal; word-wrap:normal; white-space:nowrap; direction:ltr; vertical-align:top; line-height:inherit;  font-feature-settings:"liga"; -webkit-font-smoothing:antialiased; text-rendering:optimizeLegibility; -moz-osx-font-smoothing:grayscale}
          .newsletter-flex {display: flex; align-items: flex-start}
          .mce_inline_error {display: none}
          .mce_has_error .mce_inline_error {display: block}
          @media (max-width: 1023px) {.newsletter-flex {flex-direction: column}.mc-field-group {width: 100% !important;margin-right: 0 !important;margin-bottom: 20px !important;}}
        </style>
      <style>:root {
			--lazy-loader-animation-duration: 300ms;
		}
		  
		.lazyload {
	display: block;
}

.lazyload,
        .lazyloading {
			opacity: 0;
		}


		.lazyloaded {
			opacity: 1;
			transition: opacity 300ms;
			transition: opacity var(--lazy-loader-animation-duration);
		}</style><noscript><style>.lazyload { display: none; } .lazyload[class*="lazy-loader-background-element-"] { display: block; opacity: 1; }</style></noscript>
<script type="text/javascript"> (function(a,b,c,d,e,f,g){e['ire_o']=c;e[c]=e[c]||function(){(e[c].a=e[c].a||[]).push(arguments)};f=d.createElement(b);g=d.getElementsByTagName(b)[0];f.async=1;f.src=a;g.parentNode.insertBefore(f,g);})('https://d.impactradius-event.com/A2559068-91e7-45ee-a82f-39239d736b041.js','script','ire',document,window);</script>
<meta name="generator" content="view-transitions 1.1.1">
<style id="wcc-style-inline">[data-tag]{visibility:hidden;}</style>		<style type="text/css">
						.site-title,
			.site-description {
				position: absolute;
				clip: rect(1px, 1px, 1px, 1px);
			}

						</style>
		<style type="text/css" id="custom-background-css">
body.custom-background { background-color: #ffffff; }
</style>
	

<meta name="generator" content="Powered by Slider Revolution 6.7.37 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://www.sliderrevolution.com/wp-content/uploads/2020/05/cropped-rsicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.sliderrevolution.com/wp-content/uploads/2020/05/cropped-rsicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.sliderrevolution.com/wp-content/uploads/2020/05/cropped-rsicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.sliderrevolution.com/wp-content/uploads/2020/05/cropped-rsicon-270x270.png" />
<script>
	window._tpt			??= {};
	window.SR7			??= {};
	_tpt.R				??= {};
	_tpt.R.fonts		??= {};
	_tpt.R.fonts.customFonts??= {};
	SR7.devMode			=  true;
	SR7.F 				??= {};
	SR7.G				??= {};
	SR7.LIB				??= {};
	SR7.E				??= {};
	SR7.E.gAddons		??= {};
	SR7.E.php 			??= {};
	SR7.E.nonce			= 'ab2621b576';
	SR7.E.ajaxurl		= 'https://www.sliderrevolution.com/wp-admin/admin-ajax.php';
	SR7.E.resturl		= 'https://www.sliderrevolution.com/wp-json/';
	SR7.E.slug_path		= 'revslider/revslider.php';
	SR7.E.slug			= 'revslider';
	SR7.E.plugin_url	= 'https://www.sliderrevolution.com/wp-content/plugins/revslider/';
	SR7.E.wp_plugin_url = 'https://www.sliderrevolution.com/wp-content/plugins/';
	SR7.E.revision		= '6.7.37';
	SR7.E.fontBaseUrl	= '';
	SR7.G.breakPoints 	= [1500,1240,778,480];
	SR7.G.fSUVW 		= false;
	SR7.E.modules 		= ['module','page','slide','layer','draw','animate','srtools','canvas','defaults','carousel','navigation','media','modifiers','migration'];
	SR7.E.libs 			= ['THREE','WEBGL','tpgsap'];
	SR7.E.css 			= ['csslp','cssbtns','cssfilters','cssnav','cssmedia'];
	SR7.E.resources		= {};
	SR7.E.ytnc			= false;
	SR7.JSON			??= {};
/*! Slider Revolution 7.0 - Page Processor */
(function() {
	"use strict";

	window.SR7 ??= {};
	window._tpt ??=  {};

	SR7.version = "Slider Revolution 6.7.16"

	_tpt.getMobileZoom = () => !_tpt.is_mobile ? 1 : document.documentElement.clientWidth / window.innerWidth;

	//Get Window Dimensions, and Update if required
	_tpt.getWinDim = function(type) {		
		//Read the Scrollbar Size (if 0 -> no Scrollbar exist)		
		_tpt.screenHeightWithUrlBar ??= window.innerHeight;
		let modal = (SR7.F?.modal?.visible && SR7.M[SR7.F.module.getIdByAlias(SR7.F.modal.requested)]);		
		_tpt.scrollBar = window.innerWidth !== document.documentElement.clientWidth || (modal && (window.innerWidth!==modal.c.module.clientWidth));
		_tpt.winW = _tpt.getMobileZoom() * window.innerWidth - (_tpt.scrollBar || type=="prepare" ? _tpt.scrollBarW??_tpt.mesureScrollBar() : 0);
		_tpt.winH = _tpt.getMobileZoom() * window.innerHeight;		
		_tpt.winWAll = /*modal ? modal.c.module.clientWidth :*/ document.documentElement.clientWidth;
	}
	
	// FIND CURRENT RESOPNSIVE LEVEL
	_tpt.getResponsiveLevel = function(breakpoints,id) {		
		// Force viewport width (CSS-like, includes scrollbars)
		if (SR7.G.fSUVW) return _tpt.closestGE(breakpoints, window.innerWidth);					
		// Default: content width (unchanged)
		return _tpt.closestGE(breakpoints,_tpt.winWAll);		
	},


	//Messure Scrollbar
	_tpt.mesureScrollBar = function() {				
		// Create the measurement node
		let scrollDiv = document.createElement("div");
		scrollDiv.className = "RSscrollbar-measure";
		scrollDiv.style.width = "100px";
		scrollDiv.style.height = "100px";
		scrollDiv.style.overflow = "scroll";
		scrollDiv.style.position = "absolute";
		scrollDiv.style.top = "-9999px";
		document.body.appendChild(scrollDiv);
		// Get the scrollbar width
		_tpt.scrollBarW = scrollDiv.offsetWidth - scrollDiv.clientWidth;
		// Delete the DIV
		document.body.removeChild(scrollDiv);
		return _tpt.scrollBarW;
	};


	_tpt.loadCSS = async function(url, resourceId, font) {
		if (font) _tpt.R.fonts.required[resourceId].status = 1; else  {
			_tpt.R[resourceId] ??= {};
			_tpt.R[resourceId].status = 1;
		}
		return new Promise((resolve, reject) => {
			if (!_tpt.isStylesheetLoaded(url)) {
				const link = document.createElement('link');
				link.rel = 'stylesheet';
				let propName = 'ty' + 'pe';
				let a = "text";
				let b = "css";
				link[propName] = a + '/' + b;
				link.href = url;				
				link.onload = () => {
					if (font) _tpt.R.fonts.required[resourceId].status = 2; else _tpt.R[resourceId].status = 2;
					resolve();
				};
				link.onerror = () => {
					if (font) _tpt.R.fonts.required[resourceId].status = 3; else _tpt.R[resourceId].status = 3;
					reject(new Error(`Failed to load CSS: ${url}`));
				};
				document.head.appendChild(link);
			} else {
				if (font) _tpt.R.fonts.required[resourceId].status = 2; else _tpt.R[resourceId].status = 2;
				resolve();
			}
		});
	};


	/**
	 * Create a HTML Container with tag, data, class, id
	 * @param {*} parent  - The Javascript Element where the Container should be appended
	 * @param {*} options 
	 * @returns a HTML Container with all required attributes
	 */
	_tpt.addContainer = function(options) {
		const { tag = 'div', id, class: classList, datas , textContent, iHTML} = options;
		const element = document.createElement(tag);

		if (id && id!=="") element.id = id;
		if (classList && classList!=="") element.className = classList;		
		if (datas) for (const [key, value] of Object.entries(datas)) {			
			if (key=="style") 			
				element.style.cssText = value; 
		 	else 
				element.setAttribute(`data-${key}`, value);
			
		}
		if (textContent) element.textContent = textContent;
		if (iHTML) element.innerHTML = iHTML;

		return element;
	}

	/**
	 * To avoid multiple inserts in DOM add first elements into a Document Fragement, and add it at the end to the DOM
	 * Usage: var collect = _tpt.collector();    collect.add({tag: class: datas: })   and finall apend: collect.append(parent);
	 * @returns a Constructor for new Instances. This will collect the added Elements before appending it to the required parent
	 */
	_tpt.collector = function() {
		return {
			fragment: new DocumentFragment(),
		
			add(options) {
				var el = _tpt.addContainer(options);			  
				this.fragment.appendChild(el);			  
				return el;
			},
					
			append(parent) {				
				parent.appendChild(this.fragment);
			}
		};
	}
	
	_tpt.isStylesheetLoaded = function(url) {
		// Remove the query string from the URL for comparison
		let baseUrl = url.split('?')[0];
		return Array.from(document.querySelectorAll('link[rel="stylesheet"], link[rel="preload"]')).some(link => link.href.split('?')[0] === baseUrl);
	};

	_tpt.preloader = {
		requests: new Map(),  // store references for preloaders by container
		preloaderTemplates: new Map(),  // cache for preloader templates

		show: function(container, settings) {			
			if (!settings || !container) return;
			const { type, color } = settings;
			if (type<0 || type=="off") return;

			const preloaderId = `preloader_${type}`;			
			let preloaderTemplate = this.preloaderTemplates.get(preloaderId);			
			if (!preloaderTemplate) {
				// Load the preloader template if it doesn't exist
				preloaderTemplate = this.build(type, color);
				this.preloaderTemplates.set(preloaderId, preloaderTemplate);
			}
			if (!this.requests.has(container)) this.requests.set(container, { count: 0 });
			
			const request = this.requests.get(container);
			clearTimeout(request.timer);
			request.count++;

			if (request.count === 1) 
				request.timer = setTimeout(() => {
					request.preloaderClone = preloaderTemplate.cloneNode(true);
					if (request.anim) request.anim.kill();
					if (_tpt.gsap!==undefined) 
						request.anim = _tpt.gsap.fromTo(request.preloaderClone, 1, { opacity: 0 }, { opacity: 1});
					else
					request.preloaderClone.classList.add('sr7-fade-in');
					container.appendChild(request.preloaderClone);
				}, 150);
			
		},

		hide: function(container) {
			if (!this.requests.has(container)) return;
			
			const request = this.requests.get(container);			
			request.count--;
			if (request.count < 0) request.count = 0;
			if (request.anim) request.anim.kill();			
			if (request.count === 0) {
				clearTimeout(request.timer);				
				if (request.preloaderClone) {
					request.preloaderClone.classList.remove('sr7-fade-in');
					request.anim = _tpt.gsap.to(request.preloaderClone, 0.3, { opacity: 0 , onComplete:function() {
						request.preloaderClone.remove();
					}});					
				}
			}
		},

		state : function(container) {
			if (!this.requests.has(container)) return false;
			const request = this.requests.get(container);
			return request.count > 0;
		},

		build: (preLoader, color = '#ffffff', eclass="") => {
			if (preLoader<0 || preLoader === "off") return null;
			const preLoaderType = parseInt(preLoader);
			preLoader = "prlt"+preLoaderType;
			if (isNaN(preLoaderType)) return null;			
						
			_tpt.loadCSS(SR7.E.plugin_url+'public/css/preloaders/t'+preLoaderType+".css", "preloader_"+preLoader);
			if (isNaN(preLoaderType) || preLoaderType < 6) {
				const aStyle = `background-color:${color}`;
				const ems = ((preLoaderType === 1 || preLoaderType == 2)) ? aStyle : '';
				const eds = ((preLoaderType === 3 || preLoaderType == 4)) ? aStyle : '';
				const collector = _tpt.collector();
				
				['dot1', 'dot2', 'bounce1', 'bounce2', 'bounce3'].forEach(className => 
					collector.add({ tag: 'div', class: className, datas: { style: eds } })
				);

				const container = _tpt.addContainer({ tag: 'sr7-prl', class: `${preLoader} ${eclass}`, datas: { style: ems } });
				collector.append(container);

				return container;

			} else {
				let spinHtml = {};
				if (preLoaderType === 7) {
					let clr;
					if (color.startsWith('#')) {
						clr = color.replace('#', '');
						clr = `rgba(${parseInt(clr.substring(0, 2), 16)}, ${parseInt(clr.substring(2, 4), 16)}, ${parseInt(clr.substring(4, 6), 16)}, `;
					} else if (color.startsWith('rgb')) {
						clr = color.slice(color.indexOf('(') + 1, color.lastIndexOf(')')).split(',').map(s => s.trim());
						clr = `rgba(${clr[0]}, ${clr[1]}, ${clr[2]}, `;
					}
					if (clr) {
						spinHtml.style = `border-top-color: ${clr}0.65); border-bottom-color: ${clr}0.15); border-left-color: ${clr}0.65); border-right-color: ${clr}0.15)`;
					}
				} else if (preLoaderType === 12) {
					spinHtml.style = `background:${color}`;
				}

				const numSpans = [10, 0, 4, 2, 5, 9, 0, 4, 4, 2];
				const totalSpans = numSpans[preLoaderType - 6];
				const collector = _tpt.collector();
				const innerc = collector.add({ tag: 'div', class: 'sr7-prl-inner', datas: spinHtml });

				Array.from({ length: totalSpans }).forEach(() => 
					innerc.appendChild(
						collector.add({ tag: 'span', datas: { style: `background:${color}` } })
					)						
				);

				
				
				const container = _tpt.addContainer({ tag: 'sr7-prl', class: `${preLoader} ${eclass}` });
				collector.append(container);
				return container;
			}
		}
	}


	SR7.preLoader = {
		show : (id,container) => {						
			if ((SR7.M[id]?.settings?.pLoader?.type??"off")==="off") return;			
			_tpt.preloader.show(container || SR7.M[id].c.module, SR7.M[id]?.settings?.pLoader??{color:'#fff',type:10});
		},
		hide : (id,container) => {
			if ((SR7.M[id]?.settings?.pLoader?.type??"off")==="off") return;
			_tpt.preloader.hide(container || SR7.M[id].c.module);
		},
		state : (id,container) => {
			return _tpt.preloader.state(container || SR7.M[id].c.module);
		}
	}	

	/**
     * Preset the Module Height before the DOM is fully loaded, inline by adding the Module Container. This will avoid the Page to jump in height as good as possible
     * @param {_} _  A row of settings printed by PHP. Details about the Module, id, cached Heights, heights, Breakpoints etc.
     * @returns 
     */
	_tpt.prepareModuleHeight = function(_) {		
		// Prepare Module Object Container		
		window.SR7.M ??=  {};        
		window.SR7.M[_.id] ??= {}
		if (_.googleFont=='ignore') SR7.E.ignoreGoogleFont = true;
		let M = window.SR7.M[_.id];
		//Messure 1 time the Scrollbar
		if (_tpt.scrollBarW==undefined) _tpt.mesureScrollBar();
		
		M.c ??=  {};        
		M.states ??=  {};
		M.settings ??=  {};
		M.settings.size ??=  {};		
		if (_.fixed) M.settings.fixed=true;
					
		//Collect Module DOM Container References
		M.c.module = document.querySelector('sr7-module#' + _.id);
		M.c.adjuster = M.c.module.getElementsByTagName('sr7-adjuster')[0];
		M.c.content = M.c.module.getElementsByTagName('sr7-content')[0];
		if (_.type=="carousel") M.c.carousel = M.c.content.getElementsByTagName('sr7-carousel')[0];
		if (M.c.module == null || M.c.module==undefined) return;
		if ((_.plType??"off"!=="off") && _.plColor) M.settings.pLoader = {type:_.plType,color:_.plColor};
		
		
		//Prepare the Start Height for the Module to avoid Jump and Flashes by Loading and first Rendering the Page
		if (_.plType!==undefined && _.plType!=="off" && (!SR7.preLoader.state(_.id) || !SR7.preLoader.state(_.id,M.c.module))) SR7.preLoader.show(_.id,M.c.module);
		
		
		if (!_tpt.winW) {
			_tpt.getWinDim("prepare");
			_tpt.getWinDim();
		} else _tpt.getWinDim();

		let modal = ""+M.c.module.dataset?.modal;
		if (modal=="modal" || modal=="true" || modal!=="undefined" && modal!=="false") return;
					
		//TODO - After Migration change Logic here
		M.settings.size.fullWidth = _.size.fullWidth;		
		
		M.LEV ??= _tpt.getResponsiveLevel(window.SR7.G.breakPoints,_.id);	
		_.vpt =  _tpt.fillArray(_.vpt,5);
		M.settings.vPort = _.vpt[M.LEV];
		
		//Default MobileSizes on Containers
		if (_.el!==undefined && _.el[4]=='720' && _.gh[4]!==_.el[4] && _.el[3] == '960' && _.gh[3]!==_.el[3] && _.el[2] == '768' && _.gh[2]!==_.el[2]) delete _.el;
		
		M.settings.size.height = _.el==undefined || _.el[M.LEV]==undefined || _.el[M.LEV]==0 || _.el[M.LEV]=="auto" ? _tpt.fillArray(_.gh,5,-1) : _tpt.fillArray(_.el,5,-1);
		
		M.settings.size.width = _tpt.fillArray(_.gw,5,-1);
		M.settings.size.minHeight = _tpt.fillArray(_.mh ?? [0],5,-1);
        M.cacheSize = {fullWidth:M.settings.size?.fullWidth, fullHeight:M.settings.size?.fullHeight};		

        if (_.off!==undefined) {			
			(_.off?.t??undefined) && (M.settings.size.m ??={}) && (M.settings.size.m.t = _.off.t);
			(_.off?.b??undefined) && (M.settings.size.m ??={}) && (M.settings.size.m.b = _.off.b);
			(_.off?.l??undefined) && (M.settings.size.p ??={}) && (M.settings.size.p.l = _.off.l);
			(_.off?.r??undefined) && (M.settings.size.p ??={}) && (M.settings.size.p.r = _.off.r);			
			M.offsetPrepared = true;
		}
        _tpt.updatePMHeight(_.id,_,true);
	};

    /**
     * Update the Prepared Container Height
     * @param {*} id 
     * @param {*} _ 
     * @param {*} first 
     * @returns 
     */
    _tpt.updatePMHeight = (id,_,first) => {
        let M = SR7.M[id];
        var pw =  M.settings.size.fullWidth ? _tpt.winW : M.c.module.parentNode.offsetWidth;
        pw = pw===0 || isNaN(pw) ? _tpt.winW : pw;		
		let w = M.settings.size.width[M.LEV] || M.settings.size.width[M.LEV++] || M.settings.size.width[M.LEV--] || pw;
		let h = M.settings.size.height[M.LEV] || M.settings.size.height[M.LEV++] || M.settings.size.height[M.LEV--] || 0;
		let mh = M.settings.size.minHeight[M.LEV] || M.settings.size.minHeight[M.LEV++] || M.settings.size.minHeight[M.LEV--] || 0;
		h = h=="auto" ? 0 : h;
		h = parseInt(h);
		//Set Module Width
		if (_.type!=="carousel") pw = pw-  (parseInt(_.onw??0) || 0); // If Vertical Outer Navigation used, calculation Base need to be reduced
		M.MP = (!M.settings.size.fullWidth && pw<w) || _tpt.winW<w ? Math.min(1,pw/w) : 1;		
		
		if(_.size.fullScreen || _.size.fullHeight) {
			let fho = parseInt(_.fho) || 0;
			let fhop = (""+_.fho).indexOf("%")>-1;
			_.newh =  _tpt.winH - (fhop ? (_tpt.winH * fho/100) : fho);
		 } else _.newh = M.MP * (Math.max(h,mh));	
		
		_.newh += (parseInt(_.onh ?? 0) || 0) + (parseInt(_.carousel?.pt) || 0) + (parseInt(_.carousel?.pb) || 0);
		//Scroll Based Freezed Timeline Adjustemen
		if (_.slideduration!==undefined) _.newh = Math.max(_.newh,parseInt(_.slideduration) / 3);	
		if (_.shdw) _tpt.buildShadow(_.id,_);								
		M.c.adjuster.style.height = _.newh+"px";
		M.c.module.style.height = _.newh+"px";
		M.c.content.style.height = _.newh+"px";								
		M.states.heightPrepared = true;		
		
		M.dims ??={};
		M.dims.moduleRect = M.c.module.getBoundingClientRect();
		M.c.content.style.left = "-" + M.dims.moduleRect.left + "px";

		if (!M.settings.size.fullWidth) {			
            if (first) requestAnimationFrame(() => {if (pw!==M.c.module.parentNode.offsetWidth)  _tpt.updatePMHeight(_.id,_);});
			_tpt.bgStyle(_.id,_,window.innerWidth == _tpt.winW, true);
            return;
        } 
		else _tpt.bgStyle(_.id,_,window.innerWidth == _tpt.winW, true);		
		requestAnimationFrame(function() {            
            if (first) requestAnimationFrame(() => {if (pw!==M.c.module.parentNode.offsetWidth)  _tpt.updatePMHeight(_.id,_);});
		});

		//Early Resizer Listener, gets removed later
		if (!M.earlyResizerFunction) {
			M.earlyResizerFunction = function() {
				requestAnimationFrame(function() {
					_tpt.getWinDim();
					_tpt.moduleDefaults(_.id, _);					
					_tpt.updateSlideBg(id, true);
				});
			};
			window.addEventListener("resize", M.earlyResizerFunction);
		}
    }

	_tpt.buildShadow = function(id,_) {
		let M = SR7.M[id];
		//Create Shadow
		if (M.c.shadow==undefined) {
			M.c.shadow = document.createElement("sr7-module-shadow");	
			M.c.shadow.classList.add("sr7-shdw-"+_.shdw);		
			M.c.content.appendChild(M.c.shadow);
		}
		//M.c.shadow.style.opacity=_.shadow.opacity;
	
	}
	/**
	* Style the Module Copntainer, only Visual Styling, no Size or Dimension update
	* @param {id} id - The id of the Module need to be styled     
	*/
	_tpt.bgStyle = async (id,_,early,preparing,forceadd) => {
		const M = SR7.M[id];	
		_ = _ ?? M.settings;		
		//Fixed Position of Module
		if (_.fixed && !M.c.module.classList.contains("sr7-top-fixed")) {
			M.c.module.classList.add("sr7-top-fixed");	
			M.c.module.style.position="fixed";
			M.c.module.style.width="100%";				
			M.c.module.style.top="0px";
			M.c.module.style.left="0px";
			M.c.module.style.pointerEvents="none";
			M.c.module.style.zIndex=5000;
			M.c.content.style.pointerEvents="none";
		}
		if (M.c.bgcanvas==undefined) {			
			let bg = document.createElement("sr7-module-bg");			
			let _add = false;
			if (typeof (_?.bg?.color) == "string"  && _?.bg?.color.includes("{")) {					
				if (_tpt.gradient && _tpt.gsap) 
					_.bg.color = _tpt.gradient.convert(_.bg.color);					
				else {					
					try{						
						let ctemp = JSON.parse(_.bg.color);
						if (ctemp?.orig || ctemp?.string) _.bg.color = JSON.parse(_.bg.color);
					} catch(e) {					
						return;
					}
				}
			}
			
			let color = typeof (_?.bg?.color) == "string" ? (_?.bg?.color || "transparent") : _?.bg?.color?.string ?? _?.bg?.color?.orig ?? _?.bg?.color?.color ?? "transparent";			
			bg.style["background"+(String(color).includes("grad") ? "" : "Color")] = color;
			if (color!=="transparent" || forceadd) _add=true;
			if (M.offsetPrepared) bg.style.visibility = "hidden";
			if (_?.bg?.image?.src) {
				bg.style.backgroundImage = `url(${_?.bg?.image.src})`;
				bg.style.backgroundSize = (_.bg.image?.size??"")=="" ? "cover" : _.bg.image.size;
				bg.style.backgroundPosition = _.bg.image.position;
				bg.style.backgroundRepeat = _.bg.image.repeat=="" || _.bg.image.repeat==undefined ? "no-repeat" : _.bg.image.repeat;
				_add=true;
			}
			if (!_add) return;
			M.c.bgcanvas = bg;			
			if (_.size.fullWidth) bg.style.width = (_tpt.winW - (early && _tpt.winH<document.body.offsetHeight? _tpt.scrollBarW : 0))+"px";			
			else if (preparing) 
				bg.style.width = M.c.module.offsetWidth+"px";							
			if (_.sbt?.use??false)
				M.c.content.appendChild(M.c.bgcanvas);
			else
				M.c.module.appendChild(M.c.bgcanvas);						
		} 	
		M.c.bgcanvas.style.height = _.newh!==undefined ? /*((_.type=="carousel") ? parseInt(_.carousel?.pt??0) + parseInt(_.carousel?.pb??0) : 0) +*/ _.newh+"px" : ((_.type=="carousel" ? M.dims.module.h : M.dims.content.h) + "px");
		M.c.bgcanvas.style.left = (!early && (_.sbt?.use??false)) || M.c.bgcanvas.closest('SR7-CONTENT') ? "0px" : "-" +(M?.dims?.moduleRect?.left??0) + "px";
	},

	 _tpt.updateSlideBg = function(id,early) {
		const M = SR7.M[id];	
		let _ = M.settings;	
		if (!M?.c?.bgcanvas) return;
		if (_.size.fullWidth) M.c.bgcanvas.style.width = (_tpt.winW - (early && _tpt.winH<document.body.offsetHeight? _tpt.scrollBarW : 0))+"px";
			else if (preparing) M.c.bgcanvas.style.width = M.c.module.offsetWidth+"px";
		
	}
	//Set Module Defaults
	_tpt.moduleDefaults = (id,_) => {
		let M = SR7.M[id];
		// Get the position and width of the container relative to the viewport
		if (M== undefined || M.c==undefined || M.c.module==undefined) return;
		M.dims ??={};
		M.dims.moduleRect = M.c.module.getBoundingClientRect();
		M.c.content.style.left = "-" + M.dims.moduleRect.left + "px";
		M.c.content.style.width = (_tpt.winW -_tpt.scrollBarW)+"px"; 
		if (_.type=="carousel") M.c.module.style.overflow="visible";
		_tpt.bgStyle(id,_,window.innerWidth == _tpt.winW);
	}

	//TOOLS
	//Get Offset Scroll Position
	_tpt.getOffset = (el) => {
		var rect = el.getBoundingClientRect(),
			scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
			scrollTop = window.pageYOffset || document.documentElement.scrollTop;
		return { top: rect.top + scrollTop, left: rect.left + scrollLeft };		
	}

	//Tool to fill array with amount of elements needed based only current values
	_tpt.fillArray = function (a, l) {       
		let lkv,i;		
		a = Array.isArray(a) ? a : [a];		
		let b = Array(l);		
		let len = a.length;
		for (i=0;i<a.length;i++) {
			b[i+(l-len)] = a[i];
			if (lkv==undefined && a[i]!=="#") lkv = a[i];
		}
		for (let i = 0; i < l; i++)  {
			if (b[i] === undefined || b[i]=='#') b[i] = lkv;
			lkv = b[i];
		}				
		return b;
	}

	//Will give the Index of the Closest Greater or equal Number in the Array compared to v
	//If Number bigger than first Value , it will deliver "0", other way shifted the Index.  
	_tpt.closestGE = function(a, v) {		
		let minDiff = Number.MAX_VALUE;
		let minIndex = -1;
		for (let i = 0; i < a.length; i++)
			if ((a[i]-1) >= v && (a[i]-1) - v < minDiff) {				
				minDiff = (a[i]-1) - v;
				minIndex = i;
			}		
		return ++minIndex;
	} 
})();</script>

	<link rel="stylesheet" id="asp-basic" href="https://www.sliderrevolution.com/wp-content/cache/asp/style.basic-ho-is-po-no-da-au-se-is.css?mq=Y98z1C" media="all" /><style id='asp-instance-2'>div[id*='ajaxsearchpro2_'] div.asp_loader,div[id*='ajaxsearchpro2_'] div.asp_loader *{box-sizing:border-box !important;margin:0;padding:0;box-shadow:none}div[id*='ajaxsearchpro2_'] div.asp_loader{box-sizing:border-box;display:flex;flex:0 1 auto;flex-direction:column;flex-grow:0;flex-shrink:0;flex-basis:28px;max-width:100%;max-height:100%;align-items:center;justify-content:center}div[id*='ajaxsearchpro2_'] div.asp_loader-inner{width:100%;margin:0 auto;text-align:center;height:100%}@-webkit-keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}@keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}div[id*='ajaxsearchpro2_'] div.asp_ball-beat{height:20%}div[id*='ajaxsearchpro2_'] div.asp_ball-beat>div{background-color:rgba(28,9,80,0.25);width:20%;height:100%;margin-left:10%;display:block;float:left;border-radius:100%;-webkit-animation-fill-mode:both;animation-fill-mode:both;display:inline-block;-webkit-animation:ball-beat 0.7s 0s infinite linear;animation:ball-beat 0.7s 0s infinite linear;vertical-align:top}div[id*='ajaxsearchpro2_'] div.asp_ball-beat>div:nth-child(2n-1){-webkit-animation-delay:-0.35s !important;animation-delay:-0.35s !important}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_loader,div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_loader *{box-sizing:border-box !important;margin:0;padding:0;box-shadow:none}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_loader{box-sizing:border-box;display:flex;flex:0 1 auto;flex-direction:column;flex-grow:0;flex-shrink:0;flex-basis:28px;max-width:100%;max-height:100%;align-items:center;justify-content:center}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_loader-inner{width:100%;margin:0 auto;text-align:center;height:100%}@-webkit-keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}@keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_ball-beat{height:20%}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_ball-beat>div{background-color:rgba(28,9,80,0.25);width:20%;height:100%;margin-left:10%;display:block;float:left;border-radius:100%;-webkit-animation-fill-mode:both;animation-fill-mode:both;display:inline-block;-webkit-animation:ball-beat 0.7s 0s infinite linear;animation:ball-beat 0.7s 0s infinite linear;vertical-align:top}div[id*='ajaxsearchprores2_'] .asp_res_loader div.asp_ball-beat>div:nth-child(2n-1){-webkit-animation-delay:-0.35s !important;animation-delay:-0.35s !important}#ajaxsearchpro2_1 div.asp_loader,#ajaxsearchpro2_2 div.asp_loader,#ajaxsearchpro2_1 div.asp_loader *,#ajaxsearchpro2_2 div.asp_loader *{box-sizing:border-box !important;margin:0;padding:0;box-shadow:none}#ajaxsearchpro2_1 div.asp_loader,#ajaxsearchpro2_2 div.asp_loader{box-sizing:border-box;display:flex;flex:0 1 auto;flex-direction:column;flex-grow:0;flex-shrink:0;flex-basis:28px;max-width:100%;max-height:100%;align-items:center;justify-content:center}#ajaxsearchpro2_1 div.asp_loader-inner,#ajaxsearchpro2_2 div.asp_loader-inner{width:100%;margin:0 auto;text-align:center;height:100%}@-webkit-keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}@keyframes ball-beat{50%{opacity:0.2;-webkit-transform:scale(0.75);transform:scale(0.75)}100%{opacity:1;-webkit-transform:scale(1);transform:scale(1)}}#ajaxsearchpro2_1 div.asp_ball-beat,#ajaxsearchpro2_2 div.asp_ball-beat{height:20%}#ajaxsearchpro2_1 div.asp_ball-beat>div,#ajaxsearchpro2_2 div.asp_ball-beat>div{background-color:rgba(28,9,80,0.25);width:20%;height:100%;margin-left:10%;display:block;float:left;border-radius:100%;-webkit-animation-fill-mode:both;animation-fill-mode:both;display:inline-block;-webkit-animation:ball-beat 0.7s 0s infinite linear;animation:ball-beat 0.7s 0s infinite linear;vertical-align:top}#ajaxsearchpro2_1 div.asp_ball-beat>div:nth-child(2n-1),#ajaxsearchpro2_2 div.asp_ball-beat>div:nth-child(2n-1){-webkit-animation-delay:-0.35s !important;animation-delay:-0.35s !important}@-webkit-keyframes asp_an_fadeInDown{0%{opacity:0;-webkit-transform:translateY(-20px)}100%{opacity:1;-webkit-transform:translateY(0)}}@keyframes asp_an_fadeInDown{0%{opacity:0;transform:translateY(-20px)}100%{opacity:1;transform:translateY(0)}}.asp_an_fadeInDown{-webkit-animation-name:asp_an_fadeInDown;animation-name:asp_an_fadeInDown}div.asp_r.asp_r_2,div.asp_r.asp_r_2 *,div.asp_m.asp_m_2,div.asp_m.asp_m_2 *,div.asp_s.asp_s_2,div.asp_s.asp_s_2 *{-webkit-box-sizing:content-box;-moz-box-sizing:content-box;-ms-box-sizing:content-box;-o-box-sizing:content-box;box-sizing:content-box;border:0;border-radius:0;text-transform:none;text-shadow:none;box-shadow:none;text-decoration:none;text-align:left;letter-spacing:normal}div.asp_r.asp_r_2,div.asp_m.asp_m_2,div.asp_s.asp_s_2{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;-ms-box-sizing:border-box;-o-box-sizing:border-box;box-sizing:border-box}div.asp_r.asp_r_2,div.asp_r.asp_r_2 *,div.asp_m.asp_m_2,div.asp_m.asp_m_2 *,div.asp_s.asp_s_2,div.asp_s.asp_s_2 *{padding:0;margin:0}.wpdreams_clear{clear:both}.asp_w_container_2{width:460px;margin-left:auto;margin-right:auto}#ajaxsearchpro2_1,#ajaxsearchpro2_2,div.asp_m.asp_m_2{width:100%;height:auto;max-height:none;border-radius:5px;background:#d1eaff;margin-top:0;margin-bottom:0;background-image:-moz-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-webkit-gradient(radial,center center,0px,center center,100%,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-webkit-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-o-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-ms-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:radial-gradient(ellipse at center,rgba(243,242,246,1),rgba(243,242,246,1));overflow:hidden;border:1px none rgb(29,29,29);border-radius:25px 25px 25px 25px;box-shadow:none}@media only screen and (min-width:641px) and (max-width:1024px){.asp_w_container_2{width:100%}div.asp_main_container.asp_w+[id*=asp-try-2]{width:100%}}@media only screen and (max-width:640px){.asp_w_container_2{width:100%}div.asp_main_container.asp_w+[id*=asp-try-2]{width:100%}}#ajaxsearchpro2_1 .probox,#ajaxsearchpro2_2 .probox,div.asp_m.asp_m_2 .probox{margin:10px;height:30px;background:transparent;border:0 none rgb(255,255,255);border-radius:0;box-shadow:none}p[id*=asp-try-2]{color:rgb(85,85,85) !important;display:block}div.asp_main_container+[id*=asp-try-2]{margin-left:auto;margin-right:auto;width:460px}p[id*=asp-try-2] a{color:rgb(255,181,86) !important}p[id*=asp-try-2] a:after{color:rgb(85,85,85) !important;display:inline;content:','}p[id*=asp-try-2] a:last-child:after{display:none}#ajaxsearchpro2_1 .probox .proinput,#ajaxsearchpro2_2 .probox .proinput,div.asp_m.asp_m_2 .probox .proinput{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none;line-height:normal;flex-grow:1;order:5;margin:0 0 0 10px;padding:0 5px}#ajaxsearchpro2_1 .probox .proinput input.orig,#ajaxsearchpro2_2 .probox .proinput input.orig,div.asp_m.asp_m_2 .probox .proinput input.orig{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none;line-height:normal;border:0;box-shadow:none;height:30px;position:relative;z-index:2;padding:0 !important;padding-top:2px !important;margin:-1px 0 0 -4px !important;width:100%;background:transparent !important}#ajaxsearchpro2_1 .probox .proinput input.autocomplete,#ajaxsearchpro2_2 .probox .proinput input.autocomplete,div.asp_m.asp_m_2 .probox .proinput input.autocomplete{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none;line-height:normal;opacity:0.25;height:30px;display:block;position:relative;z-index:1;padding:0 !important;margin:-1px 0 0 -4px !important;margin-top:-30px !important;width:100%;background:transparent !important}.rtl #ajaxsearchpro2_1 .probox .proinput input.orig,.rtl #ajaxsearchpro2_2 .probox .proinput input.orig,.rtl #ajaxsearchpro2_1 .probox .proinput input.autocomplete,.rtl #ajaxsearchpro2_2 .probox .proinput input.autocomplete,.rtl div.asp_m.asp_m_2 .probox .proinput input.orig,.rtl div.asp_m.asp_m_2 .probox .proinput input.autocomplete{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none;line-height:normal;direction:rtl;text-align:right}.rtl #ajaxsearchpro2_1 .probox .proinput,.rtl #ajaxsearchpro2_2 .probox .proinput,.rtl div.asp_m.asp_m_2 .probox .proinput{margin-right:2px}.rtl #ajaxsearchpro2_1 .probox .proloading,.rtl #ajaxsearchpro2_1 .probox .proclose,.rtl #ajaxsearchpro2_2 .probox .proloading,.rtl #ajaxsearchpro2_2 .probox .proclose,.rtl div.asp_m.asp_m_2 .probox .proloading,.rtl div.asp_m.asp_m_2 .probox .proclose{order:3}div.asp_m.asp_m_2 .probox .proinput input.orig::-webkit-input-placeholder{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;text-shadow:none;opacity:0.85}div.asp_m.asp_m_2 .probox .proinput input.orig::-moz-placeholder{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;text-shadow:none;opacity:0.85}div.asp_m.asp_m_2 .probox .proinput input.orig:-ms-input-placeholder{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;text-shadow:none;opacity:0.85}div.asp_m.asp_m_2 .probox .proinput input.orig:-moz-placeholder{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;text-shadow:none;opacity:0.85;line-height:normal !important}#ajaxsearchpro2_1 .probox .proinput input.autocomplete,#ajaxsearchpro2_2 .probox .proinput input.autocomplete,div.asp_m.asp_m_2 .probox .proinput input.autocomplete{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none;line-height:normal;border:0;box-shadow:none}#ajaxsearchpro2_1 .probox .proloading,#ajaxsearchpro2_1 .probox .proclose,#ajaxsearchpro2_1 .probox .promagnifier,#ajaxsearchpro2_1 .probox .prosettings,#ajaxsearchpro2_2 .probox .proloading,#ajaxsearchpro2_2 .probox .proclose,#ajaxsearchpro2_2 .probox .promagnifier,#ajaxsearchpro2_2 .probox .prosettings,div.asp_m.asp_m_2 .probox .proloading,div.asp_m.asp_m_2 .probox .proclose,div.asp_m.asp_m_2 .probox .promagnifier,div.asp_m.asp_m_2 .probox .prosettings{width:30px;height:30px;flex:0 0 30px;flex-grow:0;order:7;text-align:center}#ajaxsearchpro2_1 .probox .proclose svg,#ajaxsearchpro2_2 .probox .proclose svg,div.asp_m.asp_m_2 .probox .proclose svg{fill:rgb(254,254,254);background:rgb(51,51,51);box-shadow:0 0 0 2px rgba(255,255,255,0.9);border-radius:50%;box-sizing:border-box;margin-left:-10px;margin-top:-10px;padding:4px}#ajaxsearchpro2_1 .probox .proloading,#ajaxsearchpro2_2 .probox .proloading,div.asp_m.asp_m_2 .probox .proloading{width:30px;height:30px;min-width:30px;min-height:30px;max-width:30px;max-height:30px}#ajaxsearchpro2_1 .probox .proloading .asp_loader,#ajaxsearchpro2_2 .probox .proloading .asp_loader,div.asp_m.asp_m_2 .probox .proloading .asp_loader{width:26px;height:26px;min-width:26px;min-height:26px;max-width:26px;max-height:26px}#ajaxsearchpro2_1 .probox .promagnifier,#ajaxsearchpro2_2 .probox .promagnifier,div.asp_m.asp_m_2 .probox .promagnifier{width:auto;height:30px;flex:0 0 auto;order:7;-webkit-flex:0 0 auto;-webkit-order:7}div.asp_m.asp_m_2 .probox .promagnifier:focus-visible{outline:black outset}#ajaxsearchpro2_1 .probox .proloading .innericon,#ajaxsearchpro2_2 .probox .proloading .innericon,#ajaxsearchpro2_1 .probox .proclose .innericon,#ajaxsearchpro2_2 .probox .proclose .innericon,#ajaxsearchpro2_1 .probox .promagnifier .innericon,#ajaxsearchpro2_2 .probox .promagnifier .innericon,#ajaxsearchpro2_1 .probox .prosettings .innericon,#ajaxsearchpro2_2 .probox .prosettings .innericon,div.asp_m.asp_m_2 .probox .proloading .innericon,div.asp_m.asp_m_2 .probox .proclose .innericon,div.asp_m.asp_m_2 .probox .promagnifier .innericon,div.asp_m.asp_m_2 .probox .prosettings .innericon{text-align:center}#ajaxsearchpro2_1 .probox .promagnifier .innericon,#ajaxsearchpro2_2 .probox .promagnifier .innericon,div.asp_m.asp_m_2 .probox .promagnifier .innericon{display:block;width:30px;height:30px;float:right}#ajaxsearchpro2_1 .probox .promagnifier .asp_text_button,#ajaxsearchpro2_2 .probox .promagnifier .asp_text_button,div.asp_m.asp_m_2 .probox .promagnifier .asp_text_button{display:block;width:auto;height:30px;float:right;margin:0;padding:0 10px 0 2px;font-weight:normal;font-family:"Open Sans";color:rgb(51,51,51);font-size:15px;line-height:auto;text-shadow:none;line-height:30px}#ajaxsearchpro2_1 .probox .promagnifier .innericon svg,#ajaxsearchpro2_2 .probox .promagnifier .innericon svg,div.asp_m.asp_m_2 .probox .promagnifier .innericon svg{fill:rgba(28,9,80,1)}#ajaxsearchpro2_1 .probox .prosettings .innericon svg,#ajaxsearchpro2_2 .probox .prosettings .innericon svg,div.asp_m.asp_m_2 .probox .prosettings .innericon svg{fill:rgb(54,54,54)}#ajaxsearchpro2_1 .probox .promagnifier,#ajaxsearchpro2_2 .probox .promagnifier,div.asp_m.asp_m_2 .probox .promagnifier{width:30px;height:30px;background-image:-webkit-linear-gradient(180deg,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-moz-linear-gradient(180deg,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-o-linear-gradient(180deg,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-ms-linear-gradient(180deg,rgba(243,242,246,1) 0,rgba(243,242,246,1) 100%);background-image:linear-gradient(180deg,rgba(243,242,246,1),rgba(243,242,246,1));background-position:center center;background-repeat:no-repeat;order:11;-webkit-order:11;float:right;border:0 none rgba(255,255,255,0);border-radius:0;box-shadow:none;cursor:pointer;background-size:100% 100%;background-position:center center;background-repeat:no-repeat;cursor:pointer}#ajaxsearchpro2_1 .probox .prosettings,#ajaxsearchpro2_2 .probox .prosettings,div.asp_m.asp_m_2 .probox .prosettings{width:30px;height:30px;background:transparent;background-position:center center;background-repeat:no-repeat;order:10;-webkit-order:10;float:right;border:0 solid rgb(255,255,255);border-radius:0;box-shadow:0 1px 0 0 rgba(255,255,255,0.64);cursor:pointer;background-size:100% 100%;align-self:flex-end}#ajaxsearchprores2_1,#ajaxsearchprores2_2,div.asp_r.asp_r_2{position:absolute;z-index:11000;width:auto;margin:12px 0 0 0}#ajaxsearchprores2_1 .asp_nores,#ajaxsearchprores2_2 .asp_nores,div.asp_r.asp_r_2 .asp_nores{border:0 solid rgb(0,0,0);border-radius:0;box-shadow:0 5px 5px -5px #dfdfdf;padding:6px 12px 6px 12px;margin:0;font-weight:normal;font-family:inherit;color:rgba(74,74,74,1);font-size:1rem;line-height:1.2rem;text-shadow:none;font-weight:normal;background:rgb(255,255,255)}#ajaxsearchprores2_1 .asp_nores .asp_nores_kw_suggestions,#ajaxsearchprores2_2 .asp_nores .asp_nores_kw_suggestions,div.asp_r.asp_r_2 .asp_nores .asp_nores_kw_suggestions{color:rgba(234,67,53,1);font-weight:normal}#ajaxsearchprores2_1 .asp_nores .asp_keyword,#ajaxsearchprores2_2 .asp_nores .asp_keyword,div.asp_r.asp_r_2 .asp_nores .asp_keyword{padding:0 8px 0 0;cursor:pointer;color:rgba(20,84,169,1);font-weight:bold}#ajaxsearchprores2_1 .asp_results_top,#ajaxsearchprores2_2 .asp_results_top,div.asp_r.asp_r_2 .asp_results_top{background:rgb(255,255,255);border:1px none rgb(81,81,81);border-radius:0;padding:6px 12px 6px 12px;margin:0 0 4px 0;text-align:center;font-weight:normal;font-family:"Open Sans";color:rgb(81,81,81);font-size:13px;line-height:16px;text-shadow:none}#ajaxsearchprores2_1 .results .item,#ajaxsearchprores2_2 .results .item,div.asp_r.asp_r_2 .results .item{height:auto;background:rgb(255,255,255)}#ajaxsearchprores2_1 .results .item.hovered,#ajaxsearchprores2_2 .results .item.hovered,div.asp_r.asp_r_2 .results .item.hovered{background-image:-moz-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-webkit-gradient(radial,center center,0px,center center,100%,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-webkit-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-o-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:-ms-radial-gradient(center,ellipse cover,rgba(243,242,246,1),rgba(243,242,246,1));background-image:radial-gradient(ellipse at center,rgba(243,242,246,1),rgba(243,242,246,1))}#ajaxsearchprores2_1 .results .item .asp_image,#ajaxsearchprores2_2 .results .item .asp_image,div.asp_r.asp_r_2 .results .item .asp_image{background-size:cover;background-repeat:no-repeat}#ajaxsearchprores2_1 .results .item .asp_image img,#ajaxsearchprores2_2 .results .item .asp_image img,div.asp_r.asp_r_2 .results .item .asp_image img{object-fit:cover}#ajaxsearchprores2_1 .results .item .asp_item_overlay_img,#ajaxsearchprores2_2 .results .item .asp_item_overlay_img,div.asp_r.asp_r_2 .results .item .asp_item_overlay_img{background-size:cover;background-repeat:no-repeat}#ajaxsearchprores2_1 .results .item .asp_content,#ajaxsearchprores2_2 .results .item .asp_content,div.asp_r.asp_r_2 .results .item .asp_content{overflow:hidden;background:transparent;margin:0;padding:0 10px}#ajaxsearchprores2_1 .results .item .asp_content h3,#ajaxsearchprores2_2 .results .item .asp_content h3,div.asp_r.asp_r_2 .results .item .asp_content h3{margin:0;padding:0;display:inline-block;line-height:inherit;font-weight:bold;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none}#ajaxsearchprores2_1 .results .item .asp_content h3 a,#ajaxsearchprores2_2 .results .item .asp_content h3 a,div.asp_r.asp_r_2 .results .item .asp_content h3 a{margin:0;padding:0;line-height:inherit;display:block;font-weight:bold;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none}#ajaxsearchprores2_1 .results .item .asp_content h3 a:hover,#ajaxsearchprores2_2 .results .item .asp_content h3 a:hover,div.asp_r.asp_r_2 .results .item .asp_content h3 a:hover{font-weight:bold;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,1);font-size:16px;line-height:20px;text-shadow:none}#ajaxsearchprores2_1 .results .item div.etc,#ajaxsearchprores2_2 .results .item div.etc,div.asp_r.asp_r_2 .results .item div.etc{padding:0;font-size:13px;line-height:1.3em;margin-bottom:6px}#ajaxsearchprores2_1 .results .item .etc .asp_author,#ajaxsearchprores2_2 .results .item .etc .asp_author,div.asp_r.asp_r_2 .results .item .etc .asp_author{padding:0;font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,0.5);font-size:11px;line-height:13px;text-shadow:none}#ajaxsearchprores2_1 .results .item .etc .asp_date,#ajaxsearchprores2_2 .results .item .etc .asp_date,div.asp_r.asp_r_2 .results .item .etc .asp_date{margin:0 0 0 10px;padding:0;font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,0.75);font-size:11px;line-height:15px;text-shadow:none}#ajaxsearchprores2_1 .results .item div.asp_content,#ajaxsearchprores2_2 .results .item div.asp_content,div.asp_r.asp_r_2 .results .item div.asp_content{margin:0;padding:0;font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgba(28,9,80,0.75);font-size:13px;line-height:16px;text-shadow:none}#ajaxsearchprores2_1 span.highlighted,#ajaxsearchprores2_2 span.highlighted,div.asp_r.asp_r_2 span.highlighted{font-weight:bold;color:rgba(217,49,43,1);background-color:rgba(238,238,238,1)}#ajaxsearchprores2_1 p.showmore,#ajaxsearchprores2_2 p.showmore,div.asp_r.asp_r_2 p.showmore{text-align:center;font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgb(28,9,80);font-size:12px;line-height:15px;text-shadow:none}#ajaxsearchprores2_1 p.showmore a,#ajaxsearchprores2_2 p.showmore a,div.asp_r.asp_r_2 p.showmore a{font-weight:normal;font-family:"proxima-nova","sans-serif";color:rgb(28,9,80);font-size:12px;line-height:15px;text-shadow:none;padding:10px 5px;margin:0 auto;background:rgba(255,255,255,1);display:block;text-align:center}#ajaxsearchprores2_1 .asp_res_loader,#ajaxsearchprores2_2 .asp_res_loader,div.asp_r.asp_r_2 .asp_res_loader{background:rgb(255,255,255);height:200px;padding:10px}#ajaxsearchprores2_1.isotopic .asp_res_loader,#ajaxsearchprores2_2.isotopic .asp_res_loader,div.asp_r.asp_r_2.isotopic .asp_res_loader{background:rgba(255,255,255,0)}#ajaxsearchprores2_1 .asp_res_loader .asp_loader,#ajaxsearchprores2_2 .asp_res_loader .asp_loader,div.asp_r.asp_r_2 .asp_res_loader .asp_loader{height:200px;width:200px;margin:0 auto}div.asp_s.asp_s_2.searchsettings,div.asp_s.asp_s_2.searchsettings,div.asp_s.asp_s_2.searchsettings{direction:ltr;padding:0;background-image:-webkit-linear-gradient(185deg,rgb(255,255,255),rgb(255,255,255));background-image:-moz-linear-gradient(185deg,rgb(255,255,255),rgb(255,255,255));background-image:-o-linear-gradient(185deg,rgb(255,255,255),rgb(255,255,255));background-image:-ms-linear-gradient(185deg,rgb(255,255,255) 0,rgb(255,255,255) 100%);background-image:linear-gradient(185deg,rgb(255,255,255),rgb(255,255,255));box-shadow:0 0 0 1px rgb(29,29,29);;max-width:208px;z-index:2}div.asp_s.asp_s_2.searchsettings.asp_s,div.asp_s.asp_s_2.searchsettings.asp_s,div.asp_s.asp_s_2.searchsettings.asp_s{z-index:11001}#ajaxsearchprobsettings2_1.searchsettings,#ajaxsearchprobsettings2_2.searchsettings,div.asp_sb.asp_sb_2.searchsettings{max-width:none}div.asp_s.asp_s_2.searchsettings form,div.asp_s.asp_s_2.searchsettings form,div.asp_s.asp_s_2.searchsettings form{display:flex}div.asp_sb.asp_sb_2.searchsettings form,div.asp_sb.asp_sb_2.searchsettings form,div.asp_sb.asp_sb_2.searchsettings form{display:flex}#ajaxsearchprosettings2_1.searchsettings div.asp_option_label,#ajaxsearchprosettings2_2.searchsettings div.asp_option_label,#ajaxsearchprosettings2_1.searchsettings .asp_label,#ajaxsearchprosettings2_2.searchsettings .asp_label,div.asp_s.asp_s_2.searchsettings div.asp_option_label,div.asp_s.asp_s_2.searchsettings .asp_label{font-weight:bold;font-family:"Open Sans";color:rgb(43,43,43);font-size:12px;line-height:15px;text-shadow:none}#ajaxsearchprosettings2_1.searchsettings .asp_option_inner .asp_option_checkbox,#ajaxsearchprosettings2_2.searchsettings .asp_option_inner .asp_option_checkbox,div.asp_sb.asp_sb_2.searchsettings .asp_option_inner .asp_option_checkbox,div.asp_s.asp_s_2.searchsettings .asp_option_inner .asp_option_checkbox{background-image:-webkit-linear-gradient(180deg,rgb(34,34,34),rgb(69,72,77));background-image:-moz-linear-gradient(180deg,rgb(34,34,34),rgb(69,72,77));background-image:-o-linear-gradient(180deg,rgb(34,34,34),rgb(69,72,77));background-image:-ms-linear-gradient(180deg,rgb(34,34,34) 0,rgb(69,72,77) 100%);background-image:linear-gradient(180deg,rgb(34,34,34),rgb(69,72,77))}#ajaxsearchprosettings2_1.searchsettings .asp_option_inner .asp_option_checkbox:after,#ajaxsearchprosettings2_2.searchsettings .asp_option_inner .asp_option_checkbox:after,#ajaxsearchprobsettings2_1.searchsettings .asp_option_inner .asp_option_checkbox:after,#ajaxsearchprobsettings2_2.searchsettings .asp_option_inner .asp_option_checkbox:after,div.asp_sb.asp_sb_2.searchsettings .asp_option_inner .asp_option_checkbox:after,div.asp_s.asp_s_2.searchsettings .asp_option_inner .asp_option_checkbox:after{font-family:'asppsicons2';border:none;content:"\e800";display:block;position:absolute;top:0;left:0;font-size:11px;color:rgb(255,255,255);margin:1px 0 0 0 !important;line-height:17px;text-align:center;text-decoration:none;text-shadow:none}div.asp_sb.asp_sb_2.searchsettings .asp_sett_scroll,div.asp_s.asp_s_2.searchsettings .asp_sett_scroll{scrollbar-width:thin;scrollbar-color:rgba(28,9,80,1) transparent}div.asp_sb.asp_sb_2.searchsettings .asp_sett_scroll::-webkit-scrollbar,div.asp_s.asp_s_2.searchsettings .asp_sett_scroll::-webkit-scrollbar{width:7px}div.asp_sb.asp_sb_2.searchsettings .asp_sett_scroll::-webkit-scrollbar-track,div.asp_s.asp_s_2.searchsettings .asp_sett_scroll::-webkit-scrollbar-track{background:transparent}div.asp_sb.asp_sb_2.searchsettings .asp_sett_scroll::-webkit-scrollbar-thumb,div.asp_s.asp_s_2.searchsettings .asp_sett_scroll::-webkit-scrollbar-thumb{background:rgba(28,9,80,1);border-radius:5px;border:none}#ajaxsearchprosettings2_1.searchsettings .asp_sett_scroll,#ajaxsearchprosettings2_2.searchsettings .asp_sett_scroll,div.asp_s.asp_s_2.searchsettings .asp_sett_scroll{max-height:220px;overflow:auto}#ajaxsearchprobsettings2_1.searchsettings .asp_sett_scroll,#ajaxsearchprobsettings2_2.searchsettings .asp_sett_scroll,div.asp_sb.asp_sb_2.searchsettings .asp_sett_scroll{max-height:220px;overflow:auto}#ajaxsearchprosettings2_1.searchsettings fieldset,#ajaxsearchprosettings2_2.searchsettings fieldset,div.asp_s.asp_s_2.searchsettings fieldset{width:200px;min-width:200px;max-width:10000px}#ajaxsearchprobsettings2_1.searchsettings fieldset,#ajaxsearchprobsettings2_2.searchsettings fieldset,div.asp_sb.asp_sb_2.searchsettings fieldset{width:200px;min-width:200px;max-width:10000px}#ajaxsearchprosettings2_1.searchsettings fieldset legend,#ajaxsearchprosettings2_2.searchsettings fieldset legend,div.asp_s.asp_s_2.searchsettings fieldset legend{padding:0 0 0 10px;margin:0;background:transparent;font-weight:normal;font-family:"Open Sans";color:rgb(71,71,71);font-size:13px;line-height:15px;text-shadow:none}#ajaxsearchprores2_1.vertical,#ajaxsearchprores2_2.vertical,div.asp_r.asp_r_2.vertical{padding:4px;background:rgb(255,255,255);border-radius:3px;border:1px none rgb(29,29,29);border-radius:3px 3px 3px 3px;box-shadow:0 20px 50px 0 #1c0950;visibility:hidden;display:none}#ajaxsearchprores2_1.vertical .results,#ajaxsearchprores2_2.vertical .results,div.asp_r.asp_r_2.vertical .results{max-height:none;overflow-x:hidden;overflow-y:auto}#ajaxsearchprores2_1.vertical .item,#ajaxsearchprores2_2.vertical .item,div.asp_r.asp_r_2.vertical .item{position:relative;box-sizing:border-box}#ajaxsearchprores2_1.vertical .item .asp_content h3,#ajaxsearchprores2_2.vertical .item .asp_content h3,div.asp_r.asp_r_2.vertical .item .asp_content h3{display:inline}#ajaxsearchprores2_1.vertical .results .item .asp_content,#ajaxsearchprores2_2.vertical .results .item .asp_content,div.asp_r.asp_r_2.vertical .results .item .asp_content{overflow:hidden;width:auto;height:auto;background:transparent;margin:0;padding:8px}#ajaxsearchprores2_1.vertical .results .item .asp_image,#ajaxsearchprores2_2.vertical .results .item .asp_image,div.asp_r.asp_r_2.vertical .results .item .asp_image{width:70px;height:70px;margin:2px 8px 0 0}#ajaxsearchprores2_1.vertical .asp_simplebar-scrollbar::before,#ajaxsearchprores2_2.vertical .asp_simplebar-scrollbar::before,div.asp_r.asp_r_2.vertical .asp_simplebar-scrollbar::before{background:transparent;background-image:-moz-radial-gradient(center,ellipse cover,rgba(28,9,80,1),rgba(28,9,80,1));background-image:-webkit-gradient(radial,center center,0px,center center,100%,rgba(28,9,80,1),rgba(28,9,80,1));background-image:-webkit-radial-gradient(center,ellipse cover,rgba(28,9,80,1),rgba(28,9,80,1));background-image:-o-radial-gradient(center,ellipse cover,rgba(28,9,80,1),rgba(28,9,80,1));background-image:-ms-radial-gradient(center,ellipse cover,rgba(28,9,80,1),rgba(28,9,80,1));background-image:radial-gradient(ellipse at center,rgba(28,9,80,1),rgba(28,9,80,1))}#ajaxsearchprores2_1.vertical .results .item::after,#ajaxsearchprores2_2.vertical .results .item::after,div.asp_r.asp_r_2.vertical .results .item::after{display:block;position:absolute;bottom:0;content:"";height:1px;width:100%;background:rgba(255,255,255,0.55)}#ajaxsearchprores2_1.vertical .results .item.asp_last_item::after,#ajaxsearchprores2_2.vertical .results .item.asp_last_item::after,div.asp_r.asp_r_2.vertical .results .item.asp_last_item::after{display:none}.asp_spacer{display:none !important;}.asp_v_spacer{width:100%;height:0}#ajaxsearchprores2_1 .asp_group_header,#ajaxsearchprores2_2 .asp_group_header,div.asp_r.asp_r_2 .asp_group_header{background:#DDD;background:rgba(255,255,255,1);border-radius:3px 3px 0 0;border-top:1px solid rgba(255,255,255,1);border-left:1px solid rgba(255,255,255,1);border-right:1px solid rgba(255,255,255,1);margin:0 0 -3px;padding:7px 0 7px 10px;position:relative;z-index:1000;min-width:90%;flex-grow:1;font-weight:bold;font-family:"proxima-nova","sans-serif";color:rgb(28,9,80);font-size:11px;line-height:13px;text-shadow:none}#ajaxsearchprores2_1.vertical .results,#ajaxsearchprores2_2.vertical .results,div.asp_r.asp_r_2.vertical .results{scrollbar-width:thin;scrollbar-color:rgba(0,0,0,0.5) rgb(255,255,255)}#ajaxsearchprores2_1.vertical .results::-webkit-scrollbar,#ajaxsearchprores2_2.vertical .results::-webkit-scrollbar,div.asp_r.asp_r_2.vertical .results::-webkit-scrollbar{width:10px}#ajaxsearchprores2_1.vertical .results::-webkit-scrollbar-track,#ajaxsearchprores2_2.vertical .results::-webkit-scrollbar-track,div.asp_r.asp_r_2.vertical .results::-webkit-scrollbar-track{background:rgb(255,255,255);box-shadow:inset 0 0 12px 12px transparent;border:none}#ajaxsearchprores2_1.vertical .results::-webkit-scrollbar-thumb,#ajaxsearchprores2_2.vertical .results::-webkit-scrollbar-thumb,div.asp_r.asp_r_2.vertical .results::-webkit-scrollbar-thumb{background:transparent;box-shadow:inset 0 0 12px 12px rgba(0,0,0,0);border:solid 2px transparent;border-radius:12px}#ajaxsearchprores2_1.vertical:hover .results::-webkit-scrollbar-thumb,#ajaxsearchprores2_2.vertical:hover .results::-webkit-scrollbar-thumb,div.asp_r.asp_r_2.vertical:hover .results::-webkit-scrollbar-thumb{box-shadow:inset 0 0 12px 12px rgba(28,9,80,1)}@media(hover:none),(max-width:500px){#ajaxsearchprores2_1.vertical .results::-webkit-scrollbar-thumb,#ajaxsearchprores2_2.vertical .results::-webkit-scrollbar-thumb,div.asp_r.asp_r_2.vertical .results::-webkit-scrollbar-thumb{box-shadow:inset 0 0 12px 12px rgba(28,9,80,1)}}#ajaxsearchprores2_1.vertical .results .item .asp_image,#ajaxsearchprores2_2.vertical .results .item .asp_image,div.asp_r.asp_r_2.vertical .results .item .asp_image{margin:0 10px 0 0;border-radius:5px}#ajaxsearchprores2_1.vertical,#ajaxsearchprores2_2.vertical,div.asp_r.asp_r_2.vertical{padding:0}div.asp_w.asp_r .results .item{padding:0;border:0}#ajaxsearchprores2_1.vertical,#ajaxsearchprores2_2.vertical,div.asp_r.asp_r_2.vertical{-webkit-box-shadow:0 20px 50px 0 rgba(28,9,80,0.25);-moz-box-shadow:0 20px 50px 0 rgba(28,9,80,0.25);box-shadow:0 20px 50px 0 rgba(28,9,80,0.25)}div.asp_m.ajaxsearchpro .probox .proinput input{font-weight:500 !important}#ajaxsearchpro2_1,#ajaxsearchpro2_2,div.asp_m.asp_m_2{}div.asp_w.asp_r .results .asp_nores{padding:20px;color:#1c0950}div.asp_w.asp_r .results .asp_nores .asp_nores_header{display:block;text-align:center;width:100%;margin-bottom:10px}</style></head>

<body class="error404 custom-background wp-custom-logo wp-theme-zakra wp-child-theme-SliderRevolution hfeed tg-site-layout--no-sidebar tg-container--wide has-page-header">


<script type="text/javascript">ire('identify', {customerId: '', customerEmail: ''});</script>

		<div id="page" class="site tg-site">
				<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
		
		<header id="masthead" class="site-header tg-site-header tg-site-header--left">
		

		<div class="tg-site-header-top">
			<div class="tg-header-container tg-container tg-container--flex tg-container--flex-center">
				<div class="tg-header-top-left-content">

					<span style="font-weight: 500">Upgrade to 6.7 Now! 🚀</span> Get Enhanced Performance with the "Velocity" Engine <a href="https://www.sliderrevolution.com/sr7-velocity-frontend-engine-update/"><button class="tp-btn-small">Learn More</button></a>
<div class="tp-headercloser"> </div>
				</div>
				<!-- /.tg-header-top-left-content -->
				<div class="tg-header-top-right-content">

					<a class="rs-chat" href="#">Contact Us</a><div class="tp-label">Latest Version:</div><a class="tp-latest-version" href="https://www.sliderrevolution.com/documentation/changelog/"> </a>
				</div>
				<!-- /.tg-header-top-right-content -->
			</div>
			<!-- /.tg-container -->
		</div>
		<!-- /.tg-site-header-top -->

		

		<div class="tg-site-header-bottom">
			<div class="tg-header-container tg-container tg-container--flex tg-container--flex-center tg-container--flex-space-between">
		
		
			<div class="tg-block tg-block--one">

						<div class="site-branding">
			<a href="https://www.sliderrevolution.com/" class="custom-logo-link" rel="home"><img width="260" height="80" src="https://www.sliderrevolution.com/wp-content/uploads/2020/02/srlogo.png" class="custom-logo" alt="Slider Revolution" decoding="async" /></a>			<div class="site-info-wrap">
									<p class="site-title">
						<a href="https://www.sliderrevolution.com/" rel="home">Slider Revolution</a>
					</p>
										<p class="site-description">More than just a WordPress slider</p>
							</div>

		</div><!-- .site-branding -->
		
			</div> <!-- /.tg-site-header__block--one -->

			
			<div class="tg-block tg-block--two">

						<nav id="site-navigation" class="main-navigation tg-primary-menu tg-primary-menu--style-underline">
			<div class="menu"><ul id="primary-menu" class="menu-primary"><li id="menu-item-6948" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6948"><a href="https://www.sliderrevolution.com/wordpress-templates/">Templates</a></li>
<li id="menu-item-44620" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-44620"><a href="#">Design</a>
<ul class="sub-menu">
	<li id="menu-item-45802" class="menu-icon menu-slider lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45802"><a href="https://www.sliderrevolution.com/wordpress-sliders/">Sliders</a></li>
	<li id="menu-item-45800" class="menu-icon menu-carousel lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45800"><a href="https://www.sliderrevolution.com/website-carousels/">Carousels</a></li>
	<li id="menu-item-45801" class="menu-icon menu-website lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45801"><a href="https://www.sliderrevolution.com/one-page-websites/">One-Page Websites</a></li>
	<li id="menu-item-45799" class="menu-icon menu-hero lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45799"><a href="https://www.sliderrevolution.com/website-hero-sections/">Hero Sections</a></li>
	<li id="menu-item-9797" class="menu-icon menu-dynamic lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-9797"><a href="https://www.sliderrevolution.com/dynamic-content/">Dynamic Content</a></li>
</ul>
</li>
<li id="menu-item-26" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-26"><a href="#">Features</a>
<ul class="sub-menu">
	<li id="menu-item-6528" class="menu-icon menu-editor lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-6528"><a href="https://www.sliderrevolution.com/the-ultimate-wordpress-visual-editor/">Visual Editor</a></li>
	<li id="menu-item-21618" class="menu-icon menu-animation lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-21618"><a href="https://www.sliderrevolution.com/website-animation-effects/">Animation Effects</a></li>
	<li id="menu-item-7295" class="menu-icon menu-addons lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-7295"><a href="https://www.sliderrevolution.com/expand-possibilities-with-website-addons/">AddOns</a></li>
	<li id="menu-item-19853" class="menu-icon menu-transitions lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-19853"><a href="https://www.sliderrevolution.com/web-page-transitions/">Advanced Transitions</a></li>
	<li id="menu-item-24204" class="menu-icon menu-particles lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-24204"><a href="https://www.sliderrevolution.com/particle-animation/">Particle Animation</a></li>
</ul>
</li>
<li id="menu-item-45159" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-45159"><a href="#">SR is for</a>
<ul class="sub-menu">
	<li id="menu-item-45163" class="menu-icon menu-designer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45163"><a href="https://www.sliderrevolution.com/web-designers/">Web Designers</a></li>
	<li id="menu-item-45162" class="menu-icon menu-developer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45162"><a href="https://www.sliderrevolution.com/web-developers/">Web Developers</a></li>
	<li id="menu-item-45161" class="menu-icon menu-marketer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45161"><a href="https://www.sliderrevolution.com/marketers/">Marketers</a></li>
	<li id="menu-item-45160" class="menu-icon menu-business lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45160"><a href="https://www.sliderrevolution.com/business-owners/">Business Owners</a></li>
</ul>
</li>
<li id="menu-item-10837" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10837"><a href="#">Resources</a>
<ul class="sub-menu">
	<li id="menu-item-44621" class="menu-icon menu-helpcenter lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-44621"><a href="https://www.sliderrevolution.com/help-center/">Help Center</a></li>
	<li id="menu-item-10832" class="menu-icon menu-manual lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-10832"><a href="https://www.sliderrevolution.com/manual/">Manual</a></li>
	<li id="menu-item-44622" class="menu-icon menu-changelog lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-44622"><a href="https://www.sliderrevolution.com/documentation/changelog/">Changelog</a></li>
	<li id="menu-item-2586" class="menu-icon menu-blog lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-2586"><a href="https://www.sliderrevolution.com/blog/">Blog</a></li>
	<li id="menu-item-42696" class="menu-icon menu-update lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-42696"><a href="https://www.sliderrevolution.com/sr7-velocity-frontend-engine-update/">Version 6.7 Update <span class="menu-newtag">NEW</span></a></li>
	<li id="menu-item-10847" class="menu-icon menu-ticket lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-10847"><a href="https://support.sliderrevolution.com/">Ticket Support</a></li>
</ul>
</li>
<li id="menu-item-8301" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8301"><a href="https://account.sliderrevolution.com/portal">Login</a></li>
<li id="menu-item-8327" class="menu-pricing menu-item menu-item-type-custom menu-item-object-custom menu-item-8327"><a href="https://account.sliderrevolution.com/portal/pricing/">Buy Now</a></li>
</ul></div>		</nav><!-- #site-navigation -->
				<nav id="header-action" class="tg-header-action">
			<ul class="tg-header-action-list">
				<li class="tg-header-action__item tg-mobile-toggle" >
										<button aria-label="Primary Menu" >
						<i class="tg-icon tg-icon-bars"></i>
					</button>
				</li><!-- /.tg-mobile-toggle -->
			</ul><!-- /.zakra-header-action-list -->
		</nav><!-- #header-action -->
				<nav id="mobile-navigation" class="tg-mobile-navigation"
			>

			<div class="menu-main-container"><ul id="mobile-primary-menu" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6948"><a href="https://www.sliderrevolution.com/wordpress-templates/">Templates</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-44620"><a href="#">Design</a>
<ul class="sub-menu">
	<li class="menu-icon menu-slider lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45802"><a href="https://www.sliderrevolution.com/wordpress-sliders/">Sliders</a></li>
	<li class="menu-icon menu-carousel lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45800"><a href="https://www.sliderrevolution.com/website-carousels/">Carousels</a></li>
	<li class="menu-icon menu-website lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45801"><a href="https://www.sliderrevolution.com/one-page-websites/">One-Page Websites</a></li>
	<li class="menu-icon menu-hero lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45799"><a href="https://www.sliderrevolution.com/website-hero-sections/">Hero Sections</a></li>
	<li class="menu-icon menu-dynamic lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-9797"><a href="https://www.sliderrevolution.com/dynamic-content/">Dynamic Content</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-26"><a href="#">Features</a>
<ul class="sub-menu">
	<li class="menu-icon menu-editor lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-6528"><a href="https://www.sliderrevolution.com/the-ultimate-wordpress-visual-editor/">Visual Editor</a></li>
	<li class="menu-icon menu-animation lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-21618"><a href="https://www.sliderrevolution.com/website-animation-effects/">Animation Effects</a></li>
	<li class="menu-icon menu-addons lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-7295"><a href="https://www.sliderrevolution.com/expand-possibilities-with-website-addons/">AddOns</a></li>
	<li class="menu-icon menu-transitions lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-19853"><a href="https://www.sliderrevolution.com/web-page-transitions/">Advanced Transitions</a></li>
	<li class="menu-icon menu-particles lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-24204"><a href="https://www.sliderrevolution.com/particle-animation/">Particle Animation</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-45159"><a href="#">SR is for</a>
<ul class="sub-menu">
	<li class="menu-icon menu-designer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45163"><a href="https://www.sliderrevolution.com/web-designers/">Web Designers</a></li>
	<li class="menu-icon menu-developer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45162"><a href="https://www.sliderrevolution.com/web-developers/">Web Developers</a></li>
	<li class="menu-icon menu-marketer lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45161"><a href="https://www.sliderrevolution.com/marketers/">Marketers</a></li>
	<li class="menu-icon menu-business lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-45160"><a href="https://www.sliderrevolution.com/business-owners/">Business Owners</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10837"><a href="#">Resources</a>
<ul class="sub-menu">
	<li class="menu-icon menu-helpcenter lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-44621"><a href="https://www.sliderrevolution.com/help-center/">Help Center</a></li>
	<li class="menu-icon menu-manual lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-10832"><a href="https://www.sliderrevolution.com/manual/">Manual</a></li>
	<li class="menu-icon menu-changelog lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-44622"><a href="https://www.sliderrevolution.com/documentation/changelog/">Changelog</a></li>
	<li class="menu-icon menu-blog lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-2586"><a href="https://www.sliderrevolution.com/blog/">Blog</a></li>
	<li class="menu-icon menu-update lazyload menu-item menu-item-type-post_type menu-item-object-page menu-item-42696"><a href="https://www.sliderrevolution.com/sr7-velocity-frontend-engine-update/">Version 6.7 Update <span class="menu-newtag">NEW</span></a></li>
	<li class="menu-icon menu-ticket lazyload menu-item menu-item-type-custom menu-item-object-custom menu-item-10847"><a href="https://support.sliderrevolution.com/">Ticket Support</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-8301"><a href="https://account.sliderrevolution.com/portal">Login</a></li>
<li class="menu-pricing menu-item menu-item-type-custom menu-item-object-custom menu-item-8327"><a href="https://account.sliderrevolution.com/portal/pricing/">Buy Now</a></li>
</ul></div>
		</nav><!-- /#mobile-navigation-->
		
			</div> <!-- /.tg-site-header__block-two -->

			
		</div>
		<!-- /.tg-container -->
		</div>
		<!-- /.tg-site-header-bottom -->
		
</header><!-- #masthead -->
<fakespace class="headerspace"></fakespace> <!-- FAKE SPACE FOR MENU CHANGES -->
	
		<main id="main" class="site-main">
		
		<header class="tg-page-header tg-page-header--both-center">
			<div class="tg-container tg-container--flex tg-container--flex-center tg-container--flex-space-between">
				<h1 class="tg-page-header__title">Page Not Found</h1>
							</div>
		</header>
		<!-- /.page-header -->
				<div class="minispace div25"></div>
			<div id="content" class="site-content">
			<div class="tg-container tg-container--flex tg-container--flex-space-between">
			

	<div id="primary" class="content-area">
		
		<section class="error-404 not-found">
						<div class="page-content">
				<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

				<div style="width:460px;margin: 0 auto;"><div class="asp_w_container asp_w_container_2 asp_w_container_2_1" data-id="2" data-instance="1"><div class='asp_w asp_m asp_m_2 asp_m_2_1 wpdreams_asp_sc wpdreams_asp_sc-2 ajaxsearchpro asp_main_container asp_non_compact' data-id="2" data-name="Help Center Solutions" data-instance="1" id='ajaxsearchpro2_1'><div class="probox"><div class='prosettings' style='display:none;' data-opened=0><div class='innericon'><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 512 512"><polygon transform="rotate(90 256 256)" points="142.332,104.886 197.48,50 402.5,256 197.48,462 142.332,407.113 292.727,256"/></svg></div></div><div class='proinput'><form role="search" action='#' autocomplete="off" aria-label="Search form"><input type='search' class='orig' placeholder='Search for solutions ...' name='phrase' value='' aria-label="Search input" autocomplete="off"/><input type='text' class='autocomplete' name='phrase' value='' aria-label="Search autocomplete input" aria-hidden="true" tabindex="-1" autocomplete="off" disabled/></form></div><button class='promagnifier' aria-label="Search magnifier button"><span class='asp_text_button hiddend'> Search </span><span class='innericon'><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 512 512"><path d="M460.355 421.59l-106.51-106.512c20.04-27.553 31.884-61.437 31.884-98.037C385.73 124.935 310.792 50 218.685 50c-92.106 0-167.04 74.934-167.04 167.04 0 92.107 74.935 167.042 167.04 167.042 34.912 0 67.352-10.773 94.184-29.158L419.945 462l40.41-40.41zM100.63 217.04c0-65.095 52.96-118.055 118.056-118.055 65.098 0 118.057 52.96 118.057 118.056 0 65.097-52.96 118.057-118.057 118.057-65.096 0-118.055-52.96-118.055-118.056z"/></svg></span><span class="asp_clear"></span></button><div class='proloading'><div class="asp_loader"><div class="asp_loader-inner asp_ball-beat"><div></div><div></div><div></div></div></div></div></div></div><div class='asp_data_container' style="display:none !important;"><div class="asp_init_data" style="display:none !important;" id="asp_init_id_2_1" data-asp-id="2" data-asp-instance="1" data-aspdata="eyJhbmltYXRpb25zIjp7InBjIjp7InNldHRpbmdzIjp7ImFuaW0iOiJmYWRlZHJvcCIsImR1ciI6MzAwfSwicmVzdWx0cyI6eyJhbmltIjoiZmFkZWRyb3AiLCJkdXIiOjMwMH0sIml0ZW1zIjoiZmFkZUluRG93biJ9LCJtb2IiOnsic2V0dGluZ3MiOnsiYW5pbSI6ImZhZGVkcm9wIiwiZHVyIjoiMzAwIn0sInJlc3VsdHMiOnsiYW5pbSI6ImZhZGVkcm9wIiwiZHVyIjoiMzAwIn0sIml0ZW1zIjoidm9pZGFuaW0ifX0sImF1dG9jb21wbGV0ZSI6eyJlbmFibGVkIjoxLCJ0cmlnZ2VyX2NoYXJjb3VudCI6MCwiZ29vZ2xlT25seSI6MCwibGFuZyI6ImVuIiwibW9iaWxlIjoxfSwiYXV0b3AiOnsic3RhdGUiOiJkaXNhYmxlZCIsInBocmFzZSI6IiIsImNvdW50IjoxMH0sImNoYXJjb3VudCI6MCwiY2xvc2VPbkRvY0NsaWNrIjoxLCJjb21wYWN0Ijp7ImVuYWJsZWQiOjAsImZvY3VzIjoxLCJ3aWR0aCI6IjEwMCUiLCJ3aWR0aF90YWJsZXQiOiI0ODBweCIsIndpZHRoX3Bob25lIjoiMzIwcHgiLCJjbG9zZU9uTWFnbmlmaWVyIjoxLCJjbG9zZU9uRG9jdW1lbnQiOjAsInBvc2l0aW9uIjoic3RhdGljIiwib3ZlcmxheSI6MH0sImNwdEFyY2hpdmUiOnsidXNlQWpheCI6MCwic2VsZWN0b3IiOiIjbWFpbiIsInVybCI6IiJ9LCJkZXRlY3RWaXNpYmlsaXR5IjowLCJkaXZpIjp7ImJvZHljb21tZXJjZSI6MH0sImZvY3VzT25QYWdlbG9hZCI6MCwiZnNzX2xheW91dCI6ImZsZXgiLCJoaWdobGlnaHQiOjAsImhpZ2hsaWdodFdob2xld29yZHMiOjEsImhvbWV1cmwiOiJodHRwczpcL1wvd3d3LnNsaWRlcnJldm9sdXRpb24uY29tXC8iLCJpc19yZXN1bHRzX3BhZ2UiOjAsImlzb3RvcGljIjp7Iml0ZW1XaWR0aCI6IjIwMHB4IiwiaXRlbVdpZHRoVGFibGV0IjoiMjAwcHgiLCJpdGVtV2lkdGhQaG9uZSI6IjIwMHB4IiwiaXRlbUhlaWdodCI6IjIwMHB4IiwiaXRlbUhlaWdodFRhYmxldCI6IjIwMHB4IiwiaXRlbUhlaWdodFBob25lIjoiMjAwcHgiLCJwYWdpbmF0aW9uIjoxLCJyb3dzIjoyLCJndXR0ZXIiOjUsInNob3dPdmVybGF5IjoxLCJibHVyT3ZlcmxheSI6MSwiaGlkZUNvbnRlbnQiOjF9LCJpdGVtc2NvdW50Ijo0LCJsb2FkZXJMb2NhdGlvbiI6ImF1dG8iLCJtb2JpbGUiOnsidHJpZ2dlcl9vbl90eXBlIjoxLCJjbGlja19hY3Rpb24iOiJhamF4X3NlYXJjaCIsInJldHVybl9hY3Rpb24iOiJhamF4X3NlYXJjaCIsImNsaWNrX2FjdGlvbl9sb2NhdGlvbiI6InNhbWUiLCJyZXR1cm5fYWN0aW9uX2xvY2F0aW9uIjoic2FtZSIsInJlZGlyZWN0X3VybCI6Ij9zPXtwaHJhc2V9IiwiZWxlbWVudG9yX3VybCI6Imh0dHBzOlwvXC93d3cuc2xpZGVycmV2b2x1dGlvbi5jb21cLz9hc3BfbHM9e3BocmFzZX0iLCJtZW51X3NlbGVjdG9yIjoiI21lbnUtdG9nZ2xlIiwiaGlkZV9rZXlib2FyZCI6MSwiZm9yY2VfcmVzX2hvdmVyIjowLCJmb3JjZV9zZXR0X2hvdmVyIjowLCJmb3JjZV9zZXR0X3N0YXRlIjoiY2xvc2VkIn0sIm92ZXJyaWRlX21ldGhvZCI6ImdldCIsIm92ZXJyaWRld3BkZWZhdWx0IjoxLCJwcmVzY29udGFpbmVyaGVpZ2h0IjoiNDAwcHgiLCJwcmV2ZW50Qm9keVNjcm9sbCI6MCwicHJldmVudEV2ZW50cyI6MCwicmIiOnsiYWN0aW9uIjoibm90aGluZyJ9LCJyZXNQYWdlIjp7InVzZUFqYXgiOjAsInNlbGVjdG9yIjoiI21haW4iLCJ0cmlnZ2VyX3R5cGUiOjEsInRyaWdnZXJfZmFjZXQiOjEsInRyaWdnZXJfbWFnbmlmaWVyIjowLCJ0cmlnZ2VyX3JldHVybiI6MH0sInJlc3VsdHMiOnsid2lkdGgiOiJhdXRvIiwid2lkdGhfdGFibGV0IjoiYXV0byIsIndpZHRoX3Bob25lIjoiYXV0byJ9LCJyZXN1bHRzU25hcFRvIjoibGVmdCIsInJlc3VsdHNwb3NpdGlvbiI6ImhvdmVyIiwicmVzdWx0c3R5cGUiOiJ2ZXJ0aWNhbCIsInNiIjp7InJlZGlyZWN0X2FjdGlvbiI6ImFqYXhfc2VhcmNoIiwicmVkaXJlY3RfbG9jYXRpb24iOiJzYW1lIiwicmVkaXJlY3RfdXJsIjoiP3M9e3BocmFzZX0iLCJlbGVtZW50b3JfdXJsIjoiaHR0cHM6XC9cL3d3dy5zbGlkZXJyZXZvbHV0aW9uLmNvbVwvP2FzcF9scz17cGhyYXNlfSJ9LCJzY3JvbGxCYXIiOnsiaG9yaXpvbnRhbCI6eyJlbmFibGVkIjoxfX0sInNjcm9sbFRvUmVzdWx0cyI6eyJlbmFibGVkIjowLCJvZmZzZXQiOjB9LCJzZWxlY3QyIjp7Im5vcmVzIjoiTm8gcmVzdWx0cyBtYXRjaCJ9LCJzZXR0aW5ncyI6eyJ1bnNlbGVjdENoaWxkcmVuIjoxLCJoaWRlQ2hpbGRyZW4iOjB9LCJzZXR0aW5nc0hpZGVPblJlcyI6MCwic2V0dGluZ3NpbWFnZXBvcyI6InJpZ2h0Iiwic2V0dGluZ3NWaXNpYmxlIjowLCJzaG93X21vcmUiOnsiZW5hYmxlZCI6MCwidXJsIjoiP3M9e3BocmFzZX0iLCJlbGVtZW50b3JfdXJsIjoiaHR0cHM6XC9cL3d3dy5zbGlkZXJyZXZvbHV0aW9uLmNvbVwvP2FzcF9scz17cGhyYXNlfSIsImFjdGlvbiI6ImFqYXgiLCJsb2NhdGlvbiI6InNhbWUiLCJpbmZpbml0ZSI6MX0sInNpbmdsZUhpZ2hsaWdodCI6MCwic3RhdGlzdGljcyI6MSwidGF4QXJjaGl2ZSI6eyJ1c2VBamF4IjowLCJzZWxlY3RvciI6IiNtYWluIiwidXJsIjoiIn0sInRyaWdnZXIiOnsiZGVsYXkiOjMwMCwiYXV0b2NvbXBsZXRlX2RlbGF5IjozMTAsInVwZGF0ZV9ocmVmIjowLCJmYWNldCI6MSwidHlwZSI6MSwiY2xpY2siOiJhamF4X3NlYXJjaCIsImNsaWNrX2xvY2F0aW9uIjoic2FtZSIsInJldHVybiI6ImFqYXhfc2VhcmNoIiwicmV0dXJuX2xvY2F0aW9uIjoic2FtZSIsInJlZGlyZWN0X3VybCI6Ij9zPXtwaHJhc2V9IiwiZWxlbWVudG9yX3VybCI6Imh0dHBzOlwvXC93d3cuc2xpZGVycmV2b2x1dGlvbi5jb21cLz9hc3BfbHM9e3BocmFzZX0iLCJtaW5Xb3JkTGVuZ3RoIjoyfSwid29vU2hvcCI6eyJ1c2VBamF4IjowLCJzZWxlY3RvciI6IiNtYWluIiwidXJsIjoiIn19"></div><div class='asp_hidden_data' style="display:none !important;"><div class='asp_item_overlay'><div class='asp_item_inner'><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 512 512"><path d="M448.225 394.243l-85.387-85.385c16.55-26.08 26.146-56.986 26.146-90.094 0-92.99-75.652-168.64-168.643-168.64-92.988 0-168.64 75.65-168.64 168.64s75.65 168.64 168.64 168.64c31.466 0 60.94-8.67 86.176-23.734l86.14 86.142c36.755 36.754 92.355-18.783 55.57-55.57zm-344.233-175.48c0-64.155 52.192-116.35 116.35-116.35s116.353 52.194 116.353 116.35S284.5 335.117 220.342 335.117s-116.35-52.196-116.35-116.352zm34.463-30.26c34.057-78.9 148.668-69.75 170.248 12.863-43.482-51.037-119.984-56.532-170.248-12.862z"/></svg></div></div></div></div><div id='__original__ajaxsearchprores2_1' class='asp_w asp_r asp_r_2 asp_r_2_1 vertical ajaxsearchpro wpdreams_asp_sc wpdreams_asp_sc-2' data-id="2" data-instance="1"><div class="results"><div class="resdrg"></div></div><div class="asp_res_loader hiddend"><div class="asp_loader"><div class="asp_loader-inner asp_ball-beat"><div></div><div></div><div></div></div></div></div></div><div id='__original__ajaxsearchprosettings2_1' class="asp_w asp_ss asp_ss_2 asp_s asp_s_2 asp_s_2_1 wpdreams_asp_sc wpdreams_asp_sc-2 ajaxsearchpro searchsettings" data-id="2" data-instance="1"><form name='options' class="asp-fss-flex" aria-label="Search settings form" autocomplete = 'off'><input type="hidden" name="current_page_id" value="-1"><input type='hidden' name='qtranslate_lang' value='0'/><input type="hidden" name="filters_changed" value="0"><input type="hidden" name="filters_initial" value="1"><div style="clear:both;"></div></form></div></div></div>			</div><!-- .page-content -->
		</section><!-- .error-404 -->

			</div><!-- #primary -->
	<script>jQuery(document).ready(function(){
		jQuery("input[name=phrase]").val(decodeURI(location.pathname.replace(/-|\//g, " ")).replace('jquery ','').replace('jquery ','').replace('faq ','').replace('index.html','').replace('joomla ','').replace('templates ','').replace('documentation ',''));
		self.setTimeout(function(){ jQuery('.innericon').click(); }, 500);
		
	});</script>

	 <div class="tp-aftercontent">
		<div class="wp-block-columns smallspace tp-prefooter">
			<div class="wp-block-column tp-cardshadow tp-newscard" data-t="recent_posts_3"><h4>From The Blog</h4><a class="tp-minipost" href="https://www.sliderrevolution.com/design/sticky-header/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2025/09/sticky-header-200x113.jpg)"></div>
					<h5>Sticky Header Pros and Cons: Is It Right for Your Site?</h5>
					<span>Design</span>
					</a><a class="tp-minipost" href="https://www.sliderrevolution.com/design/ux-button-best-practices/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2025/09/ux-button-best-practices-200x113.jpg)"></div>
					<h5>UX Button Best Practices for Higher Conversions</h5>
					<span>Design</span>
					</a><a class="tp-minipost" href="https://www.sliderrevolution.com/design/wordpress-video-background/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2020/10/video-background-200x113.jpg)"></div>
					<h5>WordPress Video Background Examples And How To Add One</h5>
					<span>Design</span>
					</a></div><div class="wp-block-column tp-cardshadow tp-newscard" data-t="specific_posts_8692_20016_8329_23619"><h4>Popular Resources</h4><a class="tp-minipost" href="https://www.sliderrevolution.com/faq/optimizing-load-speed-and-performance/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2021/08/0FF9E966-12BD-4870-B6C8-3D3145364428-200x113.jpeg)"></div>
					<h5>Optimizing Load Speed and Performance</h5>
					<span>FAQ</span>
					</a><a class="tp-minipost" href="https://www.sliderrevolution.com/faq/quick-setup-slider-revolution/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2020/05/ThumbQuickSetupSR-200x113.jpg)"></div>
					<h5>Quick Setup &#8211; Slider Revolution</h5>
					<span>FAQ</span>
					</a><a class="tp-minipost" href="https://www.sliderrevolution.com/youtube-tutorials/create-a-basic-responsive-slider/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2022/01/maxresdefault-200x113.jpg)"></div>
					<h5>Create a Basic Responsive Slider</h5>
					<span>Video Tutorial</span>
					</a><a class="tp-minipost" href="https://www.sliderrevolution.com/manual/get-productive-fast/" target="_top">
					<div class="tp-minipost-thumb" style="background-image:url(https://www.sliderrevolution.com/wp-content/uploads/2020/06/getprod_featuredimage-200x113.jpg)"></div>
					<h5>Get Productive Fast</h5>
					<span>Manual</span>
					</a></div>			<div class="wp-block-column tp-cardshadow tp-newscard">
				<h2>Newsletter</h2>
				<img src="https://www.sliderrevolution.com/wp-content/uploads/2020/02/mailicon-1.png" width="50" height="38" alt="Newsletter Icon" class="tp-newslettericon">
				<p>Join over 35.000 others on the Slider Revolution email list to get access to the latest news and exclusive content.</p>
				<div id="tp_embed_signup"><div action="https://www.sliderrevolution.com/my-account/?signup=general" method="post" id="mc-embedded-subscribe-formy" name="mc-embedded-subscribe-formy" target="_blank" novalidate=""><div id="mc_embed_signup_scroll"></div><input type="submit" value="Subscribe" onclick="openNewsletterSlider();return false;" name="subscribe" id="mc-embedded-subscribe"></div></div></div>
			</div>
		</div>
	</div> 		</div>
		<!-- /.tg-container-->
		</div>
		<!-- /#content-->
				</main><!-- /#main -->
		
			<footer id="colophon" class="site-footer tg-site-footer ">
		
		
		<div class="tg-site-footer-widgets">
			<div class="tg-container">
				
<div class="tg-footer-widget-container tg-footer-widget-col--four">
					<div class="tg-footer-widget-area footer-sidebar-1">
											<section id="nav_menu-2" class="widget widget_nav_menu"><h2 class="widget-title">Slider Revolution</h2><div class="menu-footer-1-container"><ul id="menu-footer-1" class="menu"><li id="menu-item-47231" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47231"><a href="https://www.sliderrevolution.com/about-us/">About Us</a></li>
<li id="menu-item-293" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-293"><a href="https://www.sliderrevolution.com/the-ultimate-wordpress-visual-editor/">Build Anything Visually</a></li>
<li id="menu-item-292" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-292"><a href="https://www.sliderrevolution.com/pro-level-design-with-slider-revolution/">Pro-Level Design</a></li>
<li id="menu-item-295" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-295"><a href="https://www.sliderrevolution.com/examples/">Templates</a></li>
<li id="menu-item-19855" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-19855"><a href="https://www.sliderrevolution.com/web-page-transitions/">Advanced Transitions</a></li>
<li id="menu-item-296" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-296"><a href="https://www.sliderrevolution.com/expand-possibilities-with-addons/">Addons</a></li>
<li id="menu-item-297" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-297"><a href="https://www.sliderrevolution.com/premium-slider-revolution/">Upgrade To Premium</a></li>
<li id="menu-item-44577" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-44577"><a href="https://www.sliderrevolution.com/wordpress-hosting/">WordPress Hosting</a></li>
</ul></div></section>									</div>
								<div class="tg-footer-widget-area footer-sidebar-2">
											<section id="nav_menu-3" class="widget widget_nav_menu"><h2 class="widget-title">Support</h2><div class="menu-footer-2-container"><ul id="menu-footer-2" class="menu"><li id="menu-item-560" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-560"><a href="https://www.sliderrevolution.com/help-center/">Help Center</a></li>
<li id="menu-item-561" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-561"><a href="https://www.sliderrevolution.com/manual/">Manual</a></li>
<li id="menu-item-562" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-562"><a href="https://www.sliderrevolution.com/faq/">FAQs</a></li>
<li id="menu-item-30293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30293"><a href="https://www.sliderrevolution.com/contact/">Contact Us</a></li>
<li id="menu-item-30283" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30283"><a href="https://www.sliderrevolution.com/complaints/">Complaints</a></li>
<li id="menu-item-30487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30487"><a href="https://www.sliderrevolution.com/dmca/">DMCA</a></li>
<li id="menu-item-563" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-563"><a href="https://support.sliderrevolution.com/">Open a Ticket</a></li>
</ul></div></section>									</div>
								<div class="tg-footer-widget-area footer-sidebar-3">
											<section id="nav_menu-5" class="widget widget_nav_menu"><h2 class="widget-title">Platforms</h2><div class="menu-footer-3-container"><ul id="menu-footer-3" class="menu"><li id="menu-item-580" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-580"><a href="https://www.sliderrevolution.com/">WordPress <span class="rs-curv">v6.x</span></a></li>
<li id="menu-item-19868" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19868"><a target="_blank" href="https://apps.shopify.com/revolution-slider?utm_source=web&#038;utm_medium=footer&#038;utm_campaign=sliderrev">Shopify <span class="rs-oldv">v6.x</span></a></li>
<li id="menu-item-1053" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1053"><a target="_blank" href="https://www.themepunch.com/links/slider_revolution_magento">Magento <span class="rs-oldv">v6.2</span></a></li>
<li id="menu-item-833" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-833"><a target="_blank" href="https://classydevs.com/slider-revolution-prestashop/">Prestashop <span class="rs-oldv">v6.x</span></a></li>
<li id="menu-item-21627" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-21627"><a href="https://t3planet.de/en/typo3-slider-revolution-extension?utm_source=sliderrevolution.com&#038;utm_medium=banner&#038;utm_campaign=referral">TYPO3  <span class="rs-oldv">v6.x</span></a></li>
<li id="menu-item-16464" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16464"><a target="_blank" href="https://www.essential-grid.com">Essential Grid Gallery</a></li>
</ul></div></section>									</div>
								<div class="tg-footer-widget-area footer-sidebar-4">
											<section id="nav_menu-6" class="widget widget_nav_menu"><h2 class="widget-title">Resources</h2><div class="menu-footer-4-container"><ul id="menu-footer-4" class="menu"><li id="menu-item-1056" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1056"><a href="https://account.sliderrevolution.com/portal/pricing/">Pricing</a></li>
<li id="menu-item-1057" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1057"><a href="https://www.sliderrevolution.com/terms/">Terms of Use</a></li>
<li id="menu-item-1058" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1058"><a href="https://www.sliderrevolution.com/terms/site-notice/">Legal Disclosure (Impressum)</a></li>
<li id="menu-item-1078" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1078"><a rel="privacy-policy" href="https://www.sliderrevolution.com/terms/privacy/">Privacy Policy (Datenschutz)</a></li>
<li id="menu-item-1059" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1059"><a href="https://www.sliderrevolution.com/terms/license/">Licensing</a></li>
<li id="menu-item-30280" class="wt-cli-manage-consent-link menu-item menu-item-type-custom menu-item-object-custom menu-item-30280"><a href="#">Cookie policy (GDPR)</a></li>
<li id="menu-item-30488" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30488"><a href="https://www.sliderrevolution.com/sitemap/">Sitemap</a></li>
<li id="menu-item-1077" class="openNewsletter menu-item menu-item-type-custom menu-item-object-custom menu-item-1077"><a href="#">Newsletter</a></li>
</ul></div></section>									</div>
				</div> <!-- /.tg-footer-widget-container -->
			</div><!-- /.tg-container-->
		</div><!-- /.tg-site-footer-widgets -->

		
		
		<div class="tg-site-footer-bar tg-site-footer-bar--left">
			<div class="tg-container tg-container--flex tg-container--flex-top">
				<div class="tg-site-footer-section-1">

					<a class="tp-footer-social tp-yt lazyload" href="https://www.youtube.com/user/ThemePunch" target="_blank" aria-label="YouTube" rel="noopener"><span class="tp-social-fix">YouTube</span></a><a class="tp-footer-social tp-fb lazyload" href="https://www.facebook.com/official.sliderrevolution" aria-label="Facebook" target="_blank" rel="noopener"><span class="tp-social-fix">Facebook</span></a><a class="tp-footer-social tp-tw lazyload" href="https://twitter.com/revslider" target="_blank" aria-label="Twitter" rel="noopener"><span class="tp-social-fix">Twitter</span></a><a class="tp-footer-social tp-ig lazyload" href="https://www.instagram.com/sliderrevolution" target="_blank" aria-label="Instagram" rel="noopener"><span class="tp-social-fix">Instagram</span></a><a class="tp-footer-social tp-pi lazyload" aria-label="Pinterest" href="https://www.pinterest.com/sliderrevolution/" target="_blank" rel="noopener"><span class="tp-social-fix">Pinterest</span></a><a class="tp-footer-social tp-dr lazyload" href="https://www.dribbble.com/sliderrevolution" aria-label="dribbble" target="_blank" rel="noopener"><span class="tp-social-fix">Dribbble</span></a>
				</div>
				<!-- /.tg-site-footer-section-1 -->

				<div class="tg-site-footer-section-2">

					<div class="tp-copyright">© Copyright 2025 by ThemePunch OHG</div>
				</div>
				<!-- /.tg-site-footer-section-2 -->
			</div>
			<!-- /.tg-container-->
		</div>
		<!-- /.tg-site-footer-bar -->

		
			</footer><!-- #colophon -->
		
<div class="tp-headerbg"><div class="tp-headerbggradient"></div><div class="tp-headerbgimage"></div></div>
	 		 <script>

			setTimeout(function() {
				var script = document.createElement('script');
				script.type = 'text/javascript';
				script.src = '//code.tidio.co/40fj7u3r0arvgnplj5phv7n2onicaamn.js';
				script.defer = true;
				document.getElementsByTagName('head')[0].appendChild(script);
			},2000);
		</script>

	 
				<!--script id="mcjs">!function(c,h,i,m,p){m=c.createElement(h),p=c.getElementsByTagName(h)[0],m.async=1,m.src=i,p.parentNode.insertBefore(m,p)}(document,"script","https://chimpstatic.com/mcjs-connected/js/users/a5738148e5ec630766e28de16/7a4e02b8ff6ec26eeb91de76e.js");</script-->
						</div><!-- #page -->
		
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/SliderRevolution\/*","\/wp-content\/themes\/zakra\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<script>var ajaxRevslider;function rsCustomAjaxContentLoadingFunction(){ajaxRevslider=function(obj){var content='',data={action:'revslider_ajax_call_front',client_action:'get_slider_html',token:'ab2621b576',type:obj.type,id:obj.id,aspectratio:obj.aspectratio};jQuery.ajax({type:'post',url:'https://www.sliderrevolution.com/wp-admin/admin-ajax.php',dataType:'json',data:data,async:false,success:function(ret,textStatus,XMLHttpRequest){if(ret.success==true)content=ret.data;},error:function(e){console.log(e);}});return content;};var ajaxRemoveRevslider=function(obj){return jQuery(obj.selector+' .rev_slider').revkill();};if(jQuery.fn.tpessential!==undefined)if(typeof(jQuery.fn.tpessential.defaults)!=='undefined')jQuery.fn.tpessential.defaults.ajaxTypes.push({type:'revslider',func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});}var rsCustomAjaxContent_Once=false;if(document.readyState==="loading")document.addEventListener('readystatechange',function(){if((document.readyState==="interactive"||document.readyState==="complete")&&!rsCustomAjaxContent_Once){rsCustomAjaxContent_Once=true;rsCustomAjaxContentLoadingFunction();}});else{rsCustomAjaxContent_Once=true;rsCustomAjaxContentLoadingFunction();}</script><script type="text/javascript">jQuery(document).ready(function(){jQuery(".tp-latest-version").html("6.7.38");});</script><script id="wccBannerTemplate_GDPR" type="text/template"><div class="wcc-overlay wcc-hide"></div><div class="wcc-consent-container wcc-hide"> <div class="wcc-consent-bar" data-tag="notice" style="background-color:#FFFFFF;border-color:#f4f4f4">  <div class="wcc-notice"> <p class="wcc-title" data-tag="title" style="color:#212121">We value your privacy</p><div class="wcc-notice-group"> <div class="wcc-notice-des" data-tag="description" style="color:#212121"> <div class="cli-bar-container cli-style-v2">
<div class="rs-cookie"> </div>
<div class="rs-cookietext">This website uses cookies to improve your experience. By using this website you agree to our <a href="https://sliderrevolution.com/terms/privacy/">Data Protection Policy</a>.</div>
</div> </div><div class="wcc-notice-btn-wrapper" data-tag="notice-buttons"> <button class="wcc-btn wcc-btn-customize" aria-label="Customize" data-tag="settings-button" style="color:#F7345E;background-color:transparent;border-color:#F7345E">Customize</button>  <button class="wcc-btn wcc-btn-accept" aria-label="Accept All" data-tag="accept-button" style="color:#FFFFFF;background-color:#F7345E;border-color:#F7345E">Accept All</button>  </div></div></div></div></div><div class="wcc-modal"> <div class="wcc-preference-center" data-tag="detail" style="color:#212121;background-color:#FFFFFF;border-color:#f4f4f4"> <div class="wcc-preference-header"> <span class="wcc-preference-title" data-tag="detail-title" style="color:#212121">Customize Consent Preferences</span> <button class="wcc-btn-close" aria-label="[wcc_preference_close_label]" data-tag="detail-close"> <img src="https://www.sliderrevolution.com/wp-content/plugins/webtoffee-cookie-consent/lite/frontend/images/close.svg" alt="Close"> </button> </div><div class="wcc-preference-body-wrapper"> <div class="wcc-preference-content-wrapper" data-tag="detail-description" style="color:#212121"> <p>We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.</p><p>The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. </p><p>We also use third-party cookies that help us analyze how you use this website, store your preferences, and provide the content and advertisements that are relevant to you. These cookies will only be stored in your browser with your prior consent.</p><p>You can choose to enable or disable some or all of these cookies but disabling some of them may affect your browsing experience.</p> </div> <div class="wcc-google-privacy-policy" data-tag="google-privacy-policy">  </div><div class="wcc-accordion-wrapper" data-tag="detail-categories"> <div class="wcc-accordion" id="wccDetailCategorynecessary"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Necessary" data-tag="detail-category-title" style="color:#212121">Necessary</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchnecessary"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>__cf_bm</div></li><li><div>Duration</div><div>1 hour</div></li><li><div>Description</div><div>This cookie, set by Cloudflare, is used to support Cloudflare Bot Management. </div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>wt_consent</div></li><li><div>Duration</div><div>1 year</div></li><li><div>Description</div><div>Used for remembering users’ consent preferences to be respected on subsequent site visits. It does not collect or store personal information about visitors to the site.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>cf_ob_info</div></li><li><div>Duration</div><div>1 minute</div></li><li><div>Description</div><div>The cf_ob_info cookie is set by Cloudflare to provide information on HTTP Status Code returned by the origin web server, the Ray ID of the original failed request and the data center serving the traffic.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>cf_use_ob</div></li><li><div>Duration</div><div>1 minute</div></li><li><div>Description</div><div>Cloudflare sets this cookie to improve page load times and to disallow any security restrictions based on the visitor's IP address.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>PHPSESSID</div></li><li><div>Duration</div><div>session</div></li><li><div>Description</div><div>This cookie is native to PHP applications. The cookie stores and identifies a user's unique session ID to manage user sessions on the website. The cookie is a session cookie and will be deleted when all the browser windows are closed.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>cookietest</div></li><li><div>Duration</div><div>session</div></li><li><div>Description</div><div>The cookietest cookie is typically used to determine whether the user's browser accepts cookies, essential for website functionality and user experience.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>euconsent</div></li><li><div>Duration</div><div>1 year</div></li><li><div>Description</div><div>CookieYes sets this cookie to store data when IAB TCF is enabled.</div></li></ul></div> </div> </div><div class="wcc-accordion" id="wccDetailCategoryfunctional"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Functional" data-tag="detail-category-title" style="color:#212121">Functional</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchfunctional"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>ytidb::LAST_RESULT_ENTRY_KEY</div></li><li><div>Duration</div><div>never</div></li><li><div>Description</div><div>The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future.</div></li></ul></div> </div> </div><div class="wcc-accordion" id="wccDetailCategoryanalytics"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Analytics" data-tag="detail-category-title" style="color:#212121">Analytics</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchanalytics"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>IR_gbd</div></li><li><div>Duration</div><div>session</div></li><li><div>Description</div><div>Impact Radius sets this cookie to store a unique ID which is used to identify the user's device, when they return to the websites that used the same network.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>IR_*</div></li><li><div>Duration</div><div>session</div></li><li><div>Description</div><div>Impact Radius sets this cookie to store a unique ID which is used to identify the user's device when they return to the websites that use the same network.	</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>_ga</div></li><li><div>Duration</div><div>1 year 1 month 4 days</div></li><li><div>Description</div><div>Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>_ga_*</div></li><li><div>Duration</div><div>1 year 1 month 4 days</div></li><li><div>Description</div><div>Google Analytics sets this cookie to store and count page views.</div></li></ul></div> </div> </div><div class="wcc-accordion" id="wccDetailCategoryperformance"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Performance" data-tag="detail-category-title" style="color:#212121">Performance</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchperformance"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="wcc-empty-cookies-text">No cookies to display.</p></div> </div> </div><div class="wcc-accordion" id="wccDetailCategoryadvertisement"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Advertisement" data-tag="detail-category-title" style="color:#212121">Advertisement</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchadvertisement"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>YSC</div></li><li><div>Duration</div><div>session</div></li><li><div>Description</div><div>Youtube sets this cookie to track the views of embedded videos on Youtube pages.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>VISITOR_INFO1_LIVE</div></li><li><div>Duration</div><div>6 months</div></li><li><div>Description</div><div>YouTube sets this cookie to measure bandwidth, determining whether the user gets the new or old player interface.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>VISITOR_PRIVACY_METADATA</div></li><li><div>Duration</div><div>6 months</div></li><li><div>Description</div><div>YouTube sets this cookie to store the user's cookie consent state for the current domain.	</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>yt.innertube::nextId</div></li><li><div>Duration</div><div>never</div></li><li><div>Description</div><div>YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>yt.innertube::requests</div></li><li><div>Duration</div><div>never</div></li><li><div>Description</div><div>YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen.</div></li></ul></div> </div> </div><div class="wcc-accordion" id="wccDetailCategoryothers"> <div class="wcc-accordion-item"> <div class="wcc-accordion-chevron"><i class="wcc-chevron-right"></i></div> <div class="wcc-accordion-header-wrapper"> <div class="wcc-accordion-header"><button class="wcc-accordion-btn" aria-label="Others" data-tag="detail-category-title" style="color:#212121">Others</button><span class="wcc-always-active">Always Active</span> <div class="wcc-switch" data-tag="detail-category-toggle"><input type="checkbox" id="wccSwitchothers"></div> </div> <div class="wcc-accordion-header-des" data-tag="detail-category-description" style="color:#212121"> <p>Other cookies are those that are being identified and have not been classified into any category as yet.</p></div> </div> </div> <div class="wcc-accordion-body"> <div class="wcc-audit-table" data-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>wpcaptcha_captcha_4918</div></li><li><div>Duration</div><div>5 minutes</div></li><li><div>Description</div><div>Description is currently not available.</div></li></ul><ul class="wcc-cookie-des-table"><li><div>Cookie</div><div>wpcaptcha_captcha_9039</div></li><li><div>Duration</div><div>5 minutes</div></li><li><div>Description</div><div>Description is currently not available.</div></li></ul></div> </div> </div> </div></div><div class="wcc-footer-wrapper"> <span class="wcc-footer-shadow"></span> <div class="wcc-prefrence-btn-wrapper" data-tag="detail-buttons">  <button class="wcc-btn wcc-btn-preferences" aria-label="Save My Preferences" data-tag="detail-save-button" style="color:#000000;background-color:transparent;border-color:#000000"> Save My Preferences </button> <button class="wcc-btn wcc-btn-accept" aria-label="Accept All" data-tag="detail-accept-button" style="color:#FFFFFF;background-color:#F7345E;border-color:#F7345E"> Accept All </button> </div></div></div></div></script>		<div class='asp_hidden_data' id="asp_hidden_data" style="display: none !important;">
			<svg style="position:absolute" height="0" width="0">
				<filter id="aspblur">
					<feGaussianBlur in="SourceGraphic" stdDeviation="4"/>
				</filter>
			</svg>
			<svg style="position:absolute" height="0" width="0">
				<filter id="no_aspblur"></filter>
			</svg>
		</div>
		<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/blog-newsletter-gutenberg-block/front/dist/js/tp-newsletter-block.min.js?ver=2.0.2" id="mailchimp-scripts-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/themepunch-beta-tester/assets/js/validation.js?ver=1.0" id="themepunch-beta-validation-js"></script>
<script type="text/javascript" id="rocket-browser-checker-js-after">
/* <![CDATA[ */
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-extra">
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"\/video-tutorials\/|\/faq\/triggering-slide-change-on-another-slider\/|\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index.php\/)?(.*)wp-json(\/.*|$)|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https:\/\/www.sliderrevolution.com","onHoverDelay":"100","rateThrottle":"3"};
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-after">
/* <![CDATA[ */
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
/* ]]> */
</script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/themes/SliderRevolution/screen.js?ver=6.8.2" id="child-scripts-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/themes/zakra/assets/js/navigation.min.js?ver=20151215" id="zakra-navigation-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/themes/zakra/assets/js/skip-link-focus-fix.min.js?ver=20151215" id="zakra-skip-link-focus-fix-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/themes/zakra/assets/js/zakra-custom.min.js?ver=6.8.2" id="zakra-custom-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/cache/asp/asp-c65f18e5.min.js?ver=Y98z1C" id="asp-c65f18e5-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/lazy-loading-responsive-images/js/lazysizes.min.js?ver=1713134210" id="lazysizes-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/lazy-loading-responsive-images/js/ls.unveilhooks.min.js?ver=1713134210" id="lazysizes-unveilhooks-js"></script>
<script type="text/javascript" src="https://www.sliderrevolution.com/wp-content/plugins/sr-documentation/sr-documentation-tooltip.js?ver=6.8.2" id="sr_documentation_tooltip-js"></script>
<!-- BEGIN PLERDY CODE -->
	<script type="text/javascript" defer data-plerdy_code='1'>
		var _protocol="https:"==document.location.protocol?"https://":"http://";
		_site_hash_code = "4e82a435b78a8af7cf2ec876143723ed",_suid=53728, plerdyScript=document.createElement("script");
		plerdyScript.setAttribute("defer",""),plerdyScript.dataset.plerdymainscript="plerdymainscript",
		plerdyScript.src="https://a.plerdy.com/public/js/click/main.js?v="+Math.random();
		var plerdymainscript=document.querySelector("[data-plerdymainscript='plerdymainscript']");
		plerdymainscript&&plerdymainscript.parentNode.removeChild(plerdymainscript);
		try{document.head.appendChild(plerdyScript)}catch(t){console.log(t,"unable add script tag")}
	</script>
<!-- END PLERDY CODE -->
    
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"56cfbcd85a4e43969585f2283a6bb63b","server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>
