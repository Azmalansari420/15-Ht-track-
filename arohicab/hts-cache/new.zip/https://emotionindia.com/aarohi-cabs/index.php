<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aarohi Cabs</title>

   

   

    <!-- Favicon -->
    <link rel="icon" href="img/favi.png" type="image/x-icon">
   

    <!-- Theme Settings Js -->
	<script src="assets/js/theme-script.js"></script>

    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Main.css -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">

    <!-- Tabler Icon CSS -->
    <link rel="stylesheet" href="assets/plugins/tabler-icons/tabler-icons.css">

    <!-- Fontawesome Icon CSS -->
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Fancybox CSS -->
    <link rel="stylesheet" href="assets/plugins/fancybox/jquery.fancybox.min.css">

    <!-- Owlcarousel CSS -->
    <link rel="stylesheet" href="assets/plugins/owlcarousel/owl.carousel.min.css">
    
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/plugins/slick/slick.css">

    <!-- Iconsax CSS -->
    <link rel="stylesheet" href="assets/css/iconsax.css">

    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        .tt img{width:100%;height:250px;}
        .aa img{width:100%;height:220px;}
        @media only screen and (max-width: 768px) {
          .aa img{width:100%;height:250px!important;}
        }
    </style>
    
     <style>
    .rate-item {
        padding: 10px;
    }

    .rate-header-content {
        margin: 15px 0;
        text-align: center;
    }
    .rate-item {
    
    position: relative;
    overflow: hidden;
    background: var(--color-white);
    margin-bottom: 25px;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgb(6 22 58 / 10%);
    transition: all .9sease-in-out;
    z-index: 1;
}
.rate-header-content h4 {
    margin-bottom: 0;
    font-size: 22px;
    text-transform: uppercase;
}
.rate-content {
    background: #000;
    padding: 30px;
    border-radius: 20px;
    position: relative;
    z-index: 1;
}
.rate-content::before {
    content: "";
    position: absolute;
    background-image: url(assets/img/shape-4.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    opacity: .15;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    z-index: -1;
}
.rate-feature ul li {
    position: relative;
    margin: 10px 0;
    color: #fff;
}
.rate-feature ul li i {
    color: #cf3425;
    margin-right: 5px;
}
</style>

</head>
<body>

    <div class="main-header">
   <!-- Header Topbar-->
   <div class="header-topbar text-center bg-transparent">
      <div class="container">
         <div class="d-flex align-items-center justify-content-between flex-wrap">
            <p class="d-flex align-items-center fw-medium fs-14 mb-2"><i class="isax isax-call5 me-2"></i>Contact No. : +91 9356779356</p>
            <div class="d-flex align-items-center">
               <p class="mb-2 me-3 d-flex align-items-center fw-medium fs-14"><i class="isax isax-message-text-15 me-2"></i>Email : <a href="mailto:info@aarohicabs.in" style="color:#fff;"> info@aarohicabs.in</a></p>
               
               
              
            </div>
         </div>
      </div>
   </div>
   <!-- /Header Topbar-->
   <!-- Header -->
   <header>
      <div class="container">
         <div class="offcanvas-info">
            <div class="offcanvas-wrap">
               <div class="offcanvas-detail">
                  <div class="offcanvas-head">
                     <div class="d-flex justify-content-between align-items-center mb-3">
                        <a href="index.php" class="black-logo-responsive">
                        <img src="img/logo.png" alt="logo-img" style="max-width:220px;">
                        </a>
                        <a href="index.php" class="white-logo-responsive">
                        <img src="img/logo.png" alt="logo-img" style="max-width:220px;">
                        </a>
                        <div class="offcanvas-close">
                           <i class="ti ti-x"></i>
                        </div>
                     </div>
                     
                  </div>
                  <div class="mobile-menu fix mb-3"></div>
                  <div class="offcanvas__contact">
                     <div class="mt-4">
                        
                        <!--<div><a href="#" class="text-white btn btn-dark w-100 mb-3" data-bs-toggle="modal" data-bs-target="#login-modal">Contact Us</a></div>-->
                        <a href="enquiry.php" class="btn btn-primary w-100">Enquiry Now</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="offcanvas-overlay"></div>
         <div class="header-nav">
            <div class="main-menu-wrapper">
               <div class="navbar-logo">
                  <a class="logo-white header-logo" href="index.php">
                  <img src="img/logo-white1.png" class="logo" style="max-width:220px;" alt="Logo">
                  </a>
                  <a class="logo-dark header-logo" href="index.php">
                  <img src="img/logo.png" class="logo" alt="Logo" style="max-width:220px;">
                  </a>
               </div>
               <nav id="mobile-menu">
                  <ul class="main-nav">
                     <li class="has-submenu megamenu active">
                        <a href="index.php">Home</a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="about.php">About </a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="taxi-packages.php">Taxi Packages</a>
                        
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="payment.php">Payment</a>
                        
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="#">Car Rental</a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="contact.php">Contact Us</a>
                       
                     </li>
                     
                  </ul>
               </nav>
               <div class="header-btn d-flex align-items-center">
                  <!--<div class="me-3">
                     <a href="#" id="dark-mode-toggle" class="theme-toggle">
                     <i class="isax isax-moon"></i>
                     </a>
                     <a href="#" id="light-mode-toggle" class="theme-toggle">
                     <i class="isax isax-sun-1"></i>
                     </a>
                  </div>-->
                  <!--<div><a href="#" class="btn btn-white me-3" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></div>-->
                  <a href="enquiry.php" class="btn btn-primary me-0">Enquiry Now</a>
                  <div class="header__hamburger d-xl-none my-auto">
                     <div class="sidebar-menu">
                        <i class="isax isax-menu5"></i>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- /Header -->
</div>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="banner-slider banner-sec owl-carousel">
            <div class="slider-img">
                <img src="img/b1.png" alt="Img">
            </div>
            <div class="slider-img">
                <img src="img/b2.png" alt="Img">
            </div>
            <div class="slider-img">
                <img src="img/b3.png" alt="Img">
            </div>
            <div class="slider-img">
                <img src="img/b4.png" alt="Img">
            </div>
        </div>
        <div class="container">
            <div class="hero-content">
                <div class="row align-items-center">
                    <div class="col-md-12 mx-auto wow fadeInUp" data-wow-delay="0.3s">
                        <div class="banner-content mx-auto">
                            <h1 class="text-white display-5 mb-2">Get Closer to the Dream: <span>Your Tour</span> Essentials Await</h1>
                            <h6 class="text-light mx-auto">Your ultimate destination for all things help you celebrate & remember tour experience.</h6>
                        </div>
                        <div class="banner-form card mb-0">
                            <div class="card-header">
                                <ul class="nav">
                                   
                                    <li>
                                        <a href="javascript:void(0);" class="nav-link active" data-bs-toggle="tab" data-bs-target="#Cars">
                                            <i class="isax isax-car5 me-2"></i>Cabs
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a href="javascript:void(0);" class="nav-link" data-bs-toggle="tab" data-bs-target="#Tour">
                                            <i class="isax isax-camera5 me-2"></i>Tour & Travels
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body">
                                <div>
                                    <div class="tab-content">
                                        
                                        <div class="tab-pane fade active show" id="Cars">                                          
                                            <form action="#">
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-2">
                                                    <div class="d-flex align-items-center flex-wrap">
                                                        <div class="form-check d-flex align-items-center me-3 mb-2">
                                                            <input class="form-check-input mt-0" type="radio" name="drop" id="same-drop" value="same-drop" checked>
                                                            <label class="form-check-label fs-14 ms-2" for="same-drop">
                                                                Same drop-off
                                                            </label>
                                                        </div>
                                                        <div class="form-check d-flex align-items-center me-3 mb-2">
                                                            <input class="form-check-input mt-0" type="radio" name="drop" id="different-drop" value="different-drop">
                                                            <label class="form-check-label fs-14 ms-2" for="different-drop">
                                                                Different Drop off
                                                            </label>
                                                        </div>
                                                        <div class="form-check d-flex align-items-center me-3 mb-2">
                                                            <input class="form-check-input mt-0" type="radio" name="drop" id="airport" value="airport">
                                                            <label class="form-check-label fs-14 ms-2" for="airport">
                                                                Airport
                                                            </label>
                                                        </div>
                                                        <div class="form-check d-flex align-items-center me-3 mb-2">
                                                            <input class="form-check-input mt-0" type="radio" name="drop" id="hourly-drop" value="hourly-drop">
                                                            <label class="form-check-label fs-14 ms-2" for="hourly-drop">
                                                                Hourly Package
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <h6 class="fw-medium fs-16 mb-2">Book Car for rental</h6>
                                                </div>
                                                <div class="d-lg-flex">
                                                    <div class="d-flex  form-info">
                                                        <div class="form-item dropdown from-location">
                                                            <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" role="menu">
                                                                <label class="form-label fs-14 text-default mb-1">From</label>
                                                                <input type="text" class="form-control" value="Newyork">
                                                                <p class="fs-12 mb-0">USA</p>
                                                            </div>
                                                            <div class="dropdown-menu dropdown-md p-0">
                                                                <div class="input-search p-3 border-bottom">
                                                                    <div class="input-group">
                                                                        <input type="text" class="form-control" placeholder="Search for Cars">
                                                                        <span class="input-group-text px-2 border-start-0"><i class="isax isax-search-normal"></i></span>
                                                                    </div>
                                                                </div>
                                                                <ul>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">USA</h6>
                                                                            <p>2000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Japan</h6>
                                                                            <p>3000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Singapore</h6>
                                                                            <p>8000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Russia</h6>
                                                                            <p>8000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Germany</h6>
                                                                            <p>6000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="form-item dropdown pickup-airport">
                                                            <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" role="menu">
                                                                <label class="form-label fs-14 text-default mb-1">From</label>
                                                                <input type="text" class="form-control" value="Newyork">
                                                                <p class="fs-12 mb-0">Ken International Airport</p>
                                                            </div>
                                                            <div class="dropdown-menu dropdown-md p-0">
                                                                <div class="input-search p-3 border-bottom">
                                                                    <div class="input-group">
                                                                        <input type="text" class="form-control" placeholder="Search for Airport">
                                                                        <span class="input-group-text px-2 border-start-0"><i class="isax isax-search-normal"></i></span>
                                                                    </div>
                                                                </div>
                                                                <ul>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Hartsfield-Jackson Atlanta International</h6>
                                                                            <p>USA</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Dallas/Fort Worth International</h6>
                                                                            <p>USA</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">London Heathrow</h6>
                                                                            <p>UK</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Seoul Incheon</h6>
                                                                            <p>South Korea</p>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Singapore Changi International</h6>
                                                                            <p>Singapore</p>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="form-item dropdown to-location ps-2 ps-sm-3">
                                                            <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" role="menu">
                                                                <label class="form-label fs-14 text-default mb-1">To</label>
                                                                <input type="text" class="form-control" value="Newyork">
                                                                <p class="fs-12 mb-0">USA</p>
                                                                <span class="way-icon badge badge-primary rounded-pill translate-middle">
                                                                    <i class="fa-solid fa-arrow-right-arrow-left"></i>
                                                                </span>
                                                            </div>
                                                            <div class="dropdown-menu dropdown-md p-0">
                                                                <div class="input-search p-3 border-bottom">
                                                                    <div class="input-group">
                                                                        <input type="text" class="form-control" placeholder="Search for Cars">
                                                                        <span class="input-group-text px-2 border-start-0"><i class="isax isax-search-normal"></i></span>
                                                                    </div>
                                                                </div>
                                                                <ul>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">USA</h6>
                                                                            <p>2000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Japan</h6>
                                                                            <p>3000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Singapore</h6>
                                                                            <p>8000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Russia</h6>
                                                                            <p>8000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Germany</h6>
                                                                            <p>6000 Cars</p>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="form-item">
                                                            <label class="form-label fs-14 text-default mb-1">Departure</label>
                                                            <input type="text" class="form-control datetimepicker" value="21-10-2024">
                                                            <p class="fs-12 mb-0">Monday</p>
                                                        </div>
                                                        <div class="form-item return-drop">
                                                            <label class="form-label fs-14 text-default mb-1">Return</label>
                                                            <input type="text" class="form-control datetimepicker" value="23-10-2024">
                                                            <p class="fs-12 mb-0">Wednesday</p>
                                                        </div>
                                                        <div class="form-item">
                                                            <label class="form-label fs-14 text-default mb-1">Pickup Time</label>
                                                            <input type="text" class="form-control timepicker" value="11:45 PM">
                                                        </div>
                                                        <div class="form-item dropoff-time">
                                                            <label class="form-label fs-14 text-default mb-1">Dropoff Time</label>
                                                            <input type="text" class="form-control timepicker" value="11:45 PM">
                                                        </div>
                                                        <div class="form-item hourly-time">
                                                            <label class="form-label fs-14 text-default mb-1">Hours</label>
                                                            <h5>02 Hrs 10 Kms</h5>
                                                        </div>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary search-btn rounded">Search</button>
                                                </div>
                                            </form>
                                        </div>
                                        
                                        <div class="tab-pane fade" id="Tour">                                          
                                            <form action="#">
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-2">
                                                    <h6 class="fw-medium fs-16 mb-2">Search holiday packages & trips</h6>
                                                </div>
                                                <div class="d-lg-flex">
                                                    <div class="d-flex  form-info">
                                                        <div class="form-item dropdown">
                                                            <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" role="menu">
                                                                <label class="form-label fs-14 text-default mb-1">Where would like to go?</label>
                                                                <input type="text" class="form-control" value="Newyork">
                                                                <p class="fs-12 mb-0">USA</p>
                                                            </div>
                                                            <div class="dropdown-menu dropdown-md p-0">
                                                                <div class="input-search p-3 border-bottom">
                                                                    <div class="input-group">
                                                                        <input type="text" class="form-control" placeholder="Search for City, Property name or Location">
                                                                        <span class="input-group-text px-2 border-start-0"><i class="isax isax-search-normal"></i></span>
                                                                    </div>
                                                                </div>
                                                                <ul>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">USA</h6>
                                                                            <p>200 Places</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Japan</h6>
                                                                            <p>300 Places</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Singapore</h6>
                                                                            <p>80 Places</p>
                                                                        </a>
                                                                    </li>
                                                                    <li class="border-bottom">
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Russia</h6>
                                                                            <p>500 Places</p>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a class="dropdown-item" href="javascript:void(0);">
                                                                            <h6 class="fs-16 fw-medium">Germany</h6>
                                                                            <p>150 Places</p>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="form-item">
                                                            <label class="form-label fs-14 text-default mb-1">Dates</label>
                                                            <input type="text" class="form-control datetimepicker" value="21-10-2025">
                                                            <p class="fs-12 mb-0">Monday</p>
                                                        </div>
                                                        <div class="form-item">
                                                            <label class="form-label fs-14 text-default mb-1">Check Out</label>
                                                            <input type="text" class="form-control datetimepicker" value="21-10-2025">
                                                            <p class="fs-12 mb-0">Wednesday</p>
                                                        </div>
                                                        <div class="form-item dropdown">
                                                            <div data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" role="menu">
                                                                <label class="form-label fs-14 text-default mb-1">Travellers</label>
                                                                <h5>4 <span class="fw-normal fs-14">Persons</span></h5>
                                                                <p class="fs-12 mb-0">2 Adult</p>
                                                            </div>
                                                            <div class="dropdown-menu dropdown-menu-end dropdown-xl">
                                                                <h5 class="mb-3">Select Travelers</h5>
                                                                <div class="mb-3 border br-10 info-item pb-1">
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                                                            <div class="mb-3 d-flex align-items-center justify-content-between">
                                                                                <label class="form-label text-gray-9 mb-2">Adult</label>
                                                                                <div class="custom-increment">
                                                                                    <div class="input-group">
                                                                                        <span class="input-group-btn float-start">
                                                                                            <button type="button" class="quantity-left-minus btn btn-light btn-number"  data-type="minus" data-field="">
                                                                                            <span><i class="isax isax-minus"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                        <input type="text" name="quantity" class=" input-number" value="01">
                                                                                        <span class="input-group-btn float-end">
                                                                                            <button type="button" class="quantity-right-plus btn btn-light btn-number" data-type="plus" data-field="">
                                                                                                <span><i class="isax isax-add"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="mb-3 d-flex align-items-center justify-content-between">
                                                                                <label class="form-label text-gray-9 mb-2">Childrens <span class="text-default fw-normal">( 12+ Yrs )</span></label>
                                                                                <div class="custom-increment">
                                                                                    <div class="input-group">
                                                                                        <span class="input-group-btn float-start">
                                                                                            <button type="button" class="quantity-left-minus btn btn-light btn-number"  data-type="minus" data-field="">
                                                                                            <span><i class="isax isax-minus"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                        <input type="text" name="quantity" class=" input-number" value="01">
                                                                                        <span class="input-group-btn float-end">
                                                                                            <button type="button" class="quantity-right-plus btn btn-light btn-number" data-type="plus" data-field="">
                                                                                                <span><i class="isax isax-add"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="mb-3 d-flex align-items-center justify-content-between">
                                                                                <label class="form-label text-gray-9 mb-2">Infants <span class="text-default fw-normal">( 12+ Yrs )</span></label>
                                                                                <div class="custom-increment">
                                                                                    <div class="input-group">
                                                                                        <span class="input-group-btn float-start">
                                                                                            <button type="button" class="quantity-left-minus btn btn-light btn-number"  data-type="minus" data-field="">
                                                                                            <span><i class="isax isax-minus"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                        <input type="text" name="quantity" class=" input-number" value="01">
                                                                                        <span class="input-group-btn float-end">
                                                                                            <button type="button" class="quantity-right-plus btn btn-light btn-number" data-type="plus" data-field="">
                                                                                                <span><i class="isax isax-add"></i></span>
                                                                                        </button>
                                                                                        </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex justify-content-end">
                                                                    <a href="javascript:void(0);" class="btn btn-light btn-sm me-2">Cancel</a>
                                                                    <button type="submit" class="btn btn-primary btn-sm">Apply</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary search-btn rounded">Search</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /Hero Section -->
    
    <!-- About Section -->
    <section class="section about-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about-image mb-4 mb-lg-0">
                        
                        <div class="about-img">
                            <img src="img/about.webp" alt="about">
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-content">
                        <h6 class="text-primary fs-14 fw-medium mb-2">About Aarohi Cabs</h6>
                        <h2 class="display-6 mb-2">Car Rental Service in Delhi to Ayodhya - Local & Outstation Cabs</h2>
                        <p class="mb-4">Aarohi Cabs Is A Leading tour & travel, destination mangement company based out of. We feel proud to introduce ourselves as India’s leading tour operators.Our company key focus is on customer satisfaction and travel safety which is taken care by our skilled and professional tour manager, guides and driver. Aarohi Cab has been around since the early 2015 and has made tour plans for over 50000 travelers who came to India and the number is still growing. We ensure that every tour for our guest should be a memorable experience for them, their happy faces would be our treat. We take care of every minor details and keep a good look feedbacks as it guides us to make further changes in our futures tours. Our team is always there for our customers 24/7 ,we train our drivers and guide as such so they can be always alert and ready for our customers question and needs.From first time travellers to once-a-year holiday seekers, from those bitten by the travel bug to the globetrotters smitten by wanderlust, Aarohi Cab is that one travel companion who everyone loves to have on their side.</p>
                        
                    </div>
                    
                </div>
                <div class="col-md-12">
                    <div class="counter-wrap">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="counter-item mb-4">
                                    <h6 class="mb-1 d-flex align-items-center justify-content-center text-teal"><i class="isax isax-global5 me-2"></i>Available Taxi</h6>
                                    <h3 class="display-6"><span class="counter">500</span>+</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter-item mb-4">
                                    <h6 class="mb-1 d-flex align-items-center justify-content-center text-purple"><i class="isax isax-tag-user5 me-2"></i>Our Drivers</h6>
                                    <h3 class="display-6"><span class="counter">700</span>+</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter-item mb-4">
                                    <h6 class="mb-1 d-flex align-items-center justify-content-center text-pink"><i class="isax isax-tag-user5 me-2"></i>Happy Clients</h6>
                                    <h3 class="display-6"><span class="counter">1000</span>+</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="counter-item mb-4">
                                    <h6 class="mb-1 d-flex align-items-center justify-content-center text-info"><i class="isax isax-status-up5 me-2"></i>Road Trip Done</h6>
                                    <h3 class="display-6"><span class="counter">1900</span>+</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-bg">
                <img src="assets/img/bg/about-bg.png" alt="img" class="about-bg-01">
                <img src="assets/img/bg/about-bg-01.svg" alt="img" class="about-bg-02">
            </div>
        </div>
    </section>
    <!-- /About Section -->
    
    
    <!-- Blog Section -->
    <section class="section blog-section tt">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-12 col-lg-10 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">The Best Taxi Services in <span class="text-primary text-decoration-underline">Delhi According to Your Need</span></h2>
                        <p class="sub-title">We provide you the best <strong>Taxi Services in Delhi</strong> are straightforward - what you see is what you get. India is a country that offers a wide range of experiences, from cultural places to beautiful landscapes. But it is known mainly for the wonder of the world, the Taj Mahal. Every day, thousands of people visit in delhi, the home of this spectacular monument. Follow the rules and policies, and your Same Day Taj Mahal Tour By Car from Delhi will be a memorable trip to delhi.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="img/t1.jpg" alt="img">
                        </a>
                       
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">Sedan</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="img/t2.jpg" alt="img">
                        </a>
                       
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">SUV</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="img/t3.jpg" alt="img">
                        </a>
                        
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">Tempo Traveller</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

            </div>
            <div class="text-center view-all wow fadeInUp">
                <a href="#" class="btn btn-dark d-inline-flex align-items-center">Book Now<i class="isax isax-arrow-right-3 ms-2"></i></a>
            </div>
        </div>
    </section>
    <!-- /Blog Section -->

    <!-- Destination Section -->
    <section class="section destination-section aa">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-10 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">Local  <span class="text-primary  text-decoration-underline">Ayodhya </span> Sight Seening </h2>
                        <!--<p class="sub-title">DreamsTour Marketplace is a platform designed to connect fans with exclusive experiences related to a specific tour</p>-->
                    </div>
                </div>
            </div>
            <div class="owl-carousel destination-slider nav-center">

                <!-- Destination Item-->
                <div class="destination-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                    <img src="img/s1.webp" alt="img">
                    <div class="destination-info text-center">
                        <div class="destination-content">
                            <h5 class="mb-1 text-white">Ayodhya from Delhi</h5>
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="rating d-flex align-items-center me-2">
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled"></i>
                                </div>
                                <p class="fs-14 text-white">452 Reviews</p>
                            </div>
                        </div>
                        <!--<div class="destination-overlay bg-white mt-2">
                            <div class="d-flex">
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-indigo">
											<i class="isax isax-airplane"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">21 Flights</h6>
                                    </div>
                                </div>
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-cyan">
											<i class="isax isax-buildings"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">15 Hotels</h6>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-success">
											<i class="isax isax-ship"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">06 Cruises</h6>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <a href="#" class="overlay-circle-link"><i class="isax isax-arrow-right-1"></i></a>
                </div>
                <!-- /Destination Item-->

                <!-- Destination Item-->
                <div class="destination-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                    <img src="img/s2.jpg" alt="img">
                    <div class="destination-info text-center">
                        <div class="destination-content">
                            <h5 class="mb-1 text-white">Haridwar Tour by Car from Delhi</h5>
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="rating d-flex align-items-center me-2">
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled"></i>
                                </div>
                                <p class="fs-14 text-white">400 Reviews</p>
                            </div>
                        </div>
                        <!--<div class="destination-overlay bg-white mt-2">
                            <div class="d-flex">
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-indigo">
											<i class="isax isax-airplane"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">21 Flights</h6>
                                    </div>
                                </div>
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-cyan">
											<i class="isax isax-buildings"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">15 Hotels</h6>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-success">
											<i class="isax isax-ship"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">06 Cruises</h6>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <a href="#" class="overlay-circle-link"><i class="isax isax-arrow-right-1"></i></a>
                </div>
                <!-- /Destination Item-->

                <!-- Destination Item-->
                <div class="destination-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                    <img src="img/s3.jpg" alt="img">
                    <div class="destination-info text-center">
                        <div class="destination-content">
                            <h5 class="mb-1 text-white">Rishikesh Tour by Car from Delhi</h5>
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="rating d-flex align-items-center me-2">
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled"></i>
                                </div>
                                <p class="fs-14 text-white">400 Reviews</p>
                            </div>
                        </div>
                       <!-- <div class="destination-overlay bg-white mt-2">
                            <div class="d-flex">
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-indigo">
											<i class="isax isax-airplane"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">21 Flights</h6>
                                    </div>
                                </div>
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-cyan">
											<i class="isax isax-buildings"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">15 Hotels</h6>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-success">
											<i class="isax isax-ship"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">06 Cruises</h6>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <a href="#" class="overlay-circle-link"><i class="isax isax-arrow-right-1"></i></a>
                </div>
                <!-- /Destination Item-->

                <!-- Destination Item-->
                <div class="destination-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                    <img src="img/s1.webp" alt="img">
                    <div class="destination-info text-center">
                        <div class="destination-content">
                            <h5 class="mb-1 text-white">Ayodhya local sight seen</h5>
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="rating d-flex align-items-center me-2">
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled me-1"></i>
                                    <i class="fa-solid fa-star filled"></i>
                                </div>
                                <p class="fs-14 text-white">422 Reviews</p>
                            </div>
                        </div>
                        <!--<div class="destination-overlay bg-white mt-2">
                            <div class="d-flex">
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-indigo">
											<i class="isax isax-airplane"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">21 Flights</h6>
                                    </div>
                                </div>
                                <div class="col border-end">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-cyan">
											<i class="isax isax-buildings"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">15 Hotels</h6>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="count-info text-center">
                                        <span class="d-block mb-1 text-success">
											<i class="isax isax-ship"></i>
										</span>
                                        <h6 class="fs-13 fw-medium">06 Cruises</h6>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                    <a href="#" class="overlay-circle-link"><i class="isax isax-arrow-right-1"></i></a>
                </div>
                <!-- /Destination Item-->

               

            </div>
            <div class="text-center view-all wow fadeInUp">
                <a href="#" class="btn btn-dark d-inline-flex align-items-center">Book Now<i class="isax isax-arrow-right-3 ms-2"></i></a>
            </div>
        </div>
    </section>
    <!-- /Destination Section -->

    <!-- Benefit Section -->
    <section class="section benefit-section bg-light-300">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">Why <span class="text-primary  text-decoration-underline">Travel</span> with us!</h2>
                        <!--<p class="sub-title">DreamsTour, a tour operator specializing in dream destinations, offers a variety of benefits for travelers.</p>-->
                    </div>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-sm-6 col-lg-4 d-flex">
                    <div class="card benefit-card mb-0 flex-fill wow fadeInUp" data-wow-delay="0.2s">
                        <div class="card-body text-center">
                            <div class="benefit-icon mb-2 bg-secondary text-gray-9 mx-auto">
                                <i class="isax isax-lock-1"></i>
                            </div>
                            <h5 class="mb-2">Stay Safe</h5>
                            <p class="mb-0">Travel with Aarohi Cab is very Safe and Trustful. Because We keep the Well Educated, Professional, and Dedication Tourist Guide. Who Keeps the Clients Safty on priority.</p>
                            <span class="icon-view text-secondary"><i class="isax isax-lock-1"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 d-flex">
                    <div class="card benefit-card mb-0 flex-fill wow fadeInUp" data-wow-delay="0.2s">
                        <div class="card-body text-center">
                            <div class="benefit-icon mb-2 bg-orange text-white mx-auto">
                                <i class="isax isax-magicpen"></i>
                            </div>
                            <h5 class="mb-2">Quality Services</h5>
                            <p class="mb-0">Aarohi Cab is specially working for serving the best Quality of Tour and Travel Package Service to all over the world. Explore the Complete Indian Monumental and Historic Places.</p>
                            <span class="icon-view text-orange"><i class="isax isax-magicpen"></i></span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 d-flex">
                    <div class="card benefit-card mb-0 flex-fill wow fadeInUp" data-wow-delay="0.2s">
                        <div class="card-body text-center">
                            <div class="benefit-icon mb-2 bg-purple text-white mx-auto">
                                <i class="isax isax-receipt-add"></i>
                            </div>
                            <h5 class="mb-2">Save Money</h5>
                            <p class="mb-0">We are also Provide the Prebooking Deals and offers on Booking. You can save money by Making a Pre-Booking for India Travel.</p>
                            <span class="icon-view text-purple"><i class="isax isax-receipt-add"></i></span>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- /Benefit Section -->

   

<div class="taxi-rate" style="padding-top:70px;padding-bottom:70px;">
    <div class="container">
        <div class="row justify-content-center">
                <div class="col-lg-6 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">Top <span class="text-primary  text-decoration-underline">Cab</span> Routes!</h2>
                        <!--<p class="sub-title">DreamsTour, a tour operator specializing in dream destinations, offers a variety of benefits for travelers.</p>-->
                    </div>
                </div>
            </div>
        
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from DELHI</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Haridwar  Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Rishikesh Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to manali Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Mussoorie Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Lucknow Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Prayagraj Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Bareilly Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Varanasi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Gorakhpur Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Ayodhya Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Budaun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Haldwani Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Moradabad Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Agra Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Mathura Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Delhi to Vrindavan Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from HALDWANI</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haldwani to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haldwani to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haldwani to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haldwani to Rishikesh Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haldwani to Agra Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from Haridwar</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haridwar to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haridwar to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haridwar to Mussoorie Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haridwar to Lucknow Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Haridwar to Nainital Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from AGRA</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Mussoorie Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Agra to Lucknow Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from DEHRADUN</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Rishikesh Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Lucknow Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Dehradun to Agra Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from RISHIKESH</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Mussoorie Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Jim Corbett Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Rishikesh to Haldwani Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from NAINITAL</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Agra Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Mussoorie Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Nainital to Haldwani Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from JIM CORBETT</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Rishikesh Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Jim Corbett to Lucknow Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from MUSSOORIE</h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie  to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Dehradun Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Rishikesh Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Nainital Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Agra Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Mussoorie to Lucknow Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from LUCKNOW </h4>
                    </div>
                    <div class="rate-content " style="max-height: 400px; overflow-y: auto;">
                        <div class="rate-feature mt-0">
                            <ul class="mb-0">

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  lucknow to Delhi Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Haridwar Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Ayodhya Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Prayagraj Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Kanpur Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Shravasti Cab</a></li>

                                <li><a href="#" class="text-white"><i class="fa fa-check-double"></i>  Lucknow to Nawabganj Bird Sanctuary / Chandra Shekar Azad Bird Sanctuary Cab</a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from CHANDIGARH</h4>
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-lg-4">
                <div class="rate-item wow fadeInUp" data-wow-delay=".25s">
                    <div class="rate-header-content">
                        <h4>Cabs from JAIPUR</h4>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>


    <!-- Testimonial Section -->
    <section class="section testimonial-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-10 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">What’s Our <span class="text-primary  text-decoration-underline">User</span> Says</h2>
                        <p class="sub-title">Aarohi Cabs, a tour operator specializing in dream destinations, offers a variety of benefits for travelers.</p>
                    </div>
                </div>
            </div>
            <div class="owl-carousel testimonial-slider">

                <!-- Testimonial Item-->
                <div class="card border-white wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-body">
                        <h6 class="mb-4">Great Hospitalization</h6>
                        <p class="mb-4">Aarohi Cabs is the only way to go. We had the time of our life on our trip to the Ark. The customer service was wonderful & the staff was very helpful.</p>
                        <div class="border-top pt-4 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <a href="javascript:void(0);" class="avatar avatar-md  flex-shrink-0">
                                    <img src="assets/t1.png" class="rounded-circle" alt="img">
                                </a>
                                <div class="ms-2">
                                    <h6 class="fs-16 fw-medium"><a href="javascript:void(0);">Ayush Badoni</a></h6>
                                    <!--<p>Newyork, United States</p>-->
                                </div>
                            </div>
                            <span class="badge badge-warning badge-xs text-gray-9 fs-13 fw-medium me-2">5.0</span>
                        </div>
                    </div>
                </div>
                <!-- /Testimonial Item-->

                <!-- Testimonial Item-->
                <div class="card border-white wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-body">
                        <h6 class="mb-4">Hidden Treasure</h6>
                        <p class="mb-4">I went on the Gone with the Wind tour, and it was my first multi-day bus tour. The experience was terrific, thanks to the friendly tour guides.</p>
                        <div class="border-top pt-4 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <a href="javascript:void(0);" class="avatar avatar-md  flex-shrink-0">
                                    <img src="assets/t2.png" class="rounded-circle" alt="img">
                                </a>
                                <div class="ms-2">
                                    <h6 class="fs-16 fw-medium"><a href="javascript:void(0);">Bharti Singh</a></h6>
                                   <!-- <p>Cape Town, South Africa</p>-->
                                </div>
                            </div>
                            <span class="badge badge-warning badge-xs text-gray-9 fs-13 fw-medium me-2">5.0</span>
                        </div>
                    </div>
                </div>
                <!-- /Testimonial Item-->

                <!-- Testimonial Item-->
                <div class="card border-white wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-body">
                        <h6 class="mb-4">Easy to Find your Leisuere Place</h6>
                        <p class="mb-4">Thanks for arranging a smooth travel experience for us. Our cab driver was polite, timely, and helpful. The team ensured making it a stress-free trip.</p>
                        <div class="border-top pt-4 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <a href="javascript:void(0);" class="avatar avatar-md  flex-shrink-0">
                                    <img src="assets/t3.png" class="rounded-circle" alt="img">
                                </a>
                                <div class="ms-2">
                                    <h6 class="fs-16 fw-medium"><a href="javascript:void(0);">Prakash Verma</a></h6>
                                    <!--<p>Paris, France</p>-->
                                </div>
                            </div>
                            <span class="badge badge-warning badge-xs text-gray-9 fs-13 fw-medium me-2">5.0</span>
                        </div>
                    </div>
                </div>
                <!-- /Testimonial Item-->

                <!-- Testimonial Item-->
                <div class="card border-white wow fadeInUp" data-wow-delay="0.2s">
                    <div class="card-body">
                        <h6 class="mb-4">Great Service</h6>
                        <p class="mb-4">We had a fantastic time as a family. There were activities for every age group, and the kids loved the kids’ club, fun activities, good customer service.</p>
                        <div class="border-top pt-4 d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <span class="avatar avatar-md  flex-shrink-0">
                                    <img src="assets/t5.png" class="rounded-circle" alt="img">
                                </span>
                                <div class="ms-2">
                                    <h6 class="fs-16 fw-medium">Jitendra Kumar</h6>
                                    <!--<p>Newyork, United States</p>-->
                                </div>
                            </div>
                            <span class="badge badge-warning badge-xs text-gray-9 fs-13 fw-medium me-2">5.0</span>
                        </div>     
                    </div>
                </div>
                <!-- /Testimonial Item-->

            </div>
        </div>
        <div class="testimonial-bg">
            <img src="assets/img/bg/testimonial-bg-01.svg" alt="img">
        </div>
    </section>
    <!-- /Testimonial Section -->

   

    

    <!-- Blog Section -->
    <section class="section blog-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-10 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="section-header text-center">
                        <h2 class="mb-2">Recent <span class="text-primary text-decoration-underline">Articles</span></h2>
                        <p class="sub-title">Aarohi Cabs offers various blog resources that cater to travel enthusiasts, with a focus on adventure, gear reviews, and travel tips.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="assets/img/blog/blog-01.jpg" alt="img">
                        </a>
                        <span class="badge bg-primary fs-13 fw-medium">Travel</span>
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">Top 10 Hidden Gems places in Central Europe in 2025</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="assets/img/blog/blog-02.jpg" alt="img">
                        </a>
                        <span class="badge bg-primary fs-13 fw-medium">Guide</span>
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">Exploring the World: Your Ultimate Aarohi Cabs Itinerary</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

                <!-- Blog Item-->
                <div class="col-lg-4 col-md-6">
                    <div class="blog-item mb-4 wow fadeInUp" data-wow-delay="0.2s">
                        <a href="#" class="blog-img">
                            <img src="assets/img/blog/blog-03.jpg" alt="img">
                        </a>
                        <span class="badge bg-primary fs-13 fw-medium">Rental</span>
                        <div class="blog-info text-center">
                            
                            <h5><a href="#">New York City, USA - The City That  Never Sleeps</a></h5>
                        </div>
                    </div>
                </div>
                <!-- /Blog Item-->

            </div>
            <div class="text-center view-all wow fadeInUp">
                <a href="#" class="btn btn-dark d-inline-flex align-items-center">View All Articles<i class="isax isax-arrow-right-3 ms-2"></i></a>
            </div>
        </div>
    </section>
    <!-- /Blog Section -->

    <!-- Support Section -->
    <!--<section class="support-section bg-primary">
        <div class="horizontal-slide d-flex" data-direction="left" data-speed="slow">
            <div class="slide-list d-flex">
                <div class="support-item">
                    <h5>Personalized Itineraries</h5>
                </div>
                <div class="support-item">
                    <h5>Comprehensive Planning</h5>
                </div>
                <div class="support-item">
                    <h5>Expert Guidance</h5>
                </div>
                <div class="support-item">
                    <h5>Local Experience</h5>
                </div>
                <div class="support-item">
                    <h5>Customer Support</h5>
                </div>
                <div class="support-item">
                    <h5>Sustainability Efforts</h5>
                </div>
                <div class="support-item">
                    <h5>Multiple Regions</h5>
                </div>
            </div>
        </div>
    </section>-->
    <!-- /Support Section -->

    <!-- Footer -->
    <a href="https://api.whatsapp.com/send?phone=919356779356" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<a href="tel:+919356779356" class="float2">
<i class="fa fa-phone my-float2"></i>
</a>
<style>
   .float{
   position:fixed;
   width:45px;
   height:45px;
   bottom:20px;
   left:20px;
   background-color:#25d366;
   color:#FFF!important;
   border-radius:50px;
   text-align:center;
   font-size:26px;
   box-shadow: 2px 2px 3px #999;
   z-index:100;
   }
   .my-float{
   margin-top:12px;
   }
   .float2{
   position:fixed;
   width:45px;
   height:45px;
   bottom:75px;
   left:20px;
   background-color:#1f74bd;
   color:#FFF!important;
   border-radius:50px;
   text-align:center;
   font-size:26px;
   box-shadow: 2px 2px 3px #999;
   z-index:100;
   }
   .my-float2{
   margin-top:12px;
   }
</style>

<footer>
        <div class="container">
            <div class="footer-top">
                <div class="row row-cols-lg-5 row-cols-md-3 row-cols-sm-2 row-cols-1">
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Quick Links</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                <li>
                                    <a href="gallery.php">Gallery</a>
                                </li>
                                <li>
                                    <a href="terms-conditions.php">Terms and Condition</a>
                                </li>
                                <li>
                                    <a href="privacy-policy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="contact.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Taxi Packages</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="taxi-packages.php">Delhi To Ayodhya</a>
                                </li>
                                <li>
                                    <a href="#">Delhi To Rishikesh</a>
                                </li>
                                <li>
                                    <a href="#">Delhi To Haridwar</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Local Sight Seeing Ayodhya</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--<div class="col">
                        <div class="footer-widget">
                            <h5>Destinations</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="javascript:void(0);">Hawai</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Istanbul</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">San Diego</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Belgium</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Los Angeles</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Newyork</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Support</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="contact-us.html">Contact Us</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Legal Notice</a>
                                </li>
                                <li>
                                    <a href="privacy-policy.html">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="terms-conditions.html">Terms and Conditions</a>
                                </li>
                                <li>
                                    <a href="chat.html">Chat Support</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Refund Policy</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Services</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="hotel-grid.html">Hotel</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Activity Finder</a>
                                </li>
                                <li>
                                    <a href="flight-grid.html">Flight Finder</a>
                                </li>
                                <li>
                                    <a href="tour-grid.html">Holiday Rental</a>
                                </li>
                                <li>
                                    <a href="car-grid.html">Car Rental</a>
                                </li>
                                <li>
                                    <a href="tour-details.html">Holiday Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>-->
                </div>
                <div class="footer-wrap bg-white">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-xl-3 col-xxl-3">
                            <div class="mb-3 text-center text-xl-start">
                                <a href="index.php" class="d-block footer-logo-light">
                                    <img src="img/logo.png" alt="logo">
                                </a>
                                <a href="index.php" class="footer-logo-dark">
                                    <img src="img/logo.png" alt="logo">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-xl-4 col-xxl-4">
                            <div class="d-flex align-items-center justify-content-center flex-wrap">
                                <h6 class="fs-14 fw-medium me-2 mb-2">Available on : </h6>
                                <a href="javascript:void(0);" class="d-block mb-3 me-2">
                                    <img src="assets/img/icons/googleplay.svg" alt="logo">
                                </a>
                                <a href="javascript:void(0);" class="d-block mb-3">
                                    <img src="assets/img/icons/appstore.svg" alt="logo">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-5 col-xxl-5">
                            <div class="d-sm-flex align-items-center justify-content-center justify-content-xl-end">
                                <div class="d-flex align-items-center justify-content-center justify-content-sm-start me-0 pe-0 me-sm-3 pe-sm-3 border-end mb-3">
                                    <span class="avatar avatar-lg bg-primary rounded-circle flex-shrink-0">
										<i class="ti ti-headphones-filled fs-24"></i>
									</span>
                                    <div class="ms-2">
                                        <p class="mb-1">Customer Support</p>
                                        <p class="fw-medium text-dark">+91 9356779356</p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-center justify-content-sm-start mb-3">
                                    <span class="avatar avatar-lg bg-secondary rounded-circle flex-shrink-0">
										<i class="ti ti-message fs-24 text-gray-9"></i>
									</span>
                                    <div class="ms-2">
                                        <p class="mb-1">Drop Us an Email</p>
                                        <p class="fw-medium text-dark"><a href="mailto:info@aarohicabs.in">info@aarohicabs.in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-img">
                    <img src="assets/img/bg/footer.svg" class="img-fluid" alt="img">
                </div>
            </div>
        </div>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex align-items-center justify-content-between flex-wrap">
                            <p class="fs-14"> &copy; 2025 <strong>Aarohi Cabs.</strong> All Rights Reserved.</p>
                            <div class="d-flex align-items-center">
                                <ul class="social-icon">
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-x-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-linkedin"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-pinterest"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <ul class="card-links">
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-01.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-02.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-03.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-04.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-05.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-06.svg" alt="img">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Footer Bottom -->

    </footer>
    <!-- /Footer -->

    <!-- Login Modal -->
    <div class="modal fade" id="login-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center mb-3">
                            <h5 class="mb-1">Sign In</h5>
                            <p>Sign in to Start Manage your DreamsTour Account</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mt-3 mb-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap row-gap-2">
                                <div class="form-check d-flex align-items-center mb-2">
                                    <input class="form-check-input mt-0" type="checkbox" value="" id="remembers_me">
                                    <label class="form-check-label ms-2 text-gray-9 fs-14" for="remembers_me">
                                        Remember Me
                                    </label>
                                </div>
                                <a href="javascript:void(0);" class="link-primary fw-medium fs-14 mb-2" data-bs-toggle="modal" data-bs-target="#forgot-modal">Forgot Password?</a>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100">Login<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="login-or mb-3">
                            <span class="span-or">Or</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center me-2">
                                <img src="assets/img/icons/google-icon.svg" class="me-2" alt="Img">Google
                            </a>
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center">
                                <img src="assets/img/icons/fb-icon.svg" class="me-2" alt="Img">Facebook
                            </a>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Don't you have an account? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#register-modal">Sign up</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Login Modal -->

    <!-- Register Modal -->
    <div class="modal fade" id="register-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Sign Up</h5>
                            <p class="mb-3">Create your DreamsTour Account</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Name</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-user"></i>
                                </span>
                                <input type="text" class="form-control form-control-lg" placeholder="Enter Full Name">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Confirm Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mt-3 mb-3">
                            <div class="d-flex">
                                <div class="form-check d-flex align-items-center mb-2">
                                    <input class="form-check-input mt-0" type="checkbox" value="" id="agree">
                                    <label class="form-check-label ms-2 text-gray-9 fs-14" for="agree">
                                        I agree with the <a href="javascript:void(0);" class="link-primary fw-medium">Terms Of Service.</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100">Register<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="login-or mb-3">
                            <span class="span-or">Or</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center me-2">
                                <img src="assets/img/icons/google-icon.svg" class="me-2" alt="Img">Google
                            </a>
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center">
                                <img src="assets/img/icons/fb-icon.svg" class="me-2" alt="Img">Facebook
                            </a>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Already have an account? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Register Modal -->

    <!-- Change Password -->
    <div class="modal fade" id="change-password">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Change Password</h5>
                            <p class="mb-3">Enter Details to Change Password</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-0">
                            <button type="button" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100" data-bs-toggle="modal" data-bs-target="#login-password">Change Password<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Change Password -->

    <!-- Forgot Password -->
    <div class="modal fade" id="forgot-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Forgot Password</h5>
                            <p>Reset Your DreamsTour Password</p>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="button" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100" data-bs-toggle="modal" data-bs-target="#change-password">Reset Password<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Remember Password ? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Forgot Password -->

    <!-- Cursor -->
    <div class="xb-cursor tx-js-cursor">
        <div class="xb-cursor-wrapper">
            <div class="xb-cursor--follower xb-js-follower"></div>
        </div>
    </div>
    <!-- /Cursor -->

    <div class="back-to-top">
		<a class="back-to-top-icon align-items-center justify-content-center d-flex"  href="#top"><i class="fa-solid fa-arrow-up"></i></a>
	</div>	

    <!-- Jquery JS -->
    <script data-cfasync="false" src="https://cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="assets/js/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <!-- Wow JS -->
    <script src="assets/js/wow.min.js"></script>

    <!-- MeanMenu Js -->
    <script src="assets/js/jquery.meanmenu.min.js"></script>

    <!-- Swiper Js -->
    <script src="assets/plugins/owlcarousel/owl.carousel.min.js"></script>

    <!-- Fancybox JS -->
    <script src="assets/plugins/fancybox/jquery.fancybox.min.js"></script>

    <!-- Counter JS -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>

    <!-- Datepicker Core JS -->
    <script src="assets/plugins/moment/moment.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>

    <!-- cursor JS -->
    <script src="assets/js/cursor.js"></script>

    <!-- Script JS -->
    <script src="assets/js/script.js"></script>

<script src="https://cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"></script>
</body>



</html>