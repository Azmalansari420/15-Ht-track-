<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aarohi Cabs</title>

   

   

    <!-- Favicon -->
    <link rel="icon" href="img/favi.png" type="image/x-icon">
   

    <!-- Theme Settings Js -->
	<script src="assets/js/theme-script.js"></script>

    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Main.css -->
    <link rel="stylesheet" href="assets/css/meanmenu.css">

    <!-- Tabler Icon CSS -->
    <link rel="stylesheet" href="assets/plugins/tabler-icons/tabler-icons.css">

    <!-- Fontawesome Icon CSS -->
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/plugins/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Fancybox CSS -->
    <link rel="stylesheet" href="assets/plugins/fancybox/jquery.fancybox.min.css">

    <!-- Owlcarousel CSS -->
    <link rel="stylesheet" href="assets/plugins/owlcarousel/owl.carousel.min.css">
    
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/plugins/slick/slick.css">

    <!-- Iconsax CSS -->
    <link rel="stylesheet" href="assets/css/iconsax.css">

    <!-- Datepicker CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <style>
        .tt img{width:100%;height:250px;}
        .aa img{width:100%;height:220px;}
        @media only screen and (max-width: 768px) {
          .aa img{width:100%;height:250px!important;}
        }
    </style>
    
     <style>
    .rate-item {
        padding: 10px;
    }

    .rate-header-content {
        margin: 15px 0;
        text-align: center;
    }
    .rate-item {
    
    position: relative;
    overflow: hidden;
    background: var(--color-white);
    margin-bottom: 25px;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgb(6 22 58 / 10%);
    transition: all .9sease-in-out;
    z-index: 1;
}
.rate-header-content h4 {
    margin-bottom: 0;
    font-size: 22px;
    text-transform: uppercase;
}
.rate-content {
    background: #000;
    padding: 30px;
    border-radius: 20px;
    position: relative;
    z-index: 1;
}
.rate-content::before {
    content: "";
    position: absolute;
    background-image: url(assets/img/shape-4.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    opacity: .15;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    z-index: -1;
}
.rate-feature ul li {
    position: relative;
    margin: 10px 0;
    color: #fff;
}
.rate-feature ul li i {
    color: #cf3425;
    margin-right: 5px;
}
</style>

</head>
<body>

    <div class="main-header">
   <!-- Header Topbar-->
   <div class="header-topbar text-center bg-transparent">
      <div class="container">
         <div class="d-flex align-items-center justify-content-between flex-wrap">
            <p class="d-flex align-items-center fw-medium fs-14 mb-2"><i class="isax isax-call5 me-2"></i>Contact No. : +91 9356779356</p>
            <div class="d-flex align-items-center">
               <p class="mb-2 me-3 d-flex align-items-center fw-medium fs-14"><i class="isax isax-message-text-15 me-2"></i>Email : <a href="mailto:info@aarohicabs.in" style="color:#fff;"> info@aarohicabs.in</a></p>
               
               
              
            </div>
         </div>
      </div>
   </div>
   <!-- /Header Topbar-->
   <!-- Header -->
   <header>
      <div class="container">
         <div class="offcanvas-info">
            <div class="offcanvas-wrap">
               <div class="offcanvas-detail">
                  <div class="offcanvas-head">
                     <div class="d-flex justify-content-between align-items-center mb-3">
                        <a href="index.php" class="black-logo-responsive">
                        <img src="img/logo.png" alt="logo-img" style="max-width:220px;">
                        </a>
                        <a href="index.php" class="white-logo-responsive">
                        <img src="img/logo.png" alt="logo-img" style="max-width:220px;">
                        </a>
                        <div class="offcanvas-close">
                           <i class="ti ti-x"></i>
                        </div>
                     </div>
                     
                  </div>
                  <div class="mobile-menu fix mb-3"></div>
                  <div class="offcanvas__contact">
                     <div class="mt-4">
                        
                        <!--<div><a href="#" class="text-white btn btn-dark w-100 mb-3" data-bs-toggle="modal" data-bs-target="#login-modal">Contact Us</a></div>-->
                        <a href="enquiry.php" class="btn btn-primary w-100">Enquiry Now</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="offcanvas-overlay"></div>
         <div class="header-nav">
            <div class="main-menu-wrapper">
               <div class="navbar-logo">
                  <a class="logo-white header-logo" href="index.php">
                  <img src="img/logo-white1.png" class="logo" style="max-width:220px;" alt="Logo">
                  </a>
                  <a class="logo-dark header-logo" href="index.php">
                  <img src="img/logo.png" class="logo" alt="Logo" style="max-width:220px;">
                  </a>
               </div>
               <nav id="mobile-menu">
                  <ul class="main-nav">
                     <li class="has-submenu megamenu active">
                        <a href="index.php">Home</a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="about.php">About </a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="taxi-packages.php">Taxi Packages</a>
                        
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="payment.php">Payment</a>
                        
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="#">Car Rental</a>
                       
                     </li>
                     <li class="has-submenu mega-innermenu">
                        <a href="contact.php">Contact Us</a>
                       
                     </li>
                     
                  </ul>
               </nav>
               <div class="header-btn d-flex align-items-center">
                  <!--<div class="me-3">
                     <a href="#" id="dark-mode-toggle" class="theme-toggle">
                     <i class="isax isax-moon"></i>
                     </a>
                     <a href="#" id="light-mode-toggle" class="theme-toggle">
                     <i class="isax isax-sun-1"></i>
                     </a>
                  </div>-->
                  <!--<div><a href="#" class="btn btn-white me-3" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></div>-->
                  <a href="enquiry.php" class="btn btn-primary me-0">Enquiry Now</a>
                  <div class="header__hamburger d-xl-none my-auto">
                     <div class="sidebar-menu">
                        <i class="isax isax-menu5"></i>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- /Header -->
</div>
    <!-- Breadcrumb -->
    <div class="breadcrumb-bar breadcrumb-bg-02 text-center">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-12">
                    <h2 class="breadcrumb-title mb-2">Payment</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center mb-0">
                            <li class="breadcrumb-item"><a href="index.php"><i class="isax isax-home5"></i></a></li>
                            <li class="breadcrumb-item">Pages</li>
                            <li class="breadcrumb-item active" aria-current="page">Payment</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- /Breadcrumb -->

    <!-- Page Wrapper -->
    <div class="content">
        <div class="container">

            

            <!-- /Terms Condition-->
        </div>
    </div>
    <!-- /Page Wrapper -->

 <!-- Footer -->
    <a href="https://api.whatsapp.com/send?phone=919356779356" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>
<a href="tel:+919356779356" class="float2">
<i class="fa fa-phone my-float2"></i>
</a>
<style>
   .float{
   position:fixed;
   width:45px;
   height:45px;
   bottom:20px;
   left:20px;
   background-color:#25d366;
   color:#FFF!important;
   border-radius:50px;
   text-align:center;
   font-size:26px;
   box-shadow: 2px 2px 3px #999;
   z-index:100;
   }
   .my-float{
   margin-top:12px;
   }
   .float2{
   position:fixed;
   width:45px;
   height:45px;
   bottom:75px;
   left:20px;
   background-color:#1f74bd;
   color:#FFF!important;
   border-radius:50px;
   text-align:center;
   font-size:26px;
   box-shadow: 2px 2px 3px #999;
   z-index:100;
   }
   .my-float2{
   margin-top:12px;
   }
</style>

<footer>
        <div class="container">
            <div class="footer-top">
                <div class="row row-cols-lg-5 row-cols-md-3 row-cols-sm-2 row-cols-1">
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Quick Links</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                <li>
                                    <a href="gallery.php">Gallery</a>
                                </li>
                                <li>
                                    <a href="terms-conditions.php">Terms and Condition</a>
                                </li>
                                <li>
                                    <a href="privacy-policy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="contact.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Taxi Packages</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="taxi-packages.php">Delhi To Ayodhya</a>
                                </li>
                                <li>
                                    <a href="#">Delhi To Rishikesh</a>
                                </li>
                                <li>
                                    <a href="#">Delhi To Haridwar</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Local Sight Seeing Ayodhya</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!--<div class="col">
                        <div class="footer-widget">
                            <h5>Destinations</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="javascript:void(0);">Hawai</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Istanbul</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">San Diego</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Belgium</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Los Angeles</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Newyork</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Support</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="contact-us.html">Contact Us</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Legal Notice</a>
                                </li>
                                <li>
                                    <a href="privacy-policy.html">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="terms-conditions.html">Terms and Conditions</a>
                                </li>
                                <li>
                                    <a href="chat.html">Chat Support</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Refund Policy</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget">
                            <h5>Services</h5>
                            <ul class="footer-menu">
                                <li>
                                    <a href="hotel-grid.html">Hotel</a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">Activity Finder</a>
                                </li>
                                <li>
                                    <a href="flight-grid.html">Flight Finder</a>
                                </li>
                                <li>
                                    <a href="tour-grid.html">Holiday Rental</a>
                                </li>
                                <li>
                                    <a href="car-grid.html">Car Rental</a>
                                </li>
                                <li>
                                    <a href="tour-details.html">Holiday Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>-->
                </div>
                <div class="footer-wrap bg-white">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-xl-3 col-xxl-3">
                            <div class="mb-3 text-center text-xl-start">
                                <a href="index.php" class="d-block footer-logo-light">
                                    <img src="img/logo.png" alt="logo">
                                </a>
                                <a href="index.php" class="footer-logo-dark">
                                    <img src="img/logo.png" alt="logo">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-xl-4 col-xxl-4">
                            <div class="d-flex align-items-center justify-content-center flex-wrap">
                                <h6 class="fs-14 fw-medium me-2 mb-2">Available on : </h6>
                                <a href="javascript:void(0);" class="d-block mb-3 me-2">
                                    <img src="assets/img/icons/googleplay.svg" alt="logo">
                                </a>
                                <a href="javascript:void(0);" class="d-block mb-3">
                                    <img src="assets/img/icons/appstore.svg" alt="logo">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-5 col-xxl-5">
                            <div class="d-sm-flex align-items-center justify-content-center justify-content-xl-end">
                                <div class="d-flex align-items-center justify-content-center justify-content-sm-start me-0 pe-0 me-sm-3 pe-sm-3 border-end mb-3">
                                    <span class="avatar avatar-lg bg-primary rounded-circle flex-shrink-0">
										<i class="ti ti-headphones-filled fs-24"></i>
									</span>
                                    <div class="ms-2">
                                        <p class="mb-1">Customer Support</p>
                                        <p class="fw-medium text-dark">+91 9356779356</p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-center justify-content-sm-start mb-3">
                                    <span class="avatar avatar-lg bg-secondary rounded-circle flex-shrink-0">
										<i class="ti ti-message fs-24 text-gray-9"></i>
									</span>
                                    <div class="ms-2">
                                        <p class="mb-1">Drop Us an Email</p>
                                        <p class="fw-medium text-dark"><a href="mailto:info@aarohicabs.in">info@aarohicabs.in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-img">
                    <img src="assets/img/bg/footer.svg" class="img-fluid" alt="img">
                </div>
            </div>
        </div>
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="d-flex align-items-center justify-content-between flex-wrap">
                            <p class="fs-14"> &copy; 2025 <strong>Aarohi Cabs.</strong> All Rights Reserved.</p>
                            <div class="d-flex align-items-center">
                                <ul class="social-icon">
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-x-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-linkedin"></i></a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);"><i class="fa-brands fa-pinterest"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <ul class="card-links">
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-01.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-02.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-03.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-04.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-05.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/icons/card-06.svg" alt="img">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Footer Bottom -->

    </footer>
    <!-- /Footer -->

    <!-- Login Modal -->
    <div class="modal fade" id="login-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center mb-3">
                            <h5 class="mb-1">Sign In</h5>
                            <p>Sign in to Start Manage your DreamsTour Account</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mt-3 mb-3">
                            <div class="d-flex align-items-center justify-content-between flex-wrap row-gap-2">
                                <div class="form-check d-flex align-items-center mb-2">
                                    <input class="form-check-input mt-0" type="checkbox" value="" id="remembers_me">
                                    <label class="form-check-label ms-2 text-gray-9 fs-14" for="remembers_me">
                                        Remember Me
                                    </label>
                                </div>
                                <a href="javascript:void(0);" class="link-primary fw-medium fs-14 mb-2" data-bs-toggle="modal" data-bs-target="#forgot-modal">Forgot Password?</a>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100">Login<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="login-or mb-3">
                            <span class="span-or">Or</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center me-2">
                                <img src="assets/img/icons/google-icon.svg" class="me-2" alt="Img">Google
                            </a>
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center">
                                <img src="assets/img/icons/fb-icon.svg" class="me-2" alt="Img">Facebook
                            </a>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Don't you have an account? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#register-modal">Sign up</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Login Modal -->

    <!-- Register Modal -->
    <div class="modal fade" id="register-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Sign Up</h5>
                            <p class="mb-3">Create your DreamsTour Account</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Name</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-user"></i>
                                </span>
                                <input type="text" class="form-control form-control-lg" placeholder="Enter Full Name">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Confirm Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mt-3 mb-3">
                            <div class="d-flex">
                                <div class="form-check d-flex align-items-center mb-2">
                                    <input class="form-check-input mt-0" type="checkbox" value="" id="agree">
                                    <label class="form-check-label ms-2 text-gray-9 fs-14" for="agree">
                                        I agree with the <a href="javascript:void(0);" class="link-primary fw-medium">Terms Of Service.</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100">Register<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="login-or mb-3">
                            <span class="span-or">Or</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center me-2">
                                <img src="assets/img/icons/google-icon.svg" class="me-2" alt="Img">Google
                            </a>
                            <a href="javascript:void(0);" class="btn btn-light flex-fill d-flex align-items-center justify-content-center">
                                <img src="assets/img/icons/fb-icon.svg" class="me-2" alt="Img">Facebook
                            </a>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Already have an account? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Register Modal -->

    <!-- Change Password -->
    <div class="modal fade" id="change-password">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Change Password</h5>
                            <p class="mb-3">Enter Details to Change Password</p>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-lock"></i>
                                </span>
                                <input type="password" class="form-control form-control-lg pass-input" placeholder="Enter Password">
                                <span class="input-icon-addon toggle-password">
									<i class="isax isax-eye-slash"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-0">
                            <button type="button" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100" data-bs-toggle="modal" data-bs-target="#login-password">Change Password<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Change Password -->

    <!-- Forgot Password -->
    <div class="modal fade" id="forgot-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex align-items-center justify-content-end pb-0 border-0">
                    <a href="javascript:void(0);" data-bs-dismiss="modal" aria-label="Close"><i
							class="ti ti-x fs-20"></i></a>
                </div>
                <div class="modal-body p-4 pt-0">
                    <form action="#">
                        <div class="text-center border-bottom mb-3">
                            <h5 class="mb-1">Forgot Password</h5>
                            <p>Reset Your DreamsTour Password</p>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Email</label>
                            <div class="input-icon">
                                <span class="input-icon-addon">
									<i class="isax isax-message"></i>
                                </span>
                                <input type="email" class="form-control form-control-lg" placeholder="Enter Email">
                            </div>
                        </div>
                        <div class="mb-3">
                            <button type="button" class="btn btn-xl btn-primary d-flex align-items-center justify-content-center w-100" data-bs-toggle="modal" data-bs-target="#change-password">Reset Password<i class="isax isax-arrow-right-3 ms-2"></i></button>
                        </div>
                        <div class="d-flex justify-content-center">
                            <p class="fs-14">Remember Password ? <a href="javascript:void(0);" class="link-primary fw-medium" data-bs-toggle="modal" data-bs-target="#login-modal">Sign In</a></p>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- /Forgot Password -->

    <!-- Cursor -->
    <div class="xb-cursor tx-js-cursor">
        <div class="xb-cursor-wrapper">
            <div class="xb-cursor--follower xb-js-follower"></div>
        </div>
    </div>
    <!-- /Cursor -->

    <div class="back-to-top">
		<a class="back-to-top-icon align-items-center justify-content-center d-flex"  href="#top"><i class="fa-solid fa-arrow-up"></i></a>
	</div>	

    <!-- Jquery JS -->
    <script data-cfasync="false" src="https://cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
    <script src="assets/js/jquery-3.7.1.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <!-- Wow JS -->
    <script src="assets/js/wow.min.js"></script>

    <!-- MeanMenu Js -->
    <script src="assets/js/jquery.meanmenu.min.js"></script>

    <!-- Swiper Js -->
    <script src="assets/plugins/owlcarousel/owl.carousel.min.js"></script>

    <!-- Fancybox JS -->
    <script src="assets/plugins/fancybox/jquery.fancybox.min.js"></script>

    <!-- Counter JS -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>

    <!-- Datepicker Core JS -->
    <script src="assets/plugins/moment/moment.js"></script>
    <script src="assets/js/bootstrap-datetimepicker.min.js"></script>

    <!-- cursor JS -->
    <script src="assets/js/cursor.js"></script>

    <!-- Script JS -->
    <script src="assets/js/script.js"></script>

<script src="https://cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"></script>
</body>



</html>