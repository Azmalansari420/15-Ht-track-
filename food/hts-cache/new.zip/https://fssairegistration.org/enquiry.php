 <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Enquiry Form</title>
        <meta name="description" content="FSSAI license registration online application for hotels, fast food restaurants. Apply for new or renewal food license registration certificate from FSSAI Registration Consultant, at low fees.">
        <link rel="icon" href="./assets/img/flag.png" type="image/gif" sizes="16x16" alt="FSSAI License Registration Online | FSSAI License Certificate">
        <script src="https://kit.fontawesome.com/d23a55b7f1.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="main.css?v=1767416994">
        <link rel="canonical" href="https://fssairegistration.org/enquiry.php">
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-161812086-1"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-161812086-1');
        </script>
    </head>
    <body>
        <!-- Topbar -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<nav class="navbar fcs-topbar-container">
    <div class="col-lg-4 col-sm-12 fcs-topbar-heading" id="number-crm-help">
    <span style="font-size:11px">Helpline: +91 - <a href="tel:+919355583489" style="color:white;">9355583489</a>   (please prefix +91 before calling)<br><!--9031025497 ,--> <!--9905936089--><a href="tel:" class="text-decoration-none text-white"></a>
    </span>
    <span style="font-size:11px">Complaint Helpline: +91 - <a href="tel:+917996637888" style="color:white;">7996637888</a>(please prefix +91 before calling)
    </span>
    </div>
    <div class="col-lg-4">
      <span class="ml-0" style="font-size:14px;color:#fff">
      Contact Between 10:00 am to 5:00 pm , Monday-Saturday
      </span>
    </div>
    <div class="col-lg-4 text-right" style="font-size:8px">
            <a href="/enquiry.php" class="btn btn-link btn-sm  fcs-secondary-button">Enquiry</a>
        <a href="/about-us.php" class="btn btn-link btn-sm  fcs-secondary-button">About Us</a>

<a href="/complaint-form.php"class="btn btn-link text-white btn-sm  fcs-secondary-button"title="Complaint" class="complaint-btn">Complaint</a>
        <a href="/complaint-track-form.php"class="btn btn-link text-white btn-sm fcs-secondary-button"title="Complaint" class="complaint-btn">Track Complaint</a>
</div>
</nav>

<!-- Header -->
<nav class="navbar fcs-navbar-container">
    <div class="col-lg-3 col-3 fcs-navbar-heading text-left pl-4">
       <a href="/"> <img src="/assets/img/logo.svg" class="img-fluid" width="100" alt="FSSAI License Registration Online | FSSAI License Certificate"> </a>
    </div>
 <div class="col-lg-6 col-3">
    <h4 class="fcs-bold-text" style="color:#222;font-size:18px">FSSAI REGISTRATION ONLINE CONSULTANCY SERVICES <br> FSSAI LICENSE ONLINE CONSULTANCY PORTAL / एफएसएसएआई लाइसेंस ऑनलाइन  कंसल्टेंसी पोर्टल<br></h4>
    <p class="text-center">(An ISO Certified Pvt Consultancy Portal)<p>
   </div>
    <div class="col-lg-3 col-3 fcs-navbar-heading  text-right">
        <!--<img src="/assets/img/swach-bharat.png" class="img-fluid" width="160" alt="FSSAI License Registration Online | FSSAI License Certificate">-->
    </div>
</nav>



<nav class="navbar navbar-expand-lg navbar-dark bg-dark fcs-mainbar-container d-sm-block">
    <div class="col-lg-3 col-2 fcs-navbar-logo">
        <button class="navbar-toggler fcs-menu-button collapsed" style="border:0!important; color:#fff!important;" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""><i class="fa fa-bars" aria-hidden="true"></i></span>
        </button>
    </div>
    <div class="navbar-collapse collapse" id="navbarSupportedContent" style="">
        <ul class="navbar-nav">
<li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/">Home</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/fssai-registration.php">FSSAI Registration Consultancy</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/tatkal-fssai-registration.php">Tatkal FSSAI Registration Consultancy</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/renewal-existing-food-licence.php">Renewal Food Licence Consultancy</a>
        </li>
       <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/annual-return-filing.php">Annual Return Filing Consultancy</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/water-testing.php">Water Testing Consultancy</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/trace-lost-fssai-certificate.php">Trace Lost Certificate</a>
        </li>
        <li class="nav-item" id="msme-udyam-online-button">
            <a class="nav-link " href="/blog">Blog</a>
        </li>


    </ul></div>
</nav>
<!-- Marquee -->
<div class="container-fluid fcs-marquee-container" id="marqueeContainer" style="display: none;">
    <span><i class="fas fa-bell"></i></span>
    <marquee id="marqueeText">
    <!--FSSAI LICENSE REGISTRATION / FOOD LICENSE CERTIFICATION ONLINE APPLICATION PORTAL-->
    
    <!-- Happy Dussehra !! Our office will remain closed on 12th October, 2024 (Saturday).
     Our office will be operational from Monday, 14th October, 2024.-->
    </marquee>
</div>
<!--<div class="container-fluid fcs-marquee-container">
    <span><i class="fas fa-bell"></i></span>
    
    <marquee style="text-transform:none!important;color:#fff;font-size: 15px;">There will be a delay in processing of certificates on 14/08/2022 (Sunday) and 15/08/2022 (Independence day). Certificates will be processed on 16/08/2022 (Tuesday). Inconvenience caused is regretted.</marquee>
    
</div>-->
<!--<div class="container-fluid fcs-marquee-container" style="background-color:#ffdcb5;">
    <span><i class="fas fa-bell" style="color:red;"></i></span>
    <marquee scrolldelay="150">
    <span style="color:#000;"><b class="multicolor">Happy Holi !</b> Due to holiday on the occasion of Holi Festival, generation of certificate may get delayed.</span>

    </marquee>
</div>-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
<style>
#myBtnTop {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #f97806;
  color: white;
  cursor: pointer;
  padding: 8px;
  border-radius: 25px;
}

#myBtnTop:hover {background-color: #555;}
@media screen and (max-width: 600px) {
  #myBtnTop{
    display: none!important;
  }
}

.multicolor{

        background-image: linear-gradient(to left, #f400f4, #8100e4, #019541, #6868e4, #858500, orange, red);
        -webkit-background-clip: text;
        -moz-background-clip: text;
        background-clip: text;
        color: transparent;

}
</style>
<button onclick="topFunction()" id="myBtnTop" title="Go to top"><div><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"width="30" height="30" viewBox="0 0 172 172" style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M86,7.16667l-28.66667,28.66667h21.5v129h14.33333v-129h21.5z"></path></g></g></svg></div>Top</button>
<script>
var mybutton = document.getElementById("myBtnTop");
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>

<script>
    function checkMarqueeVisibility() {
      
        let now = new Date();
        let startHoli = new Date("April 07, 2025 00:00:00");
        let endHoli = new Date("April 07, 2025 11:59:59");

        let marqueeText = document.getElementById("marqueeText");
        let marqueeContainer = document.getElementById("marqueeContainer");

        let messages = [];

        // Holi Festival message (if within Holi period)
        if (now >= startHoli && now <= endHoli) {
             messages.push("<b style='color:white;background:red;margin-left:10px;border:1px solid red;border-radius: 50%;font-size: 10px;padding: 0px 5px;'>New</b>&nbsp; Office will not operate on April 7, 2025, for Ram Navami. We’ll be back Tuesday, April 8, 2025. Happy Ram Navami!"); 
        }

        // Other Important Message (Example)
        messages.push("<span style='color:green'>*</span> There will be a delay in issuing FSSAI certificate for the state of Rajasthan due ongoing System Upgradation. We appreciate your patience and understanding during this time.");
        messages.push("<span style='color:green'>*</span> There will be a delay in processing of certificates due to system upgradation : Inconvenience caused is regretted.");

        // If messages exist, display marquee
        if (messages.length > 0) {
            marqueeText.innerHTML = messages.join(" &nbsp;&nbsp; "); // Adds spacing between messages
            marqueeContainer.style.display = "flex";
        } else {
            marqueeContainer.style.display = "none";
        }
    }

    checkMarqueeVisibility(); // Run function on page load
</script>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-17064507241"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-17064507241');
</script>
<script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"97220209", enableAutoSpaTracking: true};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script>        
        <div class="container fcs-form-container ">    
            <div class="row mb-3">
                <div class="col-12 col-lg-6">
                    <h1 class=" vediv shadow text-center"style="font-size:14px">FSSAI Enquiry Form</h1>
                    <form action="#" method="post" enctype="multipart/form-data">
                        <div class="form-group txt">
                            <label> Name of Applicant / Company <span class="required">(Required)</span></label>
                            <input type="text" class="form-control" name="applicant_name" value="" required>
                        </div>
                        <div class="form-group txt">
                            <label>EMAIL ID <span class="required">(Required)</span></label>
                            <input type="text" class="form-control" name="email_id" required>
                        </div>
                        <div class="form-group txt">
                            <label>MOBILE NUMBER <span class="required">(Required)</span></label>
                            <input type="tel" maxlength="10" minlength="10"class="form-control" name="mobile_number" required>
                        </div>
                        
                        <div class="form-group txt">
                            <label>STATE <span class="required">(Required)</span></label>
                            <select name="office_state" id="state" class="form-control" required>>
                                <option value="">Select State</option>
                                <option value="Andhra Pradesh">Andhra Pradesh</option>
                                <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                <option value="Assam">Assam</option>
                                <option value="Bihar">Bihar</option>
                                <option value="Chandigarh">Chandigarh</option>
                                <option value="Chhattisgarh">Chhattisgarh</option>
                                <option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
                                <option value="Daman and Diu">Daman and Diu</option>
                                <option value="Delhi">Delhi</option>
                                <option value="Lakshadweep">Lakshadweep</option>
                                <option value="Puducherry">Puducherry</option>
                                <option value="Goa">Goa</option>
                                <option value="Gujarat">Gujarat</option>
                                <option value="Haryana">Haryana</option>
                                <option value="Himachal Pradesh">Himachal Pradesh</option>
                                <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                                <option value="Jharkhand">Jharkhand</option>
                                <option value="Karnataka">Karnataka</option>
                                <option value="Kerala">Kerala</option>
                                <option value="Madhya Pradesh">Madhya Pradesh</option>
                                <option value="Maharashtra">Maharashtra</option>
                                <option value="Manipur">Manipur</option>
                                <option value="Meghalaya">Meghalaya</option>
                                <option value="Mizoram">Mizoram</option>
                                <option value="Nagaland">Nagaland</option>
                                <option value="Odisha">Odisha</option>
                                <option value="Punjab">Punjab</option>
                                <option value="Rajasthan">Rajasthan</option>
                                <option value="Sikkim">Sikkim</option>
                                <option value="Tamil Nadu">Tamil Nadu</option>
                                <option value="Telangana">Telangana</option>
                                <option value="Tripura">Tripura</option>
                                <option value="Uttar Pradesh">Uttar Pradesh</option>
                                <option value="Uttarakhand">Uttarakhand</option>
                                <option value="West Bengal">West Bengal</option>
                            </select>
                        </div>
                        <div class="form-group txt">
                            <label>Select Product Type <span class="required">(Required)</span></label>
                            <select class="form-control" name="product_type" id="registrationType" required="">
                                <option selected="selected" value="">Select Options</option required>
                                <option value="NEW FSSAI REGISTRATION">NEW FSSAI REGISTRATION</option>
                                <option value="FSSAI RENEWAL">FSSAI RENEWAL</option>
                            </select>
                        </div>

                        <div class="form-group txt new-registration" style="display: none;">
                            <label>Select Product <span class="required">(Required)</span></label>
                            <select class="form-control" name="product" required="">
                                <option selected="selected" value="">Select Options</option>
                                <option value="BASIC REGISTRATION">BASIC REGISTRATION</option>
                                <option value="STATE LICENCE">STATE LICENCE</option>
                                <option value="CENTRAL LICENCE">CENTRAL LICENCE</option>
                            </select>
                        </div>
                    <div class="form-group">
                        <input type="text" name="vercode" class="form-control" placeholder="Verfication Code" required="required">
                    </div>
                    <div class="form-group small clearfix">
                        <label class="checkbox-inline">Verification Code</label>
                        &nbsp;&nbsp;<img src="captcha.php">
                    </div>
                    <input type="hidden" class="form-control" name="form_name" value="FSSAI Enquiry">
                    <input type="hidden" class="form-control" name="form_id" value="fssai_enquiry">
                    <button type="submit" class="btn btn-primary fcs-submit-button">Submit Application</button>
                </form>
            </div>
            <div class="col-12 col-lg-6">
                <h2 class=" vediv shadow text-center"style="font-size:14px">Instruction To Fill FSSAI Enquiry Form
                </h2>
                <div class="form-instructions">
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>Name of Applicant/Company :</strong>The applicant must provide a name or Company name as it appears on the PAN card.आवेदक को पैन कार्ड पर दिखाई देने वाला नाम या कंपनी का नाम प्रदान करना होगा।
                        </label>
                    </div>
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>Email Id :</strong> The applicant must fill out the correct email address to get the notification.अधिसूचना प्राप्त करने के लिए आवेदक को सही ईमेल पता भरना होगा।
                        </label>
                    </div>
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>Mobile Number :</strong>  Applicant must enter his/her mobile number.आवेदक को अपना मोबाइल नंबर दर्ज करना होगा।
                        </label>
                    </div>
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>STATE :</strong>  Applicant must select their state from the dropdown.आवेदक को ड्रॉपडाउन से अपना राज्य चुनना होगा।

                        </label>
                    </div>
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>SELECT PRODUCT :</strong>  Applicant must select their product name from the given option.आवेदक को दिए गए विकल्प में से अपने उत्पाद का नाम चुनना होगा।
                        </label>
                    </div>
                    <div class="form-group" style="margin-top: 14px;">
                        <label class="fcs-text-dark"><strong>SUBMIT APPLICATION :</strong>  After checking all the details applicant must click to submit application button.सभी डेटा की समीक्षा करने के बाद, आवेदक को सबमिट एप्लिकेशन बटन पर क्लिक करना होगा।
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>

<h2 class="mt-5 text-center ">FSSAI Enquiry Form </h2>
<p class="container" style="text-align:justify;">An Enquiry form for FSSAI (Food Safety and Standards Authority of India) registration is an important document for starting the process of getting FSSAI registration, which is required for all businesses participating in food industry activities in India. This form serves as the first point of contact between the applicant and the regulatory body, allowing for easier communication and documentation exchange throughout the registration process.

An enquiry form normally includes the applicant's name, contact information, business type, and intended food business activities, all of which are necessary for the FSSAI's preliminary evaluation. Specifics about the locations where food handling and processing will take place, such as address and facility information, may also be requested.

The Enquiry form may request information on the sorts of food items to be made, processed, stored, or delivered by the applicant. This helps to determine the relevant legislation and licensing requirements based on the kind and size of the food industry activities.

The Enquiry form frequently contains a space for the applicant's questions or more information about the registration procedure or regulatory compliance. This enables clarification of any questions and guarantees a thorough grasp of the requirements and procedures involved in getting FSSAI registration.

The submitting of an Enquiry form is the first step toward compliance with food safety standards in India, easing the path to FSSAI registration and encouraging adherence to established procedures in food handling and delivery.
 </p>
    
    <!-- Back To Top Button -->
    <a href="#" class="cd-top text-replace js-cd-top"><i class="fas fa-arrow-up"></i></a>
    
    <style>
    .quick_links {
        list-style-type: square;
    }

    .footer_heads {
        color:#fff;
    }

    .cont_txt {
        color:#fff;
        font-size:13px;
    }

    .bottom_nav {
        padding:0px;
    }

    .border {
        background-color:#fff;
        width:15%;
        margin-bottom:20px;
    }
    
</style>
<div class="container-fluid fcs-footer1">
    <div class="row" style="padding:0px 20px;">

        <div class="col-lg-4" style="text-align:left;">
            <p class="footer_heads">Quick Links :</p>
            <div class="border"></div>
            <ul class="quick_links">
                <li><a href="/home.php">Home</a></li>
                <li><a href="/about-us.php">About Us</a></li>
                <li><a href="/terms-of-service.php"> Terms & Conditions</a></li>
                <li><a href="/privacy-policy.php">Privacy Policy</a></li>
                <li><a href="/warranties-and-refunds.php">Warranties & Refunds</a></li>
            </ul>  

        </div>
        <div class="col-lg-4" style="text-align:left;">
            <p class="footer_heads">Contacts :</p>
            <div class="border"></div>
            <span class="cont_txt">
                HELPLINE:
            </span>
            <br>
            <span class="cont_txt">
                (+91) - <!--9031025497--><!--9905936089-->9355583489
            </span>
            <br><br>
            <span class="cont_txt">
                EMAIL: 
            </span>
            <br>
            <span class="cont_txt">
                care@fssairegistration.org
            </span>

        </div>
    
        <div class="col-lg-4" style="text-align:justify;color: #fff;padding:20px 20px;">
            <p>The Owner is a Private Consultant and having experience of Over a decade in matters related to Food Licence Application Filing Service. <br><br>The fees charged by us is the consultancy fees for our private consultancy services.<br><br>User can avail services FREE of Cost by visitng foscos.fssai.gov.in </p>
            <br>
            <br>

        </div>
       
        <div class="col-lg-12 txt">
              <a href="https://www.facebook.com/profile.php?id=100076169928724"  style="font-size:17px;color:white;text-decoration:none"><i class="fab fa-facebook-f"> facebook</i></a><p>© <a href="https://fssairegistration.org/">Fsaai Registration</a>. All Rights <a href="/test-dev-form.php">Reserved</a></p>
        </div>
        
    </div>
</div>
</div>
</div>
 <div class="text-justify text-white p-2" style="background: #f97806;color:white !important">
        <span style="font-size: 14px;font-weight:bold">Our promotion on all Ads publishers focuses on providing consultancy services through our private portal, and our targeting of keywords related to government documents and services is incidental to understanding client needs, rather than promoting such documents or services directly.</span>
      </div>
<div class="container-fluid fcs-bottom-nav bottom_nav" style="text-align:center">
<!-- <a href="https://techlounge.co.in/">Designed & Developed By Techlounge</a>-->
</div>
<!--Start of Tawk.to Script-->
<!--<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ece17ffc75cbf1769efbb69/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>-->
<!--End of Tawk.to Script-->
<script type="text/javascript">
    // Tawk_API.onPrechatSubmit = function(data) {

    //     var name = data[0].answer;
    //     var email = data[1].answer;
    //     var phone = data[2].answer;

    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             console.log(this.responseText);
    //         }
    //     };
    //     xhttp.open("GET", "chat.php?name="+name+"&email="+email+"&phone="+phone+"", true);
    //     xhttp.send();
    // };
</script>

<script>

document.addEventListener("DOMContentLoaded", function () {
    const token = 'qNNUfTIyF65mk7/rkNSB6cKig7P0yLYScxzlhFfN+gkyIJvrdj7/IvpAH76dsGCjwggI8Bd93KtlfBuHcMB4X8nm7mVROOpiWQ/JeZXnP9kb8jOxhy0HeAlWQ6f0uXZxRJV56SRca+slgWJpG7pauQQsYa8c2j0DCxSaU9Fy7wky10lII5dZZUtdh6NJAdqpZbVOz6+Yh/R9OfnSWLWxHfpT+IQL1Q+9/OMmcNOwLw8WAZeSBdOd0/rN7kz33y1t';
    document.querySelectorAll("form").forEach(function (form) {
        const tokenInput = document.createElement("input");
        tokenInput.type = "hidden";
        tokenInput.name = "lets-play_buddy";
        tokenInput.value = token;
        form.appendChild(tokenInput);
    });
});

document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("form").forEach(function (form) {
      let hiddenInput = document.createElement("input");
      hiddenInput.type = "hidden";
      hiddenInput.className = "form-control";
      hiddenInput.name = "in_source";
      hiddenInput.value = "";
      form.appendChild(hiddenInput);
    });
  });
window.onload = removeTranslate;
function removeTranslate(){
    const myTimeout = setTimeout(function(){
        document.querySelector('.VIpgJd-ZVi9od-ORHb-OEVmcd').style.display="none";
        //console.log("kk")
    }, 500);
}
document.addEventListener('DOMContentLoaded', function () {
    var emailInputs = document.querySelectorAll('input[name="email_id"], input[id="email_id"]');

    function checkEmail(inputElement) {
        var email = inputElement.value;
        var formGroup = inputElement.closest('.form-group');
        
        var feedback = formGroup.querySelector('.email-feedback');
        if (!feedback) {
            feedback = document.createElement('span');
            feedback.classList.add('email-feedback');
            feedback.style.color = 'red';
            feedback.style.fontSize = '12px';
            feedback.style.marginTop = '5px';
            formGroup.appendChild(feedback); // Add the feedback span after the input
        }

        var details = document.getElementById('verificationDetails');
        if (details) {
            details.innerHTML = '-';
        }

        var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (email.length === 0 || !emailPattern.test(email)) {
            feedback.textContent = 'Please enter a valid email address.';
            return;
        }

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'api/verify-email.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onload = function() {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success === 1) {
                    if (details) {
                        details.innerHTML = (response.data.status === 'clean') ? 'Valid Email' : 'Email Id Does Not Exist';
                    }
                    // Display valid/Email Id Does Not Exist response
                    feedback.textContent = (response.data.status === 'clean') ? 'Valid Email' : 'Email Id Does Not Exist';
                    feedback.style.color = (response.data.status === 'clean') ? 'green' : 'red';
                } else {
                    feedback.textContent = 'Error: ' + response.message;
                }
            } else {
                feedback.textContent = 'Error: Could not verify email.';
            }
        };

        xhr.send('email_id=' + encodeURIComponent(email));
    }

    emailInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            checkEmail(input);
        });
    });
});


</script>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
    <!-- Custom JS -->
    <script src="./assets/js/nav.js"></script>
    <script src="./assets/js/util.js"></script>
    <script src="./assets/js/main.js"></script>
<script>
    document.getElementById("registrationType").addEventListener("change", function() {
        let selectedValue = this.value;
        let d1 = document.querySelector(".new-registration");
        let d2 = document.querySelector(".renewal-registration");

        if (selectedValue === "NEW FSSAI REGISTRATION") {
            d1.style.display = "block";
            d2.style.display = "none";
        } else if (selectedValue === "FSSAI RENEWAL") {
            d1.style.display = "none";
            d2.style.display = "block";
        } else {
            d1.style.display = "none";
            d2.style.display = "none";
        }
    });
</script>
    
</body>
</html>