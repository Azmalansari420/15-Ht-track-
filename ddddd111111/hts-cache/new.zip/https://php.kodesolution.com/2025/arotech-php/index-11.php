
<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 11</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">
<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-two style-two">
    <!-- Header Top -->
    <div class="header-top">
        <div class="inner-container">

            <div class="top-left">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fas fa-map-marker-alt"></i> 	121 King Street, Melbourne</li>
                </ul>
                <div class="outer-box">
                    <ul class="social-icon-one">
                        <li><a href="#"><span class="fab fa-x-twitter"></span></a></li>
                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                    </ul>
                </div>
            </div>

            <div class="top-right">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">	help@company.com</a></li>
                    <li><i class="fas fa-clock"></i> Mon - Sat 8:00 - 6:30, Sunday - CLOSED</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Header Top -->

    <!-- Header Lower -->
    <div class="header-lower">
        <!-- Main box -->
        <div class="main-box">
            <div class="logo-box">
                <div class="logo">
                                <a href="index.php" title=""><img src="images/logo-3.png" alt="" title="arotech"></a>
                </div>
            </div>

            <!--Nav Box-->
            <div class="nav-outer">

                <nav class="nav main-menu">
                                        <ul class="navigation">
  <li class="current dropdown"><a href="index.php">Home</a>
  <ul>
      <li><a href="index.php">Home Layout 1</a></li>
      <li><a href="index-2.php">Home Layout 2</a></li>
      <li><a href="index-3.php">Home Layout 3</a></li>
      <li class="dropdown"><a href="#">More Home Layouts</a>
        <ul>
          <li><a href="index-4.php">Home Layout 4</a></li>
          <li><a href="index-5.php">Home Layout 5</a></li>
          <li><a href="index-6.php">Home Layout 6</a></li>
          <li><a href="index-7.php">Home Layout 7</a></li>
          <li><a href="index-8.php">Home Layout 8</a></li>
          <li><a href="index-9.php">Home Layout 9</a></li>
          <li><a href="index-10.php">Home Layout 10</a></li>
          <li><a href="index-11.php">Home Layout 11</a></li>
          <li><a href="index-12.php">Home Layout 12</a></li>
          <li><a href="index-13.php">Home Layout 13</a></li>
          <li><a href="index-14.php">Home Layout 14</a></li>
          <li><a href="index-15.php">Home Layout 15</a></li>
          <li><a href="index-16.php">Home Layout 16</a></li>
          <li><a href="index-17.php">Home Layout 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Styles</a>
        <ul>
          <li><a href="index.php">Header Style 1</a></li>
          <li><a href="index-2.php">Header Style 2</a></li>
          <li><a href="index-3.php">Header Style 3</a></li>
          <li><a href="index-4.php">Header Style 4</a></li>
          <li><a href="index-5.php">Header Style 5</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Single</a>
        <ul>
          <li><a href="index-1-single.php">Header Single 1</a></li>
          <li><a href="index-2-single.php">Header Single 2</a></li>
          <li><a href="index-3-single.php">Header Single 3</a></li>
          <li><a href="index-4-single.php">Header Single 4</a></li>
          <li><a href="index-5-single.php">Header Single 5</a></li>
          <li><a href="index-6-single.php">Header Single 6</a></li>
          <li><a href="index-7-single.php">Header Single 7</a></li>
          <li><a href="index-8-single.php">Header Single 8</a></li>
          <li><a href="index-9-single.php">Header Single 9</a></li>
          <li><a href="index-10-single.php">Header Single 10</a></li>
          <li><a href="index-11-single.php">Header Single 11</a></li>
          <li><a href="index-12-single.php">Header Single 12</a></li>
          <li><a href="index-13-single.php">Header Single 13</a></li>
          <li><a href="index-14-single.php">Header Single 14</a></li>
          <li><a href="index-15-single.php">Header Single 15</a></li>
          <li><a href="index-16-single.php">Header Single 16</a></li>
          <li><a href="index-17-single.php">Header Single 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Dark</a>
        <ul>
          <li><a href="index-1-dark.php">Header Dark 1</a></li>
          <li><a href="index-2-dark.php">Header Dark 2</a></li>
          <li><a href="index-3-dark.php">Header Dark 3</a></li>
          <li><a href="index-4-dark.php">Header Dark 4</a></li>
          <li><a href="index-5-dark.php">Header Dark 5</a></li>
          <li><a href="index-6-dark.php">Header Dark 6</a></li>
          <li><a href="index-7-dark.php">Header Dark 7</a></li>
          <li><a href="index-8-dark.php">Header Dark 8</a></li>
          <li><a href="index-9-dark.php">Header Dark 9</a></li>
          <li><a href="index-10-dark.php">Header Dark 10</a></li>
          <li><a href="index-11-dark.php">Header Dark 11</a></li>
          <li><a href="index-12-dark.php">Header Dark 12</a></li>
          <li><a href="index-13-dark.php">Header Dark 13</a></li>
          <li><a href="index-14-dark.php">Header Dark 14</a></li>
          <li><a href="index-15-dark.php">Header Dark 15</a></li>
          <li><a href="index-16-dark.php">Header Dark 16</a></li>
          <li><a href="index-17-dark.php">Header Dark 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Rtl Page</a>
        <ul>
          <li><a href="index-1-rtl.php">Header Rtl</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About</a></li>
      <li class="dropdown"><a href="#">Projects</a>
        <ul>
          <li><a href="page-projects.php">Projects List</a></li>
          <li><a href="page-project-details.php">Project Details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team List</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-testimonial.php">Testimonial</a></li>
      <li><a href="page-pricing.php">Pricing</a></li>
      <li><a href="page-pricing-switcher.php">Pricing Switcher</a></li>
      <li><a href="page-faq.php">FAQ</a></li>
      <li><a href="page-404.php">Page 404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services List</a></li>
      <li><a href="page-service-details.php">Service Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Shop</a>
    <ul>
      <li><a href="shop-products.php">Products</a></li>
      <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
      <li><a href="shop-product-details.php">Product Details</a></li>
      <li><a href="shop-cart.php">Cart</a></li>
      <li><a href="shop-checkout.php">Checkout</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">News</a>
    <ul>
      <li><a href="news-grid.php">News Grid</a></li>
      <li><a href="news-details.php">News Details</a></li>
    </ul>
  </li>
  <li><a href="page-contact.php">Contact</a></li>
</ul>                </nav>
                <!-- Main Menu End-->


                <div class="outer-box">
                    <div class="ui-btn-outer">
                        <button class="ui-btn ui-btn search-btn">
                            <span class="icon lnr lnr-icon-search"></span>
                        </button>
                    </div>


                    <a href="tel:+92(8800)9806" class="info-btn-two">
                        <i class="icon fa fa-phone"></i>
                        <small>Call Anytime</small><br> +88 017 500 500 88
                    </a>

                    <!-- Mobile Nav toggler -->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>

        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
            <div class="upper-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="close-btn"><i class="icon fa fa-times"></i></div>
            </div>

            <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
            </ul>
            <ul class="contact-list-one">
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <i class="icon lnr-icon-phone-handset"></i>
                        <span class="title">Call Now</span>
                        <a href="tel:+92880098670">+92 (8800) - 98670</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-envelope1"></span>
                        <span class="title">Send Email</span>
                        <a href="mailto:help@company.com">help@company.com</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-clock"></span>
                        <span class="title">Send Email</span>
                        Mon - Sat 8:00 - 6:30, Sunday - CLOSED
                    </div>
                </li>
            </ul>


            <ul class="social-links">
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->

    <!-- Header Search -->
    <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
            <form method="post" action="index.php">
                <div class="form-group">
                    <input type="search" name="search-field" value="" placeholder="Search..." required="">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
    <!-- End Header Search -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="inner-container">
                <!--Logo-->
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="nav-outer">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->

                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div><!-- End Sticky Menu -->
</header><section class="banner-section-ten">
    <div class="banner-carousel owl-carousel owl-theme">
        <!-- Slide Item -->
        <div class="slide-item">
            <div class="bg-image" style="background-image: url(images/main-slider/slider8.png);"></div>
            <div class="anim-icons animate-1">
                <img class="shape-image1 bounce-y" src="images/main-slider/slider11-circle-object.png" alt="">
                <img class="shape-image2" src="images/main-slider/slider11-shape1.png" alt="">
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="title animate-1">Powerful IT <br>Solution Services</h1>
                    <div class="text animate-2 me-lg-3">There are many of passages of lorem Ipsum, but the majori have <br>suffered alteration in some form.</div>
                    <div class="btn-box animate-3">
                        <a href="page-about.php" class="theme-btn btn-style-four hvr-light"><span class="btn-title">Explore now</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="features-section-five style-two pb-0">
		<div class="auto-container">
			<div class="row">
				<!-- Feature Block Five -->
				<div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
					<div class="inner-box ">
						<figure class="bg-image"><img src="images/resource/feature-bg-3.jpg" alt=""></figure>
						<h4 class="title"><a href="page-about.php">Data Visualization</a></h4>
						<div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
						<span class="count">01</span>
					</div>
				</div>

				<!-- Feature Block Five -->
				<div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box ">
						<figure class="bg-image"><img src="images/resource/feature-bg-4.jpg" alt=""></figure>
						<h4 class="title"><a href="page-about.php">UI/UX Designing</a></h4>
						<div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
						<span class="count">02</span>
					</div>
				</div>

				<!-- Feature Block Five -->
				<div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
					<div class="inner-box ">
						<figure class="bg-image"><img src="images/resource/feature-bg-5.jpg" alt=""></figure>
						<h4 class="title"><a href="page-about.php">Digital Marketing</a></h4>
						<div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
						<span class="count">03</span>
					</div>
				</div>
			</div>
		</div>
	</section><section id="about" class="about-section-three pt-70 pb-50">
  <div class="auto-container">
    <div class="row">
      <div class="content-column col-lg-6 col-md-12 col-sm-12 wow fadeInRight" data-wow-delay="600ms">
        <div class="inner-column">
          <div class="sec-title">
            <span class="sub-title">Welcome to tech</span>
            <h2>Best IT Technology Services you can Trust</h2>
            <h5>The professional approach to technology.</h5>
            <div class="text">System is a term used to refer to an organized collection symbols and processes that may be used to operate on such symbols. Perspiciatis unde omnis natus error voluptatems accusa.</div>
          </div>

          <div class="content-box">
            <div class="row">
              <div class="about-block-three col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon fa fa-arrow-alt-circle-right"></i> Cloud Based </h5>
                <p class="text">Lorem ipsum dolor sit amet not is consectetur notted</p>
              </div>

              <div class="about-block-three col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon fa fa-arrow-alt-circle-right"></i> Full Backup </h5>
                <p class="text">Lorem ipsum dolor sit amet not is consectetur notted.</p>
              </div>
            </div>

            <!--Skills-->
            <div class="skills">
              <!--Skill Item-->
              <div class="skill-item">
                <div class="skill-header">
                  <h5 class="skill-title">Technology</h5>
                </div>
                <div class="skill-bar">
                  <div class="bar-inner">
                    <div class="bar progress-line" data-width="77">
                      <div class="skill-percentage">
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="77">0</span>%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="btn-box">
              <a href="page-about.php" class="theme-btn btn-style-four"><span class="btn-title">Discover more</span></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Image Column -->
      <div class="image-column col-lg-6 col-md-12 col-sm-12">
        <div class="inner-column wow fadeInLeft">
          <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about-16-1.jpg" alt=""></figure>
          <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about-16-2.jpg" alt=""></figure>
        </div>
      </div>
    </div>
  </div>
</section><div class="marquee-section">
    <div class="marquee">
        <div class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
                            
        <div aria-hidden="true" class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
    </div>
</div><section class="call-to-action-seven">
    <div class="bg-img-pos bg-image" style="background-image: url(./images/background/7.png)"></div>
    <div class="auto-container">
        <div class="outer-box wow fadeIn">
            <figure class="small-image"><img src="images/resource/image-8.png" alt=""></figure>
            <h2 class="title">Better digital development team <br>and services at your <br>fingertips</h2>
            <a href="page-contact.php" class="theme-btn btn-style-one light"><span class="btn-title">Discover more</span></a>
        </div>
    </div>
</section><section id="services" class="services-section style-two">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">Services We’re Offering</span>
            <h2>Explore What Services <br>We’re Offering</h2>
        </div>

        <div class="row">
            <!-- Service Block -->
            <div class="service-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-service-details.php"><img src="images/resource/service-1.jpg" alt=""></a></figure>
                        <div class="icon-box"><i class="icon flaticon-business-020-hierarchy"></i></div>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-service-details.php">Website <br>Development</a></h4>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                        <a href="page-service-details.php" class="read-more">read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-service-details.php"><img src="images/resource/service-2.jpg" alt=""></a></figure>
                        <div class="icon-box"><i class="icon flaticon-business-002-graph"></i></div>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-service-details.php">Graphic <br>Designing</a></h4>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                        <a href="page-service-details.php" class="read-more">read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-service-details.php"><img src="images/resource/service-3.jpg" alt=""></a></figure>
                        <div class="icon-box"><i class="icon flaticon-business-048-coin"></i></div>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-service-details.php">Digital <br>Marketing</a></h4>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                        <a href="page-service-details.php" class="read-more">read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="fun-fact-section-five style-two">
    <div class="bg-image" style="background-image: url(images/background/bg-funfact1.png);"></div>
    <div class="auto-container">
        <div class="sec-title light mb-60">
            <div class="row">
                <div class="col-lg-7">
                    <h2 class="mb-4 mb-lg-0">Hundreds of Customers Trust Our Company</h2>
                </div>
                <div class="col-lg-5 text-lg-end">
                    <a href="page-project-details.php" class="theme-btn btn-style-four mt-lg-4"><span class="btn-title">Get Started</span></a>
                </div>
            </div>
        </div>
        <div class="fact-counter">
            <div class="row">
                <!-- Counter block-->
                <div class="counter-block-six col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner">
                        <div class="icon-box"><i class="flaticon-business-060-graph"></i></div>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="990">0</span></div>
                        <h4 class="counter-title">Projects Completed</h4>
                    </div>
                </div>
        
                <!--Counter block-->
                <div class="counter-block-six col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                    <div class="inner">
                        <div class="icon-box"><i class="flaticon-business-035-helpline"></i></div>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="370">0</span></div>
                        <h4 class="counter-title">Repeat Customers</h4>
                    </div>
                </div>
        
                <!--Counter block-->
                <div class="counter-block-six col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                    <div class="inner">
                        <div class="icon-box"><i class="flaticon-business-020-hierarchy"></i></div>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="860">0</span></div>
                        <h4 class="counter-title">Satisfied Customers</h4>
                    </div>
                </div>
        
                <!--Counter block-->
                <div class="counter-block-six col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
                    <div class="inner">
                        <div class="icon-box"><i class="flaticon-business-048-coin"></i></div>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="88">0</span></div>
                        <h4 class="counter-title">Team Members</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="testimonial" class="testimonial-section-six style-two pt-0">
	<div class="bg-image" style="background-image: url(images/icons/pattern-39.jpg);"></div>

	<div class="auto-container">
		<div class="sec-title text-center">
			<span class="sub-title">Our testimonials</span>
			<h2>What Our Customers are <br>Talking About us.</h2>
		</div>
		<div class="carousel-outer">

			<div class="testimonial-carousel-seven owl-carousel owl-theme">
				<!-- Testimonial Block -->
				<div class="testimonial-block-six">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><img src="images/resource/testimonial6-1.jpg" alt=""></figure>
						</div>
						<div class="content-box">
							<div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
							<div class="text">To review means to look back over something for evaluation or memory. It’s always a joy to hear that the work I do has positively impacted our clients.</div>
							<div class="info-box">
								<h5 class="name">Aleesha Brown</h5>
								<span class="designation">Customers</span>
								<span class="icon icon-quote-2"></span>
							</div>
						</div>
					</div>
				</div>

				<!-- Testimonial Block -->
				<div class="testimonial-block-six">
					<div class="inner-box">
						<div class="image-box">
							<figure class="image"><img src="images/resource/testimonial6-2.jpg" alt=""></figure>
						</div>
						<div class="content-box">
							<div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
							<div class="text">To review means to look back over something for evaluation or memory. It’s always a joy to hear that the work I do has positively impacted our clients.</div>
							<div class="info-box">
								<h5 class="name">Kevin Martin</h5>
								<span class="designation">Customers</span>
								<span class="icon icon-quote-2"></span>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</section><section class="process-section pb-0">
	<div class="bg-image2 bg-img-pos" style="background-image: url(images/icons/pattern-40.png);"></div>
    <div class="auto-container">
      <div class="sec-title text-center"> <span class="sub-title style-three">Working Steps</span>
        <h2 class="scrub-each-word text-split">How We Work</h2>
      </div>
      <div class="row"> 
        <!-- Process Block -->
        <div class="process-block col-lg-4 col-md-6 wow fadeInUp">
          <div class="inner-box">
            <div class="count">01</div>
            <div class="content">
              <div class="icon-box"><i class="icon flaticon-business-049-presentation"></i></div>
            </div>
          </div>
          <div class="content-box">
          	<h4 class="title">Share Your Concept</h4>
          	<div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean throughly refresing.</div>
          </div>
        </div>
        <!-- Process Block -->
        <div class="process-block col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="300ms">
          <div class="inner-box">
            <div class="count">02</div>
            <div class="content">
              <div class="icon-box"><i class="icon flaticon-business-020-hierarchy"></i></div>
            </div>
          </div>
          <div class="content-box">
          	<h4 class="title">Let’s Start Development</h4>
          	<div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean throughly refresing.</div>
          </div>
        </div>
        <!-- Process Block -->
        <div class="process-block col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="600ms">
          <div class="inner-box">
            <div class="count">03</div>
            <div class="content">
              <div class="icon-box"><i class="icon flaticon-business-054-graph"></i></div>
            </div>
          </div>
          <div class="content-box">
          	<h4 class="title">Ready to Launch</h4>
          	<div class="text">Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean throughly refresing.</div>
          </div>
        </div>
      </div>
    </div>
</section><section class="why-choose-six">
    <div class="anim-icons">
        <img class="shape-image1 bounce-y" src="images/icons/shape-vector1.png" alt="">
    </div>
    <div class="auto-container">
        <div class="row">
            <!-- Content Column -->
            <div class="content-column col-lg-6 col-md-12">
                <div class="inner-column wow fadeInRight">
                    <div class="sec-title">
                        <i class="sub-title">company benefits</i>
                        <h2>Why should choose our agency?</h2>
                        <h4 class="other-title">Proin est lacus, sagittis lobortis iaculise get.</h4>
                        <div class="text">There are many variations of passages of available but the majority have suffered. Alteration in some form, lipsum is simply free text by injected humou or randomised words even believable.There are many variations of passages of available</div>
                        <img class="shape-image2 bounce-y" src="images/icons/shape-23.png" alt="">
                    </div>

                    <div class="info-outer">
                        <div class="row">
                            <div class="info-box col-lg-4 col-md-4">
                                <div class="inner">
                                    <i class="icon flaticon-business-048-coin"></i>
                                    <h5 class="title">Leader in digital marketing</h5>
                                </div>
                            </div>
                            <div class="info-box col-lg-4 col-md-4">
                                <div class="inner">
                                    <i class="icon flaticon-business-020-hierarchy"></i>
                                    <h5 class="title">Highest success rates</h5>
                                </div>
                            </div>
                            <div class="info-box col-lg-4 col-md-4">
                                <div class="inner">
                                    <i class="icon flaticon-business-054-graph"></i>
                                    <h5 class="title">Quality marketing solutions</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image anim-overlay"><img src="images/resource/image-13.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="features-section-four pull-down p-0">
  <div class="auto-container">
    <div class="row g-0">
      <!-- Feature Block -->
      <div class="feature-block-four col-lg-6 col-md-12 col-sm-12 wow fadeInLeft">
        <div class="inner-box">
          <div class="content" style="background-image: url(images/resource/feature-bg-7.jpg)">
            <span class="icon flaticon-business-020-hierarchy"></span>
            <h5 class="title">The best user interfaces</h5>
            <div class="text">There are many variations of available</div>
          </div>
        </div>
      </div>

      <!-- Feature Block -->
      <div class="feature-block-four col-lg-6 col-md-12 col-sm-12 wow fadeInRight">
        <div class="inner-box">
          <div class="content" style="background-image: url(images/resource/feature-bg-8.jpg)">
            <span class="icon flaticon-business-048-coin"></span>
            <h5 class="title">Software IT Outsourcing</h5>
            <div class="text">There are many variations of available</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section id="news" class="news-section alternate">
  <div class="bg-shape"></div>
  <div class="auto-container">
    <div class="sec-title text-center light">
      <span class="sub-title">from the blog</span>
      <h2>News & Articles</h2>
    </div>

    <div class="row">
      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>