
<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 03 Dark</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"><!-- REVOLUTION SETTINGS STYLES -->
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION NAVIGATION STYLES -->

<link href="css/style.css" rel="stylesheet">

    <link href="css/style-dark.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">

<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 


<header class="main-header header-style-four">
    <!-- Header Lower -->
    <div class="header-lower">
        <!-- Main box -->
        <div class="main-box">
            <div class="logo-box">
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
                </div>
            </div>

            <!--Nav Box-->
            <div class="nav-outer">

                <nav class="nav main-menu">
                                        <ul class="navigation">
  <li class="current dropdown"><a href="index.php">Home</a>
  <ul>
      <li><a href="index.php">Home Layout 1</a></li>
      <li><a href="index-2.php">Home Layout 2</a></li>
      <li><a href="index-3.php">Home Layout 3</a></li>
      <li class="dropdown"><a href="#">More Home Layouts</a>
        <ul>
          <li><a href="index-4.php">Home Layout 4</a></li>
          <li><a href="index-5.php">Home Layout 5</a></li>
          <li><a href="index-6.php">Home Layout 6</a></li>
          <li><a href="index-7.php">Home Layout 7</a></li>
          <li><a href="index-8.php">Home Layout 8</a></li>
          <li><a href="index-9.php">Home Layout 9</a></li>
          <li><a href="index-10.php">Home Layout 10</a></li>
          <li><a href="index-11.php">Home Layout 11</a></li>
          <li><a href="index-12.php">Home Layout 12</a></li>
          <li><a href="index-13.php">Home Layout 13</a></li>
          <li><a href="index-14.php">Home Layout 14</a></li>
          <li><a href="index-15.php">Home Layout 15</a></li>
          <li><a href="index-16.php">Home Layout 16</a></li>
          <li><a href="index-17.php">Home Layout 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Styles</a>
        <ul>
          <li><a href="index.php">Header Style 1</a></li>
          <li><a href="index-2.php">Header Style 2</a></li>
          <li><a href="index-3.php">Header Style 3</a></li>
          <li><a href="index-4.php">Header Style 4</a></li>
          <li><a href="index-5.php">Header Style 5</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Single</a>
        <ul>
          <li><a href="index-1-single.php">Header Single 1</a></li>
          <li><a href="index-2-single.php">Header Single 2</a></li>
          <li><a href="index-3-single.php">Header Single 3</a></li>
          <li><a href="index-4-single.php">Header Single 4</a></li>
          <li><a href="index-5-single.php">Header Single 5</a></li>
          <li><a href="index-6-single.php">Header Single 6</a></li>
          <li><a href="index-7-single.php">Header Single 7</a></li>
          <li><a href="index-8-single.php">Header Single 8</a></li>
          <li><a href="index-9-single.php">Header Single 9</a></li>
          <li><a href="index-10-single.php">Header Single 10</a></li>
          <li><a href="index-11-single.php">Header Single 11</a></li>
          <li><a href="index-12-single.php">Header Single 12</a></li>
          <li><a href="index-13-single.php">Header Single 13</a></li>
          <li><a href="index-14-single.php">Header Single 14</a></li>
          <li><a href="index-15-single.php">Header Single 15</a></li>
          <li><a href="index-16-single.php">Header Single 16</a></li>
          <li><a href="index-17-single.php">Header Single 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Dark</a>
        <ul>
          <li><a href="index-1-dark.php">Header Dark 1</a></li>
          <li><a href="index-2-dark.php">Header Dark 2</a></li>
          <li><a href="index-3-dark.php">Header Dark 3</a></li>
          <li><a href="index-4-dark.php">Header Dark 4</a></li>
          <li><a href="index-5-dark.php">Header Dark 5</a></li>
          <li><a href="index-6-dark.php">Header Dark 6</a></li>
          <li><a href="index-7-dark.php">Header Dark 7</a></li>
          <li><a href="index-8-dark.php">Header Dark 8</a></li>
          <li><a href="index-9-dark.php">Header Dark 9</a></li>
          <li><a href="index-10-dark.php">Header Dark 10</a></li>
          <li><a href="index-11-dark.php">Header Dark 11</a></li>
          <li><a href="index-12-dark.php">Header Dark 12</a></li>
          <li><a href="index-13-dark.php">Header Dark 13</a></li>
          <li><a href="index-14-dark.php">Header Dark 14</a></li>
          <li><a href="index-15-dark.php">Header Dark 15</a></li>
          <li><a href="index-16-dark.php">Header Dark 16</a></li>
          <li><a href="index-17-dark.php">Header Dark 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Rtl Page</a>
        <ul>
          <li><a href="index-1-rtl.php">Header Rtl</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About</a></li>
      <li class="dropdown"><a href="#">Projects</a>
        <ul>
          <li><a href="page-projects.php">Projects List</a></li>
          <li><a href="page-project-details.php">Project Details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team List</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-testimonial.php">Testimonial</a></li>
      <li><a href="page-pricing.php">Pricing</a></li>
      <li><a href="page-pricing-switcher.php">Pricing Switcher</a></li>
      <li><a href="page-faq.php">FAQ</a></li>
      <li><a href="page-404.php">Page 404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services List</a></li>
      <li><a href="page-service-details.php">Service Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Shop</a>
    <ul>
      <li><a href="shop-products.php">Products</a></li>
      <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
      <li><a href="shop-product-details.php">Product Details</a></li>
      <li><a href="shop-cart.php">Cart</a></li>
      <li><a href="shop-checkout.php">Checkout</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">News</a>
    <ul>
      <li><a href="news-grid.php">News Grid</a></li>
      <li><a href="news-details.php">News Details</a></li>
    </ul>
  </li>
  <li><a href="page-contact.php">Contact</a></li>
</ul>                </nav>
                <!-- Main Menu End-->
            </div>

            <div class="outer-box">
                    <a href="tel:+92(8800)9806" class="info-btn">
                        <i class="icon fa fa-phone"></i>
                        <small>Call Anytime</small><br> + 88 ( 9800 ) 6802
                    </a>

                    <!-- Mobile Nav toggler -->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
            </div>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>

        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
            <div class="upper-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="close-btn"><i class="icon fa fa-times"></i></div>
            </div>

            <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
            </ul>
            <ul class="contact-list-one">
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <i class="icon lnr-icon-phone-handset"></i>
                        <span class="title">Call Now</span>
                        <a href="tel:+92880098670">+92 (8800) - 98670</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-envelope1"></span>
                        <span class="title">Send Email</span>
                        <a href="mailto:help@company.com">help@company.com</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-clock"></span>
                        <span class="title">Send Email</span>
                        Mon - Sat 8:00 - 6:30, Sunday - CLOSED
                    </div>
                </li>
            </ul>


            <ul class="social-links">
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->

    <!-- Header Search -->
    <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
            <form method="post" action="index.php">
                <div class="form-group">
                    <input type="search" name="search-field" value="" placeholder="Search..." required="">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
    <!-- End Header Search -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="inner-container">
                <!--Logo-->
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="nav-outer">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->

                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div><!-- End Sticky Menu -->
</header><section class="banner-section-three">
    <div class="banner-carousel owl-carousel owl-theme">
        <!-- Slide Item -->
        <div class="slide-item">
            <div class="bg-image" style="background-image: url(images/main-slider/slider3.jpg);"></div>
            <div class="anim-icons animate-1">
                <img class="shape-image1" src="images/main-slider/home3-shape1.png" alt="">
                <img class="shape-image2 bounce-y" src="images/main-slider/home3-shape2.png" alt="">
            </div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="title animate-1">Innovative Teach Solutions</h1>
                    <div class="text animate-2 me-lg-3">With every single one of our clients, we bring forth a deep passion for creative problem solving — which is what we deliver.</div>
                    <div class="btn-box animate-3">
                        <a href="page-about.php" class="theme-btn btn-style-one hvr-light"><span class="btn-title">Discover more</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="services" class="services-section-six style-three pb-0">
  <div class="auto-container">
    <div class="sec-title">
      <div class="row">
        <div class="col-lg-7">
          <span class="sub-title">Our Service</span>
          <h2>Services we’re offering <br>to our customers</h2>
        </div>
        <div class="col-lg-5">
          <div class="text">There are many variations of passages of available but the majority have suffered alteration in some form, by injected hum randomised words which don't slightly. but the majority have suffered alteration in some form.</div>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">UI / UX Creative <br>Design</a></h4>
          <i class="icon flaticon-Set flaticon-business-002-color-sample"></i>
          <a href="page-service-details.php" class="read-more">Read More</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">Website Graphics <br>Design</a></h4>
          <i class="icon flaticon-Set flaticon-business-013-idea"></i>
          <a href="page-service-details.php" class="read-more">Read More</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">Streagy & Digital <br>Marketing</a></h4>
          <i class="icon flaticon-Set flaticon-business-007-settings"></i>
          <a href="page-service-details.php" class="read-more">Read More</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">Effective Business <br>Growth</a></h4>
          <i class="icon flaticon-Set flaticon-business-3956725"></i>
          <a href="page-service-details.php" class="read-more">Read More</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">Data Security <br>Management</a></h4>
          <i class="icon flaticon-Set flaticon-business-013-campaign"></i>
          <a href="page-service-details.php" class="read-more">Read More</a>
        </div>
      </div>
    </div>
  </div>
</section><section id="about" class="about-section-eight">
  <div class="auto-container">
    <div class="row">
      <div class="content-column col-xl-7 col-lg-7 col-md-12 col-sm-12 order-lg-2 wow fadeInRight" data-wow-delay="600ms">
        <div class="inner-column ms-lg-5 ps-lg-3">
          <div class="sec-title">
            <span class="sub-title">ABOUT OUR COMPANY</span>
            <h2>Professional it experts for tech company solutions</h2>
            <div class="text">Web designing in a powerful way of just not an only professions, however, in a passion for our first impression on visitors by injected hum randomised words which don't slightly passages hum randomised however, in a passion</div>
          </div>

          <div class="content-box">
            <div class="row">
              <div class="about-block-layout-h3 col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon flaticon-business-020-hierarchy"></i> Best Digital <br>Resources </h5>
              </div>

              <div class="about-block-layout-h3 col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon flaticon-business-002-graph"></i> Available Digital <br>Solutions </h5>

              </div>
            </div>	

            <div class="text">Web designing in a powerful way of just not an only professions, however, in a passion for our first impression on visitors by injected hum randomised words</div>


            <div class="btn-box">
              <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title">Discover more</span></a>
              <a href="tel:+92(8800)9806" class="info-btn">
                <i class="icon fa fa-phone"></i>
                <small>Call Anytime</small><br> 92 666 888 000
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Image Column -->
      <div class="image-column col-xl-5 col-lg-5 col-md-8 col-sm-12">
        <div class="inner-column">
          <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about3-1.png" alt="">
          </figure>
          <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about3-2.png" alt="">
          </figure>
          <span class="icon-dots2"></span>
        </div>
      </div>
    </div>
  </div>
</section><section id="project" class="projects-section-four style-two pb-0">
  <div class="auto-container">
    <div class="sec-title light">
      <div class="row">
        <div class="col-lg-7">
          <span class="sub-title">Our Service</span>
          <h2>Explore what services <br>we’re offering</h2>
        </div>
        <div class="col-lg-5">
          <div class="text">There are many variations of passages of available but majority alteration in some form, by humou or randomised words.</div>
        </div>
      </div>
    </div>
    <div class="row">
      <!-- Project Block -->
      <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-project-details.php" title="">Product & Design</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-project-details.php" title="">Marketing webdesign</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-project-details.php" title="">Product & Design</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-4.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-project-details.php" title="">Marketing webdesign</a></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="faqs-section-two">
    <div class="anim-icons">
        <span class="icon icon-object-2"></span>
        <span class="icon icon-object-3"></span>
    </div>
    <div class="auto-container">
        <div class="row">
            <!-- FAQ Column -->
            <div class="faq-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Our faqs</span>
                        <h2>Frequently Asked Questions.</h2>
                        <div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit placerat neque.</div>
                    </div>

                    <ul class="accordion-box style-two wow fadeInRight">
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active"> Why should we work with your comapny?
                                <div class="icon fa fa-angle-right"></div>
                            </div>
                            <div class="acc-content current">
                                <div class="content">
                                    <div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn ">How can IT solutions benefit my business?
                                <div class="icon fa fa-angle-right"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"> What types of IT solutions are available?
                                <div class="icon fa fa-angle-right"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">Sed rhoncus facilisis purus, at accumsan purus sagittis vitae. Nullam acelit at eros imperdiet. Pellentesque sit</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Form Column -->
            <div class="content-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="banner-box-one">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <h3 class="title">Have 30+ Years Immigration Experience for Give you Visa Approval.</h3>
                    </div>
                    <div class="banner-box-two">
                        <figure class="image"><img src="images/resource/image-5.png" alt=""></figure>
                        <h5 class="caption">Explore our new completed projects.</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="fun-fact-section-four" style="background-image: url(./images/icons/pattern-27.png)">
    <div class="auto-container">
        <div class="fact-counter">
            <div class="row">
                <!-- Counter block-->
                <div class="counter-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner">
                        <i class="icon flaticon-business-060-graph"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="4524">0</span></div>
                        <span class="counter-title">Project Complete</span>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                    <div class="inner">
                        <i class="icon flaticon-business-035-helpline"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="1500">0</span></div>
                        <span class="counter-title">HAPPY CLIENTS</span>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                    <div class="inner">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="2500">0</span></div>
                        <span class="counter-title">AWWORD WINGING</span>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
                    <div class="inner">
                        <i class="icon flaticon-business-048-coin"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="1000">0</span></div>
                        <span class="counter-title">COMPANY TEAM</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="about-section-nine">
  <div class="auto-container">
    <div class="tabs-box tabs-three">
      <!--Tabs Box-->
      <ul class="tab-buttons clearfix">
        <li class="tab-btn" data-tab="#tab1"><span class="title">Our Mission</span></li>
        <li class="tab-btn active-btn" data-tab="#tab2"><span class="title">Our Vision</span></li>
        <li class="tab-btn" data-tab="#tab3"><span class="title">Our History</span></li>
      </ul>

      <div class="tabs-content">
        <!--Tab-->
        <div class="tab" id="tab1">
          <div class="row">
            <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
              <div class="inner-column">
                <div class="sec-title">
                  <h2>Our mission is to ensure services</h2>
                  <div class="text">There are many variations of passages of lorem free market to available, but the majority have alteration in some form, by injected humour</div>
                </div>
              </div>
            </div>

            <div class="image-column col-lg-6 col-md-6 col-sm-12">
              <div class="inner-column">
                <div class="info-box">
                  <h3 class="title">We have over 10 years of experience</h3>
                  <a href="#" class="read-more">Read More ></a>
                </div>

                <div class="image-box">
                  <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                  <i class="icon flaticon-business-060-graph"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--Tab-->
        <div class="tab active-tab" id="tab2">
          <div class="row">
            <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
              <div class="inner-column">
                <!-- Feature Block Nine -->
                <div class="icon-box-style">
                  <div class="inner-box ">
                    <i class="icon flaticon-business-011-dollar"></i>
                    <h4 class="title"><a href="page-service-details.php">Best Business Solution</a></h4>
                    <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                  </div>
                </div>

                <!-- Feature Block Nine -->
                <div class="icon-box-style">
                  <div class="inner-box ">
                    <i class="icon flaticon-business-012-startup"></i>
                    <h4 class="title"><a href="page-service-details.php">Highest Customer Value</a></h4>
                    <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                  </div>
                </div>
              </div>
            </div>

            <div class="image-column col-lg-6 col-md-6 col-sm-12">
              <div class="inner-column">
                <div class="info-box">
                  <h3 class="title">We have over 24 years of experience</h3>
                  <a href="#" class="read-more">Read More ></a>
                </div>

                <div class="image-box">
                  <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                  <i class="icon flaticon-business-060-graph"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--Tab-->
        <div class="tab" id="tab3">
          <div class="tab-our-history">
            <div class="row">
              <div class="image-column col-lg-6 col-md-6 col-sm-12">
                <div class="inner-column">
                  <div class="image-box">
                    <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                    <i class="icon flaticon-business-060-graph"></i>
                  </div>

                  <div class="info-box">
                    <h3 class="title">We have over 24 years of experience</h3>
                    <a href="#" class="read-more">Read More ></a>
                  </div>
                </div>
              </div>

              <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
                <div class="inner-column">
                  <!-- Feature Block Nine -->
                  <div class="icon-box-style">
                    <div class="inner-box ">
                      <i class="icon flaticon-business-011-dollar"></i>
                      <h4 class="title"><a href="page-service-details.php">Best Business Solution</a></h4>
                      <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                    </div>
                  </div>

                  <!-- Feature Block Nine -->
                  <div class="icon-box-style">
                    <div class="inner-box ">
                      <i class="icon flaticon-business-012-startup"></i>
                      <h4 class="title"><a href="page-service-details.php">Highest Customer Value</a></h4>
                      <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section id="testimonial" class="testimonial-section-six pt-0">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">Our testimonials</span>
            <h2>What Our Customers are <br>Talking About us.</h2>
        </div>
        <div class="carousel-outer">

            <div class="testimonial-carousel-seven owl-carousel owl-theme">
                <!-- Testimonial Block -->
                <div class="testimonial-block-six">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="images/resource/testimonial6-1.jpg" alt=""></figure>
                        </div>
                        <div class="content-box">
                            <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                            <div class="text">To review means to look back over something for evaluation or memory. It’s always a joy to hear that the work I do has positively impacted our clients.</div>
                            <div class="info-box">
                                <h5 class="name">Aleesha Brown</h5>
                                <span class="designation">Customers</span>
                                <span class="icon icon-quote-2"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Testimonial Block -->
                <div class="testimonial-block-six">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="images/resource/testimonial6-2.jpg" alt=""></figure>
                        </div>
                        <div class="content-box">
                            <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                            <div class="text">To review means to look back over something for evaluation or memory. It’s always a joy to hear that the work I do has positively impacted our clients.</div>
                            <div class="info-box">
                                <h5 class="name">Kevin Martin</h5>
                                <span class="designation">Customers</span>
                                <span class="icon icon-quote-2"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section><section id="team" class="team-section-three style-two">
  <div class="auto-container">
    <div class="sec-title light text-center">
      <span class="sub-title">MEET OUR TEAM MEMBERS</span>
      <h2>Meet the professional team <br>behind the success</h2>
    </div>

    <div class="row">
      <!-- Team Block -->
      <div class="col-lg-3 col-sm-6 wow fadeInUp">
        <div class="team-block-three">
          <div class="inner-box">
            <div class="image-box">
              <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-1.jpg" alt=""></a></figure>
              <div class="social-links">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div>
              <span class="share-icon fa fa-share-alt"></span>
            </div>
            <div class="info-box">
              <span class="designation">IT Director</span>
              <h4 class="name"><a href="page-team-details.php">Robert jonson</a></h4>
            </div>
          </div>
        </div>
      </div>

      <!-- Team Block -->
      <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
        <div class="team-block-three">
          <div class="inner-box">
            <div class="image-box">
              <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-2.jpg" alt=""></a></figure>
              <div class="social-links">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div>
              <span class="share-icon fa fa-share-alt"></span>
            </div>
            <div class="info-box">
              <span class="designation">HR Admin</span>
              <h4 class="name"><a href="page-team-details.php">Sarah Albert </a></h4>
            </div>
          </div>
        </div>
      </div>

      <!-- Team Block -->
      <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
        <div class="team-block-three">
          <div class="inner-box">
            <div class="image-box">
              <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-3.jpg" alt=""></a></figure>
              <div class="social-links">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div>
              <span class="share-icon fa fa-share-alt"></span>
            </div>
            <div class="info-box">
              <span class="designation">Manager</span>
              <h4 class="name"><a href="page-team-details.php">David Cooper </a></h4>
            </div>
          </div>
        </div>
      </div>

      <!-- Team Block -->
      <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
        <div class="team-block-three">
          <div class="inner-box">
            <div class="image-box">
              <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-4.jpg" alt=""></a></figure>
              <div class="social-links">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </div>
              <span class="share-icon fa fa-share-alt"></span>
            </div>
            <div class="info-box">
              <span class="designation">Manager</span>
              <h4 class="name"><a href="page-team-details.php">Recherd william </a></h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="clients-section border-top">
    <div class="auto-container">
        <!-- Sponsors Outer -->
        <div class="sponsors-outer">
            <!--clients carousel-->
            <ul class="clients-carousel owl-carousel owl-theme pt-5 pb-5">
                <li class="slide-item"> <a href="#"><img src="images/resource/client-2.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-3.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-4.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-5.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-6.png" alt=""></a> </li>
            </ul>
        </div>
    </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>