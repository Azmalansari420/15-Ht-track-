<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 07 Single</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">

<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-six">
  <!-- Header Top -->
  <div class="header-top">
    <div class="inner-container">
  
      <div class="top-left">
        <!-- Info List -->
        <ul class="list-style-one">
          <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">needhelp@company.com</a></li>
          <li><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li>
        </ul>
      </div>
  
      <div class="top-right">
        <ul class="useful-links">
          <li><a href="#">Help</a></li>
          <li><a href="#">Support</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <ul class="social-icon-one">
          <li><a href="#"><span class="fa fa-x"></span></a></li>
          <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
          <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
          <li><a href="#"><span class="fab fa-instagram"></span></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Header Top -->
  
  <div class="header-lower">
    <!-- Main box -->
    <div class="main-box">
      <div class="logo-box">
        <div class="logo">
                      <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
        </div>
      </div>


      <!--Nav Box-->
      <div class="nav-outer">    
        <nav class="nav main-menu">
                      <ul class="navigation">
    <li class="current"><a href="#home">Home</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#project">Project</a></li>
    <li><a href="#testimonial">Testimonial</a></li>
    <li><a href="#news">News</a></li>
    <li><a href="#contact">Contact</a></li>
</ul>        </nav>
        <!-- Main Menu End-->
      </div>

      <div class="outer-box">
        <!-- Header Search -->
        <button class="ui-btn ui-btn search-btn">
          <span class="icon lnr lnr-icon-search"></span>
        </button>

        <a href="tel:+92(8800)9806" class="info-btn">
          <i class="icon fa fa-phone"></i>
          <small>Call Anytime</small><br> + 88 ( 9800 ) 6802
        </a>
        <!-- Mobile Nav toggler -->
        <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
      </div>
    </div>
  </div>

  <!-- Mobile Menu  -->
  <div class="mobile-menu">
    <div class="menu-backdrop"></div>
  
    <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
    <nav class="menu-box">
      <div class="upper-box">
        <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
        <div class="close-btn"><i class="icon fa fa-times"></i></div>
      </div>
  
      <ul class="navigation clearfix">
        <!--Keep This Empty / Menu will come through Javascript-->
      </ul>
      <ul class="contact-list-one">
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <i class="icon lnr-icon-phone-handset"></i>
            <span class="title">Call Now</span>
            <a href="tel:+92880098670">+92 (8800) - 98670</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-envelope1"></span>
            <span class="title">Send Email</span>
            <a href="mailto:help@company.com">help@company.com</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-clock"></span>
            <span class="title">Send Email</span>
            Mon - Sat 8:00 - 6:30, Sunday - CLOSED
          </div>
        </li>
      </ul>
  
  
      <ul class="social-links">
        <li><a href="#"><i class="fa fa-x"></i></a></li>
        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      </ul>
    </nav>
  </div><!-- End Mobile Menu -->

  <!-- Header Search -->
  <div class="search-popup">
    <span class="search-back-drop"></span>
    <button class="close-search"><span class="fa fa-times"></span></button>
  
    <div class="search-inner">
      <form method="post" action="index.php">
        <div class="form-group">
          <input type="search" name="search-field" value="" placeholder="Search..." required="">
          <button type="submit"><i class="fa fa-search"></i></button>
        </div>
      </form>
    </div>
  </div>
  <!-- End Header Search -->

  <!-- Sticky Header  -->
  <div class="sticky-header">
    <div class="auto-container">
      <div class="inner-container">
        <!--Logo-->
        <div class="logo">
                    <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
        </div>
  
        <!--Right Col-->
        <div class="nav-outer">
          <!-- Main Menu -->
          <nav class="main-menu">
            <div class="navbar-collapse show collapse clearfix">
              <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
              </ul>
            </div>
          </nav><!-- Main Menu End-->
  
          <!--Mobile Navigation Toggler-->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div><!-- End Sticky Menu -->
</header><section class="banner-section-seven">
    <div class="banner-carousel owl-carousel owl-theme">
        <!-- Slide Item -->
        <div class="slide-item">
            <div class="bg-image" style="background-image: url(images/main-slider/slider7.jpg);"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="title animate-1">Your Gateway to Digital Transformation</h1>
                    <div class="text animate-2">Web designing in a powerful way of just not an only professions, however, in a passion for our Company. We have to a tendency to believe the idea that smart looking of any website is the first impression on visitors</div>
                    <div class="btn-box animate-3">
                        <a href="page-about.php" class="theme-btn btn-style-four"><span class="btn-title">Explore Now</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="about" class="about-section-fourteen">
  <div class="anim-icons animate-1">
    <img class="shape-image1" src="images/icons/shape-19.png" alt="">
  </div>
  <div class="auto-container">
    <div class="row">
      <!-- Content Column -->
      <div class="content-column col-lg-6 col-md-12">
        <div class="inner-column wow fadeInRight">
          <div class="sec-title">
            <span class="sub-title">ABOUT OUR COMPANY</span>
            <h2>Professional IT Experts for Your Tech Solutions</h2>
            <div class="bold-text">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words.</div>
            <div class="text">You need to be sure there isn't anything embarrassing hidden in the middle of text. All the lorem generators on the Internet</div>
          </div>
          <ul class="list-style-three two-column">
            <li>Nsectetur cing elit.</li>
            <li>You’re going passage.</li>
            <li>Suspe ndisse suscipit leo.</li>
            <li>Lorem ipsum gen on tend.</li>
          </ul>
          <a href="page-about.php" class="theme-btn btn-style-four"><span class="btn-title">Explore now</span></a>
        </div>
      </div>
      <!-- Image Column -->
      <div class="image-column col-lg-6 col-md-12 col-sm-12">
        <div class="inner-column">
          <div class="image-box">
            <figure class="bg-image"><img src="images/resource/image-10.jpg" alt=""></figure>
            <figure class="image"><img src="images/resource/image-9.jpg" alt=""></figure>
            <div class="info-box">
              <i class="icon flaticon-business-020-hierarchy"></i>
              <span class="count">4,89000</span>
              <div class="text">We Process Clients Visa’s only in 20 Days</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section id="services" class="features-section-five style-two pt-3">
    <div class="auto-container">
        <div class="row">
            <!-- Feature Block Five -->
            <div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box ">
                    <figure class="bg-image"><img src="images/resource/feature-bg-3.jpg" alt=""></figure>
                    <h4 class="title"><a href="page-about.php">Web Development</a></h4>
                    <div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
                    <span class="count">01</span>
                </div>
            </div>

            <!-- Feature Block Five -->
            <div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box ">
                    <figure class="bg-image"><img src="images/resource/feature-bg-4.jpg" alt=""></figure>
                    <h4 class="title"><a href="page-about.php">WebCase Solutions</a></h4>
                    <div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
                    <span class="count">02</span>
                </div>
            </div>

            <!-- Feature Block Five -->
            <div class="feature-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box ">
                    <figure class="bg-image"><img src="images/resource/feature-bg-5.jpg" alt=""></figure>
                    <h4 class="title"><a href="page-about.php">Data Security</a></h4>
                    <div class="text">There are many variations of passages of Lorem Ipsum available, but the majority</div>
                    <span class="count">03</span>
                </div>
            </div>
        </div>
    </div>
</section><section id="project" class="projects-section-six pt-0">
    <div class="auto-container">
      <div class="sec-title text-center"> 
      	<span class="sub-title">Our Portfolio</span>
        <h2>Explore Our Recently <br>Completed Projects</h2>
      </div>
      <div class="row"> 
        <!-- Project Block -->
        <div class="project-block-six col-lg-4 col-md-6">
          <div class="inner-box">
            <figure class="image overlay-anim"><img src="images/resource/project1-1.jpg" alt="Image"></figure>
            <div class="content-box">
              <div class="content">
                <h4 class="title">Social Marketing</h4>
                <a href="page-project-details.php" class="read-more"><i class="icon fa fa-long-arrow-right"></i></a>
                <div class="inner">
                  <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Project Block -->
        <div class="project-block-six col-lg-4 col-md-6">
          <div class="inner-box">
            <figure class="image overlay-anim"><img src="images/resource/project1-2.jpg" alt="Image"></figure>
            <div class="content-box">
              <div class="content">
                <h4 class="title">Web design</h4>
                <a href="page-project-details.php" class="read-more"><i class="icon fa fa-long-arrow-right"></i></a>
                <div class="inner">
                  <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Project Block -->
        <div class="project-block-six col-lg-4 col-md-6">
          <div class="inner-box">
            <figure class="image overlay-anim"><img src="images/resource/project1-3.jpg" alt="Image"></figure>
            <div class="content-box">
              <div class="content">
                <h4 class="title">Smart Visions</h4>
                <a href="page-project-details.php" class="read-more"><i class="icon fa fa-long-arrow-right"></i></a>
                <div class="inner">
                  <div class="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom-text"><div class="text">TOP RATED BY CUSTOMERS & IMMIGRATION FIRMS WITH 100% SUCCESS RATE.</div></div>
    </div>
  </section><section class="pricing-section-three style-two">
    <div class="auto-container">
        <div class="sec-title text-center"> <span class="sub-title">Pricing plan</span>
        <h2 class="scrub-each-word text-split">Best pricing plans thatfits <br>foryou</h2>
        </div>
        <div class="tm-pricing-plan-switcher">
        <span class="title-normal">Monthly</span>
        <div class="price-switcher">
            <div class="pricing-switcher-btn"> <a href="javascript:" aria-label="Pricing" class="btn-toggle" data-pricing-trigger><span class="round"></span></a></div>
        </div>
        <span class="title-secondary">Yearly</span> <span class="price-offer">20% Off</span>
        </div>
        <div class="tabs-content">
        <div class="row">
            <!-- Pricing Block -->
            <div class="tm-pricing-table pricing-block-three col-xl-4 col-md-6">
            <div class="inner-box">
                <div class="icon-arrow2"></div>
                <div class="offer">Save <span>23%</span></div>
                <h4 class="title">Regular Plan</h4>
                <div class="price-box-outer">
                <div class="price-box price-normal">
                    <h4 class="price"><span>$</span>29</h4>
                    <span class="validaty">/per month</span>
                </div>
                <div class="price-box price-secondary">
                    <h4 class="price"><span>$</span>199</h4>
                    <span class="validaty">/ Yearly</span>
                </div>
                </div>
                <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Network Security Audit</li>
                <li><i class="fa-solid fa-circle-check"></i> Custom Software</li>
                <li><i class="fa-solid fa-circle-check"></i> Cyber Security</li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
                </ul>
                <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
            </div>
            <!-- Pricing Block -->
            <div class="tm-pricing-table pricing-block-three col-xl-4 col-md-6">
            <div class="inner-box">
                <div class="icon-arrow2"></div>
                <div class="offer">Save <span>23%</span></div>
                <h4 class="title">Standard Plan</h4>
                <div class="price-box-outer">
                <div class="price-box price-normal">
                    <h4 class="price"><span>$</span>88</h4>
                    <span class="validaty">/per month</span>
                </div>
                <div class="price-box price-secondary">
                    <h4 class="price"><span>$</span>399</h4>
                    <span class="validaty">/ Yearly</span>
                </div>
                </div>
                <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Managed IT Services</li>
                <li><i class="fa-solid fa-circle-check"></i> Cybersecurity Training</li>
                <li><i class="fa-solid fa-circle-check"></i> Data Backup and Recovery</li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
                </ul>
                <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
            </div>
            <!-- Pricing Block -->
            <div class="tm-pricing-table pricing-block-three col-xl-4 col-md-6">
            <div class="inner-box">
                <div class="icon-arrow2"></div>
                <div class="offer">Save <span>23%</span></div>
                <h4 class="title">Ultimate Plan</h4>
                <div class="price-box-outer">
                <div class="price-box price-normal">
                    <h4 class="price"><span>$</span>149</h4>
                    <span class="validaty">/per month</span>
                </div>
                <div class="price-box price-secondary">
                    <h4 class="price"><span>$</span>599</h4>
                    <span class="validaty">/ Yearly</span>
                </div>
                </div>
                <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Migration Consultation</li>
                <li><i class="fa-solid fa-circle-check"></i> Data Backup Recovery</li>
                <li><i class="fa-solid fa-circle-check"></i> Cyber Security</li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
                </ul>
                <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
            </div>
        </div>
        </div>
    </div>
</section><section class="faqs-section-two-three">
    <div class="auto-container">
        <div class="row">
            <!-- FAQ Column -->
            <div class="faq-column col-lg-5 col-md-12 col-sm-12">
                <div class="inner-column">

                    <ul class="accordion-box accordion-box-two wow fadeInRight">
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active">Is my technology allowed on tech?
                                <div class="icon fa fa-angle-down"></div>
                            </div>
                            <div class="acc-content current">
                                <div class="content">
                                    <div class="text">Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque tincidunt elit</div>
                                </div>
                            </div>
                        </li>

                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How to soft launch your business?
                                <div class="icon fa fa-angle-down"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque tincidunt elit</div>
                                </div>
                            </div>
                        </li>


                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn"> How to turn visitors into contributors 
                                <div class="icon fa fa-angle-down"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque tincidunt elit</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-lg-7 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image overlay-anim"><img src="images/resource/faq1-1.jpg" alt=""></figure>
                    </div>

                    <div class="graph-box-two">
                        <!-- Pie Graph -->
                        <div class="pie-graph">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ffaa17" data-bgColor="#ffffff" data-width="115" data-height="115"
                                    data-linecap="normal" value="90">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="90" data-speed="2000"></span>%</div>
                            </div>
                            <h6 class="title">Affordable <br>cost</h6>
                        </div>
                        <!-- Pie Graph -->
                        <div class="pie-graph">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ffaa17" data-bgColor="#ffffff" data-width="115" data-height="115"
                                    data-linecap="normal" value="50">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="50" data-speed="2000"></span>%</div>
                            </div>
                            <h6 class="title">Quality <br>of work</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="clients-section style-two">
    <div class="auto-container">
        <!-- Sponsors Outer -->
        <div class="sponsors-outer">
            <!--clients carousel-->
            <ul class="clients-carousel owl-carousel owl-theme pt-5 pb-5">
                <li class="slide-item"> <a href="#"><img src="images/resource/client-2.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-3.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-4.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-5.png" alt=""></a> </li>
                <li class="slide-item"> <a href="#"><img src="images/resource/client-6.png" alt=""></a> </li>
            </ul>
        </div>
    </div>
</section><section class="video-section-four">
    <div class="video-box">
        <div class="bg bg-image" style="background-image: url(./images/background/video-bg2.jpg)"></div>
        <div class="content">
            <div class="btn-box">
                <a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i><span class="ripple"></span></a>
            </div>
        </div>
    </div>
</section><section class="about-section-nine">
    <div class="auto-container">
        <div class="tabs-box tabs-three">
            <!--Tabs Box-->
            <ul class="tab-buttons clearfix">
                <li class="tab-btn" data-tab="#tab1"><span class="title">Our Mission</span></li>
                <li class="tab-btn active-btn" data-tab="#tab2"><span class="title">Our Vision</span></li>
                <li class="tab-btn" data-tab="#tab3"><span class="title">Our History</span></li>
            </ul>

            <div class="tabs-content">
                <!--Tab-->
                <div class="tab" id="tab1">
                    <div class="row">
                        <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-column">
                                <div class="sec-title">
                                    <h2>Our mission is to ensure services</h2>
                                    <div class="text">There are many variations of passages of lorem free market to available, but the majority have alteration in some form, by injected humour</div>
                                </div>
                            </div>
                        </div>

                        <div class="image-column col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-column">
                                <div class="info-box">
                                    <h3 class="title">We have over 10 years of experience</h3>
                                    <a href="#" class="read-more">Read More ></a>
                                </div>

                                <div class="image-box">
                                    <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                                    <i class="icon flaticon-business-060-graph"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Tab-->
                <div class="tab active-tab" id="tab2">
                    <div class="row">
                        <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-column">
                                <!-- Feature Block Nine -->
                                <div class="icon-box-style">
                                    <div class="inner-box ">
                                        <i class="icon flaticon-business-011-dollar"></i>
                                        <h4 class="title"><a href="page-service-details.php">Best Business Solution</a></h4>
                                        <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                                    </div>
                                </div>

                                <!-- Feature Block Nine -->
                                <div class="icon-box-style">
                                    <div class="inner-box ">
                                        <i class="icon flaticon-business-012-startup"></i>
                                        <h4 class="title"><a href="page-service-details.php">Highest Customer Value</a></h4>
                                        <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="image-column col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-column">
                                <div class="info-box">
                                    <h3 class="title">We have over 24 years of experience</h3>
                                    <a href="#" class="read-more">Read More ></a>
                                </div>

                                <div class="image-box">
                                    <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                                    <i class="icon flaticon-business-060-graph"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Tab-->
                <div class="tab" id="tab3">
                    <div class="tab-our-history">
                        <div class="row">
                            <div class="image-column col-lg-6 col-md-6 col-sm-12">
                                <div class="inner-column">
                                    <div class="image-box">
                                        <figure class="image overlay-anim"><img src="images/resource/about9-1.png" alt=""></figure>
                                        <i class="icon flaticon-business-060-graph"></i>
                                    </div>

                                    <div class="info-box">
                                        <h3 class="title">We have over 24 years of experience</h3>
                                        <a href="#" class="read-more">Read More ></a>
                                    </div>
                                </div>
                            </div>

                            <div class="blocks-column col-lg-6 col-md-6 col-sm-12">
                                <div class="inner-column">
                                    <!-- Feature Block Nine -->
                                    <div class="icon-box-style">
                                        <div class="inner-box ">
                                            <i class="icon flaticon-business-011-dollar"></i>
                                            <h4 class="title"><a href="page-service-details.php">Best Business Solution</a></h4>
                                            <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                                        </div>
                                    </div>

                                    <!-- Feature Block Nine -->
                                    <div class="icon-box-style">
                                        <div class="inner-box ">
                                            <i class="icon flaticon-business-012-startup"></i>
                                            <h4 class="title"><a href="page-service-details.php">Highest Customer Value</a></h4>
                                            <div class="text">Lorem ipsum dolor sit  consectetur adipiscing elit ullamcorper.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="news" class="news-section-three pt-0">
  <div class="auto-container">
    <div class="sec-title text-center">
      <span class="sub-title">From the Blog</span>
      <h2>Checkout latest news <br> updates & articles</h2>
    </div>

    <div class="row">
      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section id="contact" class="faqs-section pb-120">
    <div class="auto-container">
        <div class="row">
            <!-- FAQ Column -->
            <div class="faq-column col-lg-6 col-md-12 col-sm-12 order-4">
                <div class="faq-bg" style="background-image: url(./images/icons/pattern-2.jpg)"></div>
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Questions & answers</span>
                        <h2>See Frequently Asked Questions</h2>
                    </div>

                    <ul class="accordion-box wow fadeInRight">
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">Is my technology allowed on tech?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo
                                        injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active">How to soft launch your business?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content current">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How to turn visitors into contributors
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How can i find my solutions?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Form Column -->
            <div class="form-column col-lg-6 col-md-12 col-sm-12">
                <div class="form-bg" style="background-image: url(./images/background/6.jpg)"></div>
                <div class="inner-column">
                    <!-- Contact Form -->
                    <div class="contact-form wow fadeInLeft">
                        <div class="title-box">
                            <span class="sub-title">Contact us</span>
                            <h3>Write Email</h3>
                        </div>

                        <!--Contact Form-->
                        <form id="contact_form" name="contact_form" action="includes/sendmail.php" method="post">
                            <div class="form-group">
                                <input type="text" name="form_name" placeholder="Your Name" required>
                            </div>

                            <div class="form-group">
                                <input type="text" name="Email" placeholder="Email Address" required>
                            </div>

                            <div class="form-group">
                                <input type="text" name="Phone" placeholder="Phone Number" required>
                            </div>

                            <div class="form-group">
                                <textarea name="message" placeholder="Write a Message" required></textarea>
                            </div>

                            <div class="form-group">
                                <button class="theme-btn btn-style-one" type="submit" name="submit-form" data-loading-text="Please wait..."><span class="btn-title">Send a message</span></button>
                            </div>
                        </form>
                    </div>
                    <!--End Contact Form -->

                </div>
            </div>
        </div>
    </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>