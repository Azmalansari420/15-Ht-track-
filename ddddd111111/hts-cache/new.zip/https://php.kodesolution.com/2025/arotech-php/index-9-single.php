<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 09 Single</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"><!-- REVOLUTION SETTINGS STYLES -->
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION NAVIGATION STYLES -->

<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">
<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-two style-two">
    <!-- Header Top -->
    <div class="header-top">
        <div class="inner-container">

            <div class="top-left">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fas fa-map-marker-alt"></i> 	121 King Street, Melbourne</li>
                </ul>
                <div class="outer-box">
                    <ul class="social-icon-one">
                        <li><a href="#"><span class="fab fa-x-twitter"></span></a></li>
                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                    </ul>
                </div>
            </div>

            <div class="top-right">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">	help@company.com</a></li>
                    <li><i class="fas fa-clock"></i> Mon - Sat 8:00 - 6:30, Sunday - CLOSED</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Header Top -->

    <!-- Header Lower -->
    <div class="header-lower">
        <!-- Main box -->
        <div class="main-box">
            <div class="logo-box">
                <div class="logo">
                                <a href="index.php" title=""><img src="images/logo-3.png" alt="" title="arotech"></a>
                </div>
            </div>

            <!--Nav Box-->
            <div class="nav-outer">

                <nav class="nav main-menu">
                                        <ul class="navigation">
    <li class="current"><a href="#home">Home</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#project">Project</a></li>
    <li><a href="#testimonial">Testimonial</a></li>
    <li><a href="#news">News</a></li>
    <li><a href="#contact">Contact</a></li>
</ul>                </nav>
                <!-- Main Menu End-->


                <div class="outer-box">
                    <div class="ui-btn-outer">
                        <button class="ui-btn ui-btn search-btn">
                            <span class="icon lnr lnr-icon-search"></span>
                        </button>
                    </div>


                    <a href="tel:+92(8800)9806" class="info-btn-two">
                        <i class="icon fa fa-phone"></i>
                        <small>Call Anytime</small><br> +88 017 500 500 88
                    </a>

                    <!-- Mobile Nav toggler -->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>

        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
            <div class="upper-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="close-btn"><i class="icon fa fa-times"></i></div>
            </div>

            <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
            </ul>
            <ul class="contact-list-one">
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <i class="icon lnr-icon-phone-handset"></i>
                        <span class="title">Call Now</span>
                        <a href="tel:+92880098670">+92 (8800) - 98670</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-envelope1"></span>
                        <span class="title">Send Email</span>
                        <a href="mailto:help@company.com">help@company.com</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-clock"></span>
                        <span class="title">Send Email</span>
                        Mon - Sat 8:00 - 6:30, Sunday - CLOSED
                    </div>
                </li>
            </ul>


            <ul class="social-links">
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->

    <!-- Header Search -->
    <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
            <form method="post" action="index.php">
                <div class="form-group">
                    <input type="search" name="search-field" value="" placeholder="Search..." required="">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
    <!-- End Header Search -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="inner-container">
                <!--Logo-->
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="nav-outer">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->

                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div><!-- End Sticky Menu -->
</header><section class="main-slider-two">
    <div class="anim-icons animate-1">
        <img class="shape-image2" src="images/main-slider/home9-shape1.png" alt="">
    </div>
    <div class="rev_slider_wrapper fullwidthbanner-container" id="rev_slider_two_wrapper" data-source="gallery">
        <div class="rev_slider fullwidthabanner" id="rev_slider_two" data-version="5.4.1">
            <ul>
                <!-- Slide 1 -->
                <li data-index="rs-1" data-transition="zoomout">
                    <!-- MAIN IMAGE -->
                    <img src="images/main-slider/slider2.png" alt="" class="rev-slidebg">

                    <div class="tp-caption" 
                    data-paddingbottom="[15,15,15,15]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['900','900','750','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['-35','20','20','0']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <h1>Digital <span class="selected">agency</span> <br>for your business</h1>
                    </div>

                    <div class="tp-caption" data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['700','750','700','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['140','180','180','120']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <a href="#" class="theme-btn btn-style-one hover-light"><span class="btn-title">Discover More</span></a>
                    </div>
                </li>
                <!-- Slide 2 -->
                <li data-index="rs-2" data-transition="zoomout">
                    <!-- MAIN IMAGE -->
                    <img src="images/main-slider/slider2.png" alt="" class="rev-slidebg">

                    <div class="tp-caption" 
                    data-paddingbottom="[15,15,15,15]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['900','900','750','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['-35','20','20','0']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <h1>Digital <span class="selected">agency</span> <br>for your business</h1>
                    </div>

                    <div class="tp-caption" data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['700','750','700','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['140','180','180','120']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <a href="#" class="theme-btn btn-style-one hover-light"><span class="btn-title">Discover More</span></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section><section id="about" class="about-section-three pb-60">
  <div class="auto-container">
    <div class="row">
      <div class="content-column col-lg-6 col-md-12 col-sm-12 wow fadeInRight" data-wow-delay="600ms">
        <div class="inner-column">
          <div class="sec-title">
            <span class="sub-title">Welcome to tech</span>
            <h2>Best IT Technology Services you can Trust</h2>
            <h5>The professional approach to technology.</h5>
            <div class="text">System is a term used to refer to an organized collection symbols and processes that may be used to operate on such symbols. Perspiciatis unde omnis natus error voluptatems accusa.</div>
          </div>

          <div class="content-box">
            <div class="row">
              <div class="about-block-three col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon fa fa-arrow-alt-circle-right"></i> Cloud Based </h5>
                <p class="text">Lorem ipsum dolor sit amet not is consectetur notted</p>
              </div>

              <div class="about-block-three col-lg-6 col-md-6 col-sm-12">
                <h5 class="title"><i class="icon fa fa-arrow-alt-circle-right"></i> Full Backup </h5>
                <p class="text">Lorem ipsum dolor sit amet not is consectetur notted.</p>
              </div>
            </div>

            <!--Skills-->
            <div class="skills">
              <!--Skill Item-->
              <div class="skill-item">
                <div class="skill-header">
                  <h5 class="skill-title">Technology</h5>
                </div>
                <div class="skill-bar">
                  <div class="bar-inner">
                    <div class="bar progress-line" data-width="77">
                      <div class="skill-percentage">
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="77">0</span>%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="btn-box">
              <a href="page-about.php" class="theme-btn btn-style-four"><span class="btn-title">Discover more</span></a>
            </div>
          </div>
        </div>
      </div>

      <!-- Image Column -->
      <div class="image-column col-lg-6 col-md-12 col-sm-12">
        <div class="inner-column wow fadeInLeft">
          <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about-16-1.jpg" alt=""></figure>
          <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about-16-2.jpg" alt=""></figure>
        </div>
      </div>
    </div>
  </div>
</section><section id="services" class="services-section-nine style-two">
    <div class="bg-img-pos bg-image" style="background-image: url(images/icons/pattern-37.png);"></div>
    <div class="auto-container pb-10">
        <div class="sec-title light text-center">
            <span class="sub-title">OUR SERVICES</span>
            <h2>Explore What Services <br>We’re Offering</h2>
        </div>
        <div class="row">
            <!-- Service Block Two -->
            <div class="service-block-nine col-lg-4 col-md-6 coll-md-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><img src="images/resource/service9-1.jpg" alt=""></figure>
                    </div>
                    <div class="title-box">
                        <h4 class="title"><a href="page-service-details.php">Website <br>Development</a></h4>
                    </div>
                    <div class="content-box">
                        <i class="icon flaticon-business-049-presentation"></i>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                    </div>
                </div>
            </div>

            <!-- Service Block Two -->
            <div class="service-block-nine col-lg-4 col-md-6 coll-md-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><img src="images/resource/service9-2.jpg" alt=""></figure>
                    </div>
                    <div class="title-box">
                        <h4 class="title"><a href="page-service-details.php">Graphic <br>designing</a></h4>
                    </div>
                    <div class="content-box">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                    </div>
                </div>
            </div>

            <!-- Service Block Two -->
            <div class="service-block-nine col-lg-4 col-md-6 coll-md-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><img src="images/resource/service9-3.jpg" alt=""></figure>
                    </div>
                    <div class="title-box">
                        <h4 class="title"><a href="page-service-details.php">Digital <br>marketing</a></h4>
                    </div>
                    <div class="content-box">
                        <i class="icon flaticon-business-011-dollar"></i>
                        <div class="text">Duis aute irure dolor in voluptate.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="why-choose-us-four">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-7 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Company Benefits</span>
                        <h2>Why Should You Choose Our Agency?</h2>
                        <h3>Proin are many variations passages of available.</h3>
                        <div class="text">There are many variations of passages of available but the majority have suffered. Alteration in some form, lipsum is simply free text by injected humou or randomised words. variations of passages of available</div>
                    </div>

                    <blockquote class="blockquote-style-one">Lorem ipsum dolor sit amet, consectetur notted dipisicing elit sed do eiusmod consectetur notted dipisicing elit</blockquote>

                    <div class="btn-box">
                        <a href="page-about" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Explore Now</span></a>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-5 col-lg-5 col-md-12 col-sm-12">
                <div class="inner-column wow fadeInLeft">
                    <div class="image-box">
                        <span class="bg-shape"></span>
                        <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/why-us4-1.png" alt=""></figure>
                        <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-2.png" alt=""></figure>
                        <figure class="image-3 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-3.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="project" class="projects-section-four style-two pb-0">
  <div class="outer-box">
    <div class="sec-title light text-center">
      <span class="sub-title">Recent Portfolio</span>
      <h2>Checkout our Recently <br>Completed Projects</h2>
    </div>
    <div class="row">
      <!-- Project Block -->
      <div class="project-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="images/resource/project5-1.jpg" class="lightbox-image"><img src="images/resource/project5-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="cat">Security</span>
            <h4 class="title"><a href="page-projects.php">Social Marketing</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class="project-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="images/resource/project5-2.jpg" class="lightbox-image"><img src="images/resource/project5-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-projects.php">Web design</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class="project-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="images/resource/project5-3.jpg" class="lightbox-image"><img src="images/resource/project5-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="cat">Technology</span>
            <h4 class="title"><a href="page-projects.php">Smart Visions</a></h4>
          </div>
        </div>
      </div>
      <!-- Project Block -->
      <div class="project-block-five col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="images/resource/project5-4.jpg" class="lightbox-image"><img src="images/resource/project5-4.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="cat">Development</span>
            <h4 class="title"><a href="page-projects.php">App Integration</a></h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="pricing-section-four">
    <div class="anim-icons animate-1">
            <img class="shape-image1" src="images/icons/shape-20.png" alt="">
            <img class="shape-image2" src="images/icons/shape-21.png" alt="">
        </div>
    <div class="auto-container">
        <div class="sec-title text-center"> <span class="sub-title style-three">Our Pricing Plans</span>
        <h2 class="scrub-each-word text-split">Choose Your Optimal <br>Pricing Plans</h2>
        </div>
        <div class="row">
        <!-- Pricing Block -->
        <div class="pricing-block-four col-xl-4 col-md-6">
            <div class="inner-box">
            <div class="icon-arrow2"></div>
            <div class="offer">Save <span>23%</span></div>
            <i class="icon-two flaticon-business-011-dollar"></i>
            <h4 class="title">Regular Plan</h4>
            <h2 class="price">$39<sub>/ for per month</sub></h2>
            <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Network Security Audit</li>
                <li><i class="fa-solid fa-circle-check"></i> Support Management</li>
                <li><i class="fa-solid fa-circle-check"></i> Cyber Security </li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
            </ul>
            <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
        </div>
        <!-- Pricing Block -->
        <div class="pricing-block-four col-xl-4 col-md-6">
            <div class="inner-box">
            <div class="icon-arrow2"></div>
            <div class="offer">Save <span>23%</span></div>
            <i class="icon-two flaticon-business-011-dollar"></i>
            <h4 class="title">Standard Plan</h4>
            <h2 class="price">$99<sub>/ for per month</sub></h2>
            <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Data Backup And Recovery</li>
                <li><i class="fa-solid fa-circle-check"></i> Network Security Audit</li>
                <li><i class="fa-solid fa-circle-check"></i> Cybersecurity Training</li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
            </ul>
            <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
        </div>
        <!-- Pricing Block -->
        <div class="pricing-block-four col-xl-4 col-md-6">
            <div class="inner-box">
            <div class="icon-arrow2"></div>
            <div class="offer">Save <span>23%</span></div>
            <i class="icon-two flaticon-business-011-dollar"></i>
            <h4 class="title">Ultimate Plan</h4>
            <h2 class="price">$199<sub>/ for per month</sub></h2>
            <ul class="features-list">
                <li><i class="fa-solid fa-circle-check"></i> Migration Consultation</li>
                <li><i class="fa-solid fa-circle-check"></i> Network Security Audit</li>
                <li><i class="fa-solid fa-circle-check"></i> Cyber Security</li>
                <li><i class="fa-solid fa-circle-check"></i> 24/7 Remote Support</li>
            </ul>
            <a href="page-pricing.php" class="theme-btn btn-style-one"><span class="btn-title">Choose Package</span></a>
            </div>
        </div>
        </div>
    </div>
</section><section class="features-section-style-two">
    <div class="auto-container">
        <div class="row">
            <!-- Title Column -->
            <div class="title-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="sec-title light">
                        <span class="sub-title">Our Service</span>
                        <h2>We’re Dedicated to Serve you All Time</h2>
                        <div class="text">Web designing in a powerful way of just not an only professions, however, in a passion for our Company. We have to a tendency to believe the idea that smart looking of any website is the first impression on visitors.</div>
                    </div>
                </div>
            </div>

            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                <div class="image-box wow fadeIn">
                    <figure class="image"><img src="images/resource/image-11.jpg" alt=""></figure>
                </div>
            </div>
        </div>

        <div class="row justify-content-center">
            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <i class="icon flaticon-business-011-dollar"></i>
                    <h6 class="title"><a href="page-service-details.php">Banking</a></h6>
                </div>
            </div>

            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="200ms">
                <div class="inner-box ">
                    <i class="icon flaticon-business-049-presentation"></i>
                    <h6 class="title"><a href="page-service-details.php">Healthcare</a></h6>
                </div>
            </div>

            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="400ms">
                <div class="inner-box ">
                    <i class="icon flaticon-business-061-meeting"></i>
                    <h6 class="title"><a href="page-service-details.php">Education</a></h6>
                </div>
            </div>

            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box ">
                    <i class="icon flaticon-business-030-settings"></i>
                    <h6 class="title"><a href="page-service-details.php">Manufacturing</a></h6>
                </div>
            </div>

            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="800ms">
                <div class="inner-box ">
                    <i class="icon flaticon-business-054-graph"></i>
                    <h6 class="title"><a href="page-service-details.php">Capital Markets</a></h6>
                </div>
            </div>

            <!-- Feature Block Two -->
            <div class="feature-block-two dark col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="1000ms">
                <div class="inner-box ">
                    <i class="icon flaticon-business-020-hierarchy"></i>
                    <h6 class="title"><a href="page-service-details.php">Networking</a></h6>
                </div>
            </div>

        </div>
    </div>
</section><section class="faqs-section style-two">
    <div class="auto-container">
        <div class="row">
            <!-- FAQ Column -->
            <div class="faq-column col-xl-6 col-lg-12 col-md-12 order-4">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Questions & answers</span>
                        <h2>See Frequently Asked Questions</h2>
                    </div>

                    <ul class="accordion-box wow fadeInRight">
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">Is my technology allowed on tech?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered
                                        alteration in some fo
                                        injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active">How to soft launch your business?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content current">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered
                                        alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How to turn visitors into contributors
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered
                                        alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How can i find my solutions?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered
                                        alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- image Column -->
            <div class="image-column col-xl-6 col-lg-12 col-md-12">
                <div class="inner-column">
                    <figure class="image"><img src="images/resource/image-12.jpg" alt=""></figure>
                    <div class="info-box">
                        <div class="inner">
                            <span class="icon flaticon-business-020-hierarchy"></span>
                            <h3 class="title">Trusted IT Solution & Service <br>Business Agency</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="contact" class="contact-section-five">
    <div class="bg-img-pos bg-image" style="background-image: url(images/icons/pattern-31.jpg);"></div>
    <div class="bg-image"><img src="images/resource/girl.png" alt=""></div>
    <div class="auto-container">
        <div class="row">
            <!-- Title Column -->
            <div class="title-column col-lg-6">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">contact with us</span>
                        <h2>let’s work together?</h2>
                        <div class="text">Sed ut perspiciatis unde omnis natus error sit voluptatem accusa ntium doloremque laudantium totam rem.</div>
                    </div>

                    <!-- Contact block -->
                    <div class="contact-info-block">
                        <div class="inner">
                            <i class="icon fa fa-phone"></i>
                            <h6 class="title">Have any question?</h6>
                            <div class="text">Free <a href="tel:230009850">+23 (000)-9850</a></div>
                        </div>
                    </div>


                    <!-- Contact Info block -->
                    <div class="contact-info-block">
                        <div class="inner">
                            <i class="icon fa fa-envelope"></i>
                            <h6 class="title">Send email</h6>
                            <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
                        </div>
                    </div>

                    <!-- Contact Info block -->
                    <div class="contact-info-block">
                        <div class="inner">
                            <i class="icon fa fa-map-marker-alt"></i>
                            <h6 class="title">Visit anytime</h6>
                            <div class="text">30 broklyn golden street. New York</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form Column -->
            <div class="form-column col-lg-6">
                <div class="inner-column">
                    <!-- Contact Form -->
                    <div class="contact-form wow fadeInLeft">
                        <h2 class="title">Contact us</h2>

                        <!--Contact Form-->
                        <form id="contact_form" name="contact_form" action="includes/sendmail.php" method="post">
                            <div class="row">
                                <div class="form-group col-lg-12">
                                    <input type="text" name="form_name" placeholder="Your Name" required>
                                </div>

                                <div class="form-group col-lg-12">
                                    <input type="email" name="Email" placeholder="Email Address" required>
                                </div>

                                <div class="form-group col-lg-12">
                                    <textarea name="message" placeholder="Comment" required></textarea>
                                </div>

                                <div class="form-group col-lg-12">
                                    <button class="theme-btn btn-style-one hvr-dark" type="submit" name="submit-form" data-loading-text="Please wait..."><span class="btn-title">Write a Message</span></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--End Contact Form -->
                </div>
            </div>
        </div>
    </div>
</section><section id="testimonial" class="testimonial-section-four pt-100 pb-0">
    <div class="auto-container">
        <div class="row">
            <!-- Title Column -->
            <div class="title-column col-xl-5 col-lg-6 col-md-12">
                <div class="inner-column pe-lg-5">
                    <div class="sec-title">
                        <span class="sub-title">Our Testimonials</span>
                        <h2>What They’re Talking About Us</h2>
                        <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable</div>
                    </div>
                </div>
            </div>

            <!-- Testimonial Column -->
            <div class="testimonial-column col-xl-7 col-lg-6 col-md-12">
                <div class="carousel-outer">
                    <div class="testimonial-bg" style="background-image: url(images/resource/testimonial-bg.png)"></div>
                    <div class="testimonial-carousel-four owl-carousel owl-theme">

                        <!-- Testimonial Block Four -->
                        <div class="testimonial-block-four">
                            <div class="inner-box">
                                <div class="content-box">
                                    <span class="icon icon-quote"></span>
                                    <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                                    <div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
                                </div>
                                <div class="info-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                                    <h5 class="name">Jessica Brown</h5>
                                    <span class="designation">Co Founder</span>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block Four -->
                        <div class="testimonial-block-four">
                            <div class="inner-box">
                                <div class="content-box">
                                    <span class="icon icon-quote"></span>
                                    <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                                    <div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
                                </div>
                                <div class="info-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                                    <h5 class="name">Jessica Brown</h5>
                                    <span class="designation">Co Founder</span>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block Four -->
                        <div class="testimonial-block-four">
                            <div class="inner-box">
                                <div class="content-box">
                                    <span class="icon icon-quote"></span>
                                    <div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
                                    <div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
                                </div>
                                <div class="info-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                                    <h5 class="name">Jessica Brown</h5>
                                    <span class="designation">Co Founder</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="news" class="news-section-three pt-100">
  <div class="auto-container">
    <div class="sec-title text-center">
      <span class="sub-title">From the Blog</span>
      <h2>News & Articles</h2>
    </div>

    <div class="row">
      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news3-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
            <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>