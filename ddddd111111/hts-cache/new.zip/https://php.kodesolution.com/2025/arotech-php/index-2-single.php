<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 02 Single</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"><!-- REVOLUTION SETTINGS STYLES -->
<link href="plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"><!-- REVOLUTION LAYERS STYLES -->
<link href="plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"><!-- REVOLUTION NAVIGATION STYLES -->

<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">

<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-six">
  <!-- Header Top -->
  <div class="header-top">
    <div class="inner-container">
  
      <div class="top-left">
        <!-- Info List -->
        <ul class="list-style-one">
          <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">needhelp@company.com</a></li>
          <li><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li>
        </ul>
      </div>
  
      <div class="top-right">
        <ul class="useful-links">
          <li><a href="#">Help</a></li>
          <li><a href="#">Support</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
        <ul class="social-icon-one">
          <li><a href="#"><span class="fa fa-x"></span></a></li>
          <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
          <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
          <li><a href="#"><span class="fab fa-instagram"></span></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Header Top -->
  
  <div class="header-lower">
    <!-- Main box -->
    <div class="main-box">
      <div class="logo-box">
        <div class="logo">
                      <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
        </div>
      </div>


      <!--Nav Box-->
      <div class="nav-outer">    
        <nav class="nav main-menu">
                      <ul class="navigation">
    <li class="current"><a href="#home">Home</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#project">Project</a></li>
    <li><a href="#testimonial">Testimonial</a></li>
    <li><a href="#news">News</a></li>
    <li><a href="#contact">Contact</a></li>
</ul>        </nav>
        <!-- Main Menu End-->
      </div>

      <div class="outer-box">
        <!-- Header Search -->
        <button class="ui-btn ui-btn search-btn">
          <span class="icon lnr lnr-icon-search"></span>
        </button>

        <a href="tel:+92(8800)9806" class="info-btn">
          <i class="icon fa fa-phone"></i>
          <small>Call Anytime</small><br> + 88 ( 9800 ) 6802
        </a>
        <!-- Mobile Nav toggler -->
        <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
      </div>
    </div>
  </div>

  <!-- Mobile Menu  -->
  <div class="mobile-menu">
    <div class="menu-backdrop"></div>
  
    <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
    <nav class="menu-box">
      <div class="upper-box">
        <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
        <div class="close-btn"><i class="icon fa fa-times"></i></div>
      </div>
  
      <ul class="navigation clearfix">
        <!--Keep This Empty / Menu will come through Javascript-->
      </ul>
      <ul class="contact-list-one">
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <i class="icon lnr-icon-phone-handset"></i>
            <span class="title">Call Now</span>
            <a href="tel:+92880098670">+92 (8800) - 98670</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-envelope1"></span>
            <span class="title">Send Email</span>
            <a href="mailto:help@company.com">help@company.com</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-clock"></span>
            <span class="title">Send Email</span>
            Mon - Sat 8:00 - 6:30, Sunday - CLOSED
          </div>
        </li>
      </ul>
  
  
      <ul class="social-links">
        <li><a href="#"><i class="fa fa-x"></i></a></li>
        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      </ul>
    </nav>
  </div><!-- End Mobile Menu -->

  <!-- Header Search -->
  <div class="search-popup">
    <span class="search-back-drop"></span>
    <button class="close-search"><span class="fa fa-times"></span></button>
  
    <div class="search-inner">
      <form method="post" action="index.php">
        <div class="form-group">
          <input type="search" name="search-field" value="" placeholder="Search..." required="">
          <button type="submit"><i class="fa fa-search"></i></button>
        </div>
      </form>
    </div>
  </div>
  <!-- End Header Search -->

  <!-- Sticky Header  -->
  <div class="sticky-header">
    <div class="auto-container">
      <div class="inner-container">
        <!--Logo-->
        <div class="logo">
                    <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
        </div>
  
        <!--Right Col-->
        <div class="nav-outer">
          <!-- Main Menu -->
          <nav class="main-menu">
            <div class="navbar-collapse show collapse clearfix">
              <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
              </ul>
            </div>
          </nav><!-- Main Menu End-->
  
          <!--Mobile Navigation Toggler-->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div><!-- End Sticky Menu -->
</header><section class="main-slider-two">
    <div class="anim-icons animate-1">
        <img class="shape-image1" src="images/main-slider/home2-shape1.png" alt="">
    </div>
    <div class="rev_slider_wrapper fullwidthbanner-container" id="rev_slider_two_wrapper" data-source="gallery">
        <div class="rev_slider fullwidthabanner" id="rev_slider_two" data-version="5.4.1">
            <ul>
                <!-- Slide 1 -->
                <li data-index="rs-1" data-transition="zoomout">
                    <!-- MAIN IMAGE -->
                    <img src="images/main-slider/slider2.png" alt="" class="rev-slidebg">

                    <div class="tp-caption" 
                    data-paddingbottom="[15,15,15,15]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['900','900','750','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['5','20','20','0']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <h1>Digital <span class="selected">agency</span> <br>for your business</h1>
                    </div>

                    <div class="tp-caption" data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['700','750','700','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['180','180','180','120']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <a href="#" class="theme-btn btn-style-one hover-light"><span class="btn-title">Discover More</span></a>
                    </div>
                </li>
                <!-- Slide 2 -->
                <li data-index="rs-2" data-transition="zoomout">
                    <!-- MAIN IMAGE -->
                    <img src="images/main-slider/slider2.png" alt="" class="rev-slidebg">

                    <div class="tp-caption" 
                    data-paddingbottom="[15,15,15,15]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['900','900','750','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['5','20','20','0']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <h1>Digital <span class="selected">agency</span> <br>for your business</h1>
                    </div>

                    <div class="tp-caption" data-paddingbottom="[0,0,0,0]"
                    data-paddingleft="[15,15,15,15]"
                    data-paddingright="[15,15,15,15]"
                    data-paddingtop="[0,0,0,0]"
                    data-responsive_offset="on"
                    data-type="text" data-height="none"
                    data-width="['700','750','700','450']"
                    data-whitespace="normal"
                    data-hoffset="['0','0','0','0']"
                    data-voffset="['180','180','180','120']"
                    data-x="['center','center','center','center']"
                    data-y="['middle','middle','middle','middle']"
                    data-textalign="['top','top','top','top']"
                    data-frames='[{"delay":1000,"speed":1500,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'>
                        <a href="#" class="theme-btn btn-style-one hover-light"><span class="btn-title">Discover More</span></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section><section id="services" class="services-section-six style-two pb-0">
    <div class="auto-container">
        <div class="sec-title light">
            <div class="row">
                <div class="col-lg-7">
                    <span class="sub-title">Our Service</span>
                    <h2>Explore what services <br>we’re offering</h2>
                </div>
                <div class="col-lg-5">
                    <div class="text">There are many variations of passages of available but majority alteration in some form, by humou or randomised words.</div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">UI / UX Creative <br>Design</a></h4>
                    <i class="icon flaticon-Set flaticon-business-002-color-sample"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Website Graphics <br>Design</a></h4>
                    <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Streagy & Digital <br>Marketing</a></h4>
                    <i class="icon flaticon-Set flaticon-business-007-settings"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Effective Business <br>Growth</a></h4>
                    <i class="icon flaticon-Set flaticon-business-3956725"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Data Security <br>Management</a></h4>
                    <i class="icon flaticon-Set flaticon-business-013-campaign"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section><section id="about" class="about-section-seven">
    <div class="auto-container">
        <div class="row">
            <!-- Content Column -->
            <div class="content-column col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">GET TO KNOW US</span>
                        <h2>The world best digital solutions we provide to you</h2>
                        <div class="text">There are many variations of passages of available but the majority have suffered alteration in some form, by injected hum randomised words which don't slightly. but the majority have suffered alteration in some form.</div>
                    </div>

                    <!-- Info Box -->
                    <div class="info-box">
                        <div class="inner">
                            <i class="icon flaticon-Set flaticon-business-3956725"></i>
                            <h4 class="title">Leading in marketing</h4>
                            <div class="text">Knowledge of technologies rules better than anyone which we apply in our daily office working schedule</div>
                        </div>
                    </div>

                    <!-- Info Box -->
                    <div class="info-box">
                        <div class="inner">
                            <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                            <h4 class="title">Expert developers</h4>
                            <div class="text">Knowledge of technologies rules better than anyone which we apply in our daily office working schedule</div>
                        </div>
                    </div>
                    
                    <div class="other-info">
                        <div class="author-info">
                            <div class="inner">
                                <figure class="thumb"><img src="images/resource/avatar.jpg" alt=""></figure>
                                <h5 class="name">Aleesha brown</h5>
                                <span class="designation">CEO & CO Founder</span>
                            </div>
                        </div>
                        <div class="btn-box">
                            <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title">Discover more</span></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-lg-5 col-md-12 col-sm-12 wow fadeInLeft">
                <div class="image-box">
                    <span class="icon-dots2"></span>
                    <span class="icon-circle zoom-one"></span>
                    <figure class="image-1 wow fadeIn"><img src="images/resource/about-14.png" alt=""></figure>
                    <figure class="image-2 wow fadeIn" data-wow-delay="600ms"><img src="images/resource/about-15.png" alt=""></figure>
                    <div class="exp-box">
                        <div class="inner">
                            <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                            <span class="count">38+</span>
                            <div class="text">Work Experience</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="project" class="projects-section-four pt-20">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">our portfolio</span>
            <h2>Explore our new recently <br>completed projects.</h2>
        </div>
    </div>

    <div class="outer-box">
        <div class="row">
            <!-- Project Block -->
            <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-1.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        <span class="cat">Development</span>
                        <h4 class="title"><a href="page-project-details.php" title="">Product & Design</a></h4>
                    </div>
                </div>
            </div>
            <!-- Project Block -->
            <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-2.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        <span class="cat">Development</span>
                        <h4 class="title"><a href="page-project-details.php" title="">Marketing webdesign</a></h4>
                    </div>
                </div>
            </div>
            <!-- Project Block -->
            <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-3.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        <span class="cat">Development</span>
                        <h4 class="title"><a href="page-project-details.php" title="">Product & Design</a></h4>
                    </div>
                </div>
            </div>
            <!-- Project Block -->
            <div class=" project-block-four col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="page-project-details.php"><img src="images/resource/project3-4.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        <span class="cat">Development</span>
                        <h4 class="title"><a href="page-project-details.php" title="">Marketing webdesign</a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="video-section-two">
    <div class="auto-container">
        <div class="video-box">
            <div class="bg bg-image" style="background-image: url(./images/background/video-bg1.jpg)"></div>
            <div class="content">
                <div class="btn-box">
                    <a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i><span class="ripple"></span></a>
                </div>
            </div>
        </div>
    </div>
</section><section class="fun-fact-section-three">
    <div class="auto-container">
        <div class="outer-box">
            <div class="row">
                <div class="title-column col-lg-5 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title light">
                            <span class="sub-title">FUNFACTS</span>
                            <h2>We’re experts in the business</h2>
                            <div class="text">There are many variations of passages of available but majority <br>alteration in some form, by humou or randomised words</div>
                        </div>
                    </div>
                </div>

                <div class="column col-lg-7 col-md-12 col-sm-12">
                    <div class="fact-counter">
                        <div class="row">
                            <!-- Counter block-->
                            <div class="counter-block-four col-lg-4 col-md-4 col-sm-12 wow fadeInUp">
                                <div class="inner">
                                    <div class="content">
                                        <i class="icon flaticon-Set flaticon-business-3956725"></i>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="6420">0</span></div>
                                        <h6 class="counter-title">Projects Completed</h6>
                                    </div>
                                </div>
                            </div>

                            <!--Counter block-->
                            <div class="counter-block-four col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                                <div class="inner">
                                    <div class="content">
                                        <i class="icon flaticon-Set flaticon-business-002-color-sample"></i>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="9280">0</span></div>
                                        <h6 class="counter-title">Satisfied Clients</h6>
                                    </div>
                                </div>
                            </div>

                            <!--Counter block-->
                            <div class="counter-block-four col-lg-4 col-md-4 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                                <div class="inner">
                                    <div class="content">
                                        <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="380">0</span></div>
                                        <h6 class="counter-title">Expert Teams</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="why-choose-us-five">
    <div class="anim-icons">
        <span class="icon icon-arrow1"></span>
    </div>

    <div class="auto-container">
        <div class="row">
            <!-- Content Column -->
            <div class="content-column col-lg-6 col-md-12">
                <div class="inner-column wow fadeInRight">
                    <div class="sec-title">
                        <i class="sub-title">Why choose us</i>
                        <h2>Building a design easy for business</h2>
                    </div>
                    <div class="row">
                        <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                                    <h5 class="title">Web <br>growths</h5>
                                </div>
                                <div class="text">Good knowledge becuase you done something many times.</div>
                            </div>
                        </div>
                        <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-Set flaticon-business-3956725"></i>
                                    <h5 class="title">Digital <br>solutions</h5>
                                </div>
                                <div class="text">Good knowledge becuase you done something many times.</div>
                            </div>
                        </div>
                        <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-Set flaticon-business-007-settings"></i>
                                    <h5 class="title">Best <br>consultancy</h5>
                                </div>
                                <div class="text">Good knowledge becuase you done something many times.</div>
                            </div>
                        </div>
                        <div class="info-box col-lg-6 col-md-6">
                            <div class="inner">
                                <div class="title-box">
                                    <i class="icon flaticon-Set flaticon-business-013-campaign"></i>
                                    <h5 class="title">Expert <br>developers</h5>
                                </div>
                                <div class="text">Good knowledge becuase you done something many times.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-lg-6 col-md-12">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image anim-overlay"><img src="images/resource/why-us-6.jpg" alt=""></figure>
                        <div class="content-box">
                            <div class="text">We’re bringing latest business innovation in to the digital world</div>
                            <div class="caption">Top quality marketing solutions</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="team-section-three">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">OUR TEAM MEMBERS</span>
            <h2>MEET THE EXPERTS</h2>
        </div>

        <div class="row">
            <!-- Team Block -->
            <div class="col-lg-3 col-sm-6 wow fadeInUp">
                <div class="team-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-1.jpg" alt=""></a></figure>
                            <div class="social-links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                            <span class="share-icon fa fa-share-alt"></span>
                        </div>
                        <div class="info-box">
                            <span class="designation">IT Director</span>
                            <h4 class="name"><a href="page-team-details.php">Robert jonson</a></h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Block -->
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
                <div class="team-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-2.jpg" alt=""></a></figure>
                            <div class="social-links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                            <span class="share-icon fa fa-share-alt"></span>
                        </div>
                        <div class="info-box">
                            <span class="designation">HR Admin</span>
                            <h4 class="name"><a href="page-team-details.php">Sarah Albert </a></h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Block -->
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
                <div class="team-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-3.jpg" alt=""></a></figure>
                            <div class="social-links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                            <span class="share-icon fa fa-share-alt"></span>
                        </div>
                        <div class="info-box">
                            <span class="designation">Manager</span>
                            <h4 class="name"><a href="page-team-details.php">David Cooper </a></h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Block -->
            <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
                <div class="team-block-three">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="page-team-details.php"><img src="images/resource/team2-4.jpg" alt=""></a></figure>
                            <div class="social-links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                            <span class="share-icon fa fa-share-alt"></span>
                        </div>
                        <div class="info-box">
                            <span class="designation">Manager</span>
                            <h4 class="name"><a href="page-team-details.php">Recherd william </a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="testimonial" class="testimonial-section-five">
    <div class="bg-shape2" style="background-image: url(images/icons/pattern-25.png);"></div>
    <div class="auto-container">
        <div class="row">
            <!-- Title Column -->
            <div class="title-column col-xl-4 col-lg-4 col-md-12">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">testimonials</span>
                        <h2>What they’re talking about</h2>
                        <div class="text">Lorem ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean solldin, lorem is simply free text quis bibendum.</div>
                    </div>
                </div>
            </div>

            <!-- Testimonial Column -->
            <div class="testimonial-column col-xl-8 col-lg-8 col-md-12">
                <div class="inner-column">
                    <div class="testimonial-carousel-six owl-carousel default-navs">
                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-2.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Sarah albert</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Mike hardson</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-4.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Aleesha brown</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-1.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Sarah albert</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Mike hardson</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Testimonial Block -->
                        <div class="testimonial-block-five">
                            <div class="inner-box">
                                <div class="content-box">
                                    <figure class="thumb"><img src="images/resource/testi-thumb-4.jpg" alt=""></figure>
                                    <div class="rating">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                    <div class="text">Lorem ipsum is simply free text dolor not sit amet, notted adipisicing elit sed do eiusmod incididunt labore et dolore text.</div>
                                    <div class="info-box">
                                        <h4 class="name">Aleesha brown</h4>
                                        <span class="designation">Designer</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="news" class="news-section-three">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">From the Blog</span>
            <h2>Checkout latest news <br> updates & articles</h2>
        </div>

        <div class="row">
            <!-- News Block -->
            <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news2-1.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <span class="date">20 April</span>
                        <ul class="post-info">
                            <li><i class="fa fa-user-circle"></i> by Admin</li>
                            <li><i class="fa fa-comments"></i> 2 Comments</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news2-2.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <span class="date">20 April</span>
                        <ul class="post-info">
                            <li><i class="fa fa-user-circle"></i> by Admin</li>
                            <li><i class="fa fa-comments"></i> 2 Comments</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news2-3.jpg" alt=""></a></figure>
                    </div>
                    <div class="content-box">
                        <span class="date">20 April</span>
                        <ul class="post-info">
                            <li><i class="fa fa-user-circle"></i> by Admin</li>
                            <li><i class="fa fa-comments"></i> 2 Comments</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="call-to-action-six pull-down">
    <div class="auto-container">
        <div class="outer-box">
            <div class="bg-shape"></div>
            <div class="row">
                <div class="title-column col-lg-6 col-md-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <h2>Passion can Make a <br>Top-Performing Company</h2>
                        </div>
                    </div>
                </div>

                <div class="btn-column col-lg-6 col-md-12">
                    <div class="inner-column">
                        <a href="page-contact.php" class="theme-btn btn-style-one bg-light"><span class="btn-title">CONTACT US</span></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="contact" class="contact-section-three pull-up-two">
    <div class="auto-container">
        <div class="row">
            <!-- Info Column -->
            <div class="info-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column me-xl-5 pe-xl-5 ps-0 wow fadeInRight">
                    <div class="sec-title light">
                        <div class="sub-title">Get in Touch</div>
                        <h2>Get a free quote today</h2>
                        <div class="text">Web designing in a powerful way of just not an only professions, however, in a passion for our company</div>
                    </div>

                    <div class="contact-info-box-two">
                        <span class="icon fa fa-map-marker-alt"></span>
                        <h6 class="title">Visit Us</h6>
                        <div class="text">66 Road Broklyn Street, 600 New York, USA</div>
                    </div>

                    <div class="contact-info-box-two">
                        <span class="icon fa fa-envelope"></span>
                        <h6 class="title">Email address</h6>
                        <div class="text"><a href="mailto:needhelp@company.com">needhelp@company.com</a></div>
                    </div>

                    <div class="contact-info-box-two">
                        <span class="icon fa fa-phone"></span>
                        <h6 class="title">Call now</h6>
                        <div class="text"><a href="tel:+999000111222">+999 000 111 222</a></div>
                    </div>
                </div>
            </div>

            <!-- Form Column -->
            <div class="form-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <!-- Contact Form -->
                    <div class="contact-form-two style-two wow fadeInLeft">
                        <!--Contact Form-->
                        <form id="contact_form" name="contact_form" class="" action="includes/sendmail.php" method="post">
                            <div class="row">
                                <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                    <input type="text" name="full_name" class="form-control" placeholder="Your Name" required>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                    <input type="email" name="Email" class="form-control" placeholder="Email Address" required>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                    <input type="text" name="Phone" class="form-control" placeholder="Phone Number" required>
                                </div>

                                <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                    <input type="text" name="subject" class="form-control" placeholder="Subject" required>
                                </div>

                                <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                    <textarea name="message" class="form-control" placeholder="Write Message" required></textarea>
                                </div>

                                <div class="form-group col-lg-12 col-md-12 col-sm-12">
                                    <button class="theme-btn btn-style-one hvr-light" type="submit" name="submit-form" data-loading-text="Please wait..."><span class="btn-title">Send a message</span></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!--End Contact Form -->

                </div>
            </div>
        </div>
    </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/main-slider-script.js"></script>
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>