<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 01 Single</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">

<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-one">
  <!-- Header Top -->
  <div class="header-top">
    <div class="inner-container">

      <div class="top-left">
        <!-- Info List -->
        <ul class="list-style-one">
          <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">needhelp@company.com</a></li>
          <li><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li>
        </ul>
      </div>

      <div class="top-right">
        <ul class="useful-links">
          <li><a href="#">Help</a></li>
          <li><a href="#">Support</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
    </div>

    <div class="outer-box">
      <ul class="social-icon-one">
        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
      </ul>
    </div>
  </div>
  <!-- Header Top -->

  <!-- Header Lower -->
  <div class="header-lower">
    <!-- Main box -->
    <div class="main-box">
      <div class="logo-box">
        <div class="logo">
                    <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
        </div>
      </div>

      <!--Nav Box-->
      <div class="nav-outer">

        <nav class="nav main-menu">
                    <ul class="navigation">
    <li class="current"><a href="#home">Home</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#project">Project</a></li>
    <li><a href="#testimonial">Testimonial</a></li>
    <li><a href="#news">News</a></li>
    <li><a href="#contact">Contact</a></li>
</ul>        </nav>
        <!-- Main Menu End-->


        <div class="outer-box">
          <div class="ui-btn-outer">
            <button class="ui-btn ui-btn search-btn">
              <span class="icon lnr lnr-icon-search"></span>
            </button>
            <a href="shop-cart.php" class="ui-btn"><i class="lnr-icon-shopping-cart"></i></a>
          </div>


          <a href="tel:+92(8800)9806" class="info-btn">
            <i class="icon fa fa-phone"></i>
            <small>Call Anytime</small><br> + 88 ( 9800 ) 6802
          </a>

          <a href="page-contact.php" class="theme-btn btn-style-one"><span class="btn-title">get solution</span></a>

          <!-- Mobile Nav toggler -->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Header Lower -->

  <!-- Mobile Menu  -->
  <div class="mobile-menu">
    <div class="menu-backdrop"></div>

    <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
    <nav class="menu-box">
      <div class="upper-box">
        <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt=""></a></div>
        <div class="close-btn"><i class="icon fa fa-times"></i></div>
      </div>

      <ul class="navigation clearfix">
        <!--Keep This Empty / Menu will come through Javascript-->
      </ul>
      <ul class="contact-list-one">
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <i class="icon lnr-icon-phone-handset"></i>
            <span class="title">Call Now</span>
            <a href="tel:+92880098670">+92 (8800) - 98670</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-envelope1"></span>
            <span class="title">Send Email</span>
            <a href="mailto:help@company.com">help@company.com</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-clock"></span>
            <span class="title">Send Email</span>
            Mon - Sat 8:00 - 6:30, Sunday - CLOSED
          </div>
        </li>
      </ul>


      <ul class="social-links">
        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      </ul>
    </nav>
  </div><!-- End Mobile Menu -->

  <!-- Header Search -->
  <div class="search-popup">
    <span class="search-back-drop"></span>
    <button class="close-search"><span class="fa fa-times"></span></button>

    <div class="search-inner">
      <form method="post" action="index.php">
        <div class="form-group">
          <input type="search" name="search-field" value="" placeholder="Search..." required="">
          <button type="submit"><i class="fa fa-search"></i></button>
        </div>
      </form>
    </div>
  </div>
  <!-- End Header Search -->

  <!-- Sticky Header  -->
  <div class="sticky-header">
    <div class="auto-container">
      <div class="inner-container">
        <!--Logo-->
        <div class="logo">
                    <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
        </div>

        <!--Right Col-->
        <div class="nav-outer">
          <!-- Main Menu -->
          <nav class="main-menu">
            <div class="navbar-collapse show collapse clearfix">
              <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
              </ul>
            </div>
          </nav><!-- Main Menu End-->

          <!--Mobile Navigation Toggler-->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div><!-- End Sticky Menu -->
</header><section class="banner-section">
  <div class="banner-carousel owl-carousel owl-theme">
    <!-- Slide Item -->
    <div class="slide-item">
      <div class="bg-image" style="background-image: url(images/main-slider/slider1.jpg);"></div>
      <div class="anim-icons animate-1">
        <img class="shape-image1" src="images/main-slider/home1-shape1.png" alt="">
        <img class="shape-image2" src="images/main-slider/home1-shape2.png" alt="">
        <img class="shape-image3" src="images/main-slider/home1-shape3.png" alt="">
        <img class="shape-image4 bounce-y" src="images/main-slider/home1-shape4.png" alt="">
        <img class="shape-image5" src="images/main-slider/home1-shape5.png" alt="">
        <img class="shape-image6" src="images/main-slider/home1-shape6.png" alt="">
      </div>
      <div class="auto-container">
        <div class="content-box">
          <span class="sub-title animate-1">TECH MANAGEMENT</span>
          <h1 class="title animate-2">The Best Source <br>for IT Solutions</h1>
          <div class="text animate-3">Web designing in a powerful way of just not an only professions, however, in a passion for <br>our Company. We have to a tendency to believe the idea that smart looking of any website <br>is the first impression on visitors</div>
          <div class="btn-box animate-4">
            <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title"> Discover more</span></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="clients-section border-bottom">
  <div class="auto-container">
    <!-- Sponsors Outer -->
    <div class="sponsors-outer">
      <!--clients carousel-->
      <ul class="clients-carousel owl-carousel owl-theme pt-5 pb-5">
        <li class="slide-item"> <a href="#"><img src="images/resource/client-2.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-3.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-4.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-5.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-6.png" alt=""></a> </li>
      </ul>
    </div>
  </div>
</section><section id="about" class="about-section-five">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-6 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">About Our Company</span>
                        <h2>Professional IT Experts for Tech Solutions</h2>
                        <div class="text">Web designing in a powerful way of just not an only professions, however, in a passion for our Company. We have to a
                        tendency to believe the idea that smart looking of any website is the first impression on visitors.</div>
                    </div>

                    <ul class="list-style-three">
                        <li>The business applications</li>
                        <li>The business applications</li>
                        <li>Revolutionary catalysts chang</li>
                        <li>Revolutionary catalysts chang</li>
                        <li>Catalysts for chang seamlessly</li>
                        <li>Catalysts for chang seamlessly</li>
                    </ul>

                    <div class="btn-box d-flex">
                        <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title">Explore now</span></a>
                        <div class="founder-info">
                            <div class="thumb"><img src="images/resource/thumb-1.jpg" alt=""></div>
                            <h5 class="name">Jon Martin</h5>
                            <span class="designation">Co Founder</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-6 col-lg-5 col-md-12 col-sm-12">
                <div class="inner-column">
                    <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about-9.jpg" alt="">
                    </figure>
                    <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about-10.jpg" alt="">
                    </figure>
                </div>
            </div>
        </div>
    </div>
</section><section id="services" class="services-section-six">
    <div class="auto-container">
        <div class="sec-title">
            <div class="row">
                <div class="col-lg-7">
                    <span class="sub-title">What We’re Offering</span>
                    <h2>Services Built Specifically <br>for your Business</h2>
                </div>
                <div class="col-lg-5">
                    <div class="text">Lorem ipsum dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et simply free text dolore magna aliqua lonm andhn.</div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">UI / UX Creative <br>Design</a></h4>
                    <i class="icon flaticon-Set flaticon-business-002-color-sample"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Website Graphics <br>Design</a></h4>
                    <i class="icon flaticon-Set flaticon-business-013-idea"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Streagy & Digital <br>Marketing</a></h4>
                    <i class="icon flaticon-Set flaticon-business-007-settings"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Effective Business <br>Growth</a></h4>
                    <i class="icon flaticon-Set flaticon-business-3956725"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>

            <!-- Service Block -->
            <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
                <div class="inner-box ">
                    <h4 class="title"><a href="page-service-details.php">Data Security <br>Management</a></h4>
                    <i class="icon flaticon-Set flaticon-business-013-campaign"></i>
                    <a href="page-service-details.php" class="read-more">Read More</a>
                </div>
            </div>
        </div>
        <div class="bottom-text">
            <div class="inner">
                <div class="text">Need digital marketing solutions & services? <span class="color2">Send a request now</span></div>
                <a href="page-services.php" class="theme-btn btn-style-one"><span class="btn-title">All Services</span></a>
            </div>
        </div>
    </div>
</section><div class="marquee-section">
    <div class="marquee">
        <div class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
        <div aria-hidden="true" class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
    </div>
</div><section class="offer-section">
    <div class="auto-container">
        <div class="row">
            <!-- Content Column -->
            <div class="content-column col-lg-6 col-md-12">
                <div class="inner-column">
                    <div class="sec-title light">
                        <span class="sub-title">TECH MANAGEMENT</span>
                        <h2>Empowering Businesses Through Technology</h2>
                        <div class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu convenient scheduling, account fugiat nulla pariatur.</div>
                    </div>
                    <div class="info-box">
                        <i class="icon flaticon-business-036-idea"></i>
                        <h4 class="title">We’re doing the right thing.<br> The right way.</h4>
                    </div>
                    <ul class="list-style-two">
                        <li><i class="fa fa-check-circle"></i> Reliable Support and Maintenance</li>
                        <li><i class="fa fa-check-circle"></i> Making this the first true generator on the Internet</li>
                        <li><i class="fa fa-check-circle"></i> Various versions have evolved over the years</li>
                    </ul>
                </div>
            </div>

            <!-- Content Column -->
            <div class="image-column col-lg-6 col-md-12 col-sm-12">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image"><img src="images/resource/image-4.png" alt=""></figure>
                        <div class="caption-box wow slideInRight">
                            <div class="icon-box">
                                <a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now-two lightbox-image"><i class="icon fa fa-play"></i></a>
                            </div>
                            <div class="title-box">
                                <h4 class="title">Professional IT technology services you can trust</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="project" class="project-section bg-color3 pb-0">
    <div class="auto-container">
        <div class="sec-title">
            <div class="row">
                <div class="col-lg-7">
                    <span class="sub-title">recently Completed work</span>
                    <h2>Improve & Enhance the <br>Tech Projects</h2>
                </div>
                <div class="col-lg-5">
                    <div class="text">There are many variations of passages of available but majority have suffered alteration in some form, by humou or randomised words which don't look even slightly believable.</div>
                </div>
            </div>
        </div>

        <div class="carousel-outer ms-0 me-0">
            <!-- Prject Carousel -->
            <div class="project-carousel owl-carousel owl-theme">
                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-1.jpg" class="lightbox-image"><img src="images/resource/project2-1.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">Product & Design</a></h4>
                            <span class="cat">DESIGN / IDEAS</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-2.jpg" class="lightbox-image"><img src="images/resource/project2-2.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">IT Consulting</a></h4>
                            <span class="cat">DESIGN / IDEAS</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-3.jpg" class="lightbox-image"><img src="images/resource/project2-3.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">App Integration</a></h4>
                            <span class="cat">DESIGN / IDEAS</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-4.jpg" class="lightbox-image"><img src="images/resource/project2-4.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">Smart Visions</a></h4>
                            <span class="cat">DESIGN / IDEAS</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="testimonial" class="testimonial-section-five bg-color3">
    <div class="bg-shape2" style="background-image: url(./images/icons/bg-shape2.png);"></div>
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">OUR FEEDBAKCS</span>
            <h2>What They’re Talking <br>About Company</h2>
        </div>

        <div class="row">
            <!-- Testimonial Block -->
            <div class="testimonial-block-five col-lg-4 col-md-6">
                <div class="inner-box">
                    <div class="content-box">
                        <figure class="thumb"><img src="images/resource/testi-thumb-2.jpg" alt=""></figure>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="text">Sed ut perspiciatis unde omnis natus error sit voluptatem accusa ntium dolore laudantium totam rem aperiamea queipsa quae abillo inventore veritatis et quasi beatae.</div>
                        <div class="info-box">
                            <h4 class="name">Sarah albert</h4>
                            <span class="designation">Manager</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Testimonial Block -->
            <div class="testimonial-block-five col-lg-4 col-md-6">
                <div class="inner-box">
                    <div class="content-box">
                        <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="text">Sed ut perspiciatis unde omnis natus error sit voluptatem accusa ntium dolore laudantium totam rem aperiamea queipsa quae abillo inventore veritatis et quasi beatae.</div>
                        <div class="info-box">
                            <h4 class="name">Mike hardson</h4>
                            <span class="designation">It Officer</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Testimonial Block -->
            <div class="testimonial-block-five col-lg-4 col-md-6">
                <div class="inner-box">
                    <div class="content-box">
                        <figure class="thumb"><img src="images/resource/testi-thumb-1.jpg" alt=""></figure>
                        <div class="rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <div class="text">Sed ut perspiciatis unde omnis natus error sit voluptatem accusa ntium dolore laudantium totam rem aperiamea queipsa quae abillo inventore veritatis et quasi beatae.</div>
                        <div class="info-box">
                            <h4 class="name">Aleesha brown</h4>
                            <span class="designation">HR admin</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="call-to-action" style="background-image: url(./images/background/1.jpg)">
    <div class="auto-container">
        <div class="title-box">
            <div class="icon bounce-y"><img src="images/resource/icon-logo.png" alt=""></div>
            <h1 class="title">IT Solutions & Services at your <br>Fingertips</h1>
            <a href="page-services.php" class="theme-btn btn-style-one"><span class="btn-title">Discover more</span></a>
        </div>
    </div>
</section><section class="why-choose-us-four">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-7 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Company Benefits</span>
                        <h2>Why Should You Choose Our Agency?</h2>
                        <h3>Proin are many variations passages of available.</h3>
                        <div class="text">There are many variations of passages of available but the majority have suffered. Alteration in some form, lipsum is simply free text by injected humou or randomised words. variations of passages of available</div>
                    </div>

                    <blockquote class="blockquote-style-one">Lorem ipsum dolor sit amet, consectetur notted dipisicing elit sed do eiusmod consectetur notted dipisicing elit</blockquote>

                    <div class="btn-box">
                        <a href="page-about" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Explore Now</span></a>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-5 col-lg-5 col-md-12 col-sm-12">
                <div class="inner-column wow fadeInLeft">
                    <div class="image-box">
                        <span class="bg-shape"></span>
                        <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/why-us4-1.png" alt=""></figure>
                        <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-2.png" alt=""></figure>
                        <figure class="image-3 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-3.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="fun-fact-section pt-0">
    <div class="auto-container">
        <div class="fact-counter">
            <div class="row">
                <!-- Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner">
                        <i class="icon flaticon-business-060-graph"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="4520">0</span></div>
                        <h6 class="counter-title">Project completed</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                    <div class="inner">
                        <i class="icon flaticon-business-035-helpline"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="326">0</span></div>
                        <h6 class="counter-title">IT specialists</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                    <div class="inner">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="8600">0</span></div>
                        <h6 class="counter-title">Satisfied clients</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
                    <div class="inner">
                        <i class="icon flaticon-business-048-coin"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="238">0</span></div>
                        <h6 class="counter-title">Smart solutions</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="contact" class="faqs-section">
  <div class="auto-container">
    <div class="row">
      <!-- FAQ Column -->
      <div class="faq-column col-lg-6 col-md-12 col-sm-12 order-4">
        <div class="faq-bg" style="background-image: url(./images/icons/pattern-2.jpg)"></div>
        <div class="inner-column">
          <div class="sec-title">
            <span class="sub-title">Questions & answers</span>
            <h2>See Frequently Asked Questions</h2>
          </div>

          <ul class="accordion-box wow fadeInRight">
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">Is my technology allowed on tech?
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">There are many variations of passages the majority have suffered alteration in some fo
                    injected humour, or randomised words believable.</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block active-block">
              <div class="acc-btn active">How to soft launch your business?
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content current">
                <div class="content">
                  <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">How to turn visitors into contributors
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">How can i find my solutions?
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <!-- Form Column -->
      <div class="form-column col-lg-6 col-md-12 col-sm-12">
        <div class="form-bg" style="background-image: url(./images/background/6.jpg)"></div>
        <div class="inner-column">
          <!-- Contact Form -->
          <div class="contact-form wow fadeInLeft">
            <div class="title-box">
              <span class="sub-title">Contact us</span>
              <h3>Write Email</h3>
            </div>

            <!-- Contact Form -->
            <form id="contact_form" name="contact_form" action="includes/sendmail.php" method="post">
              <div class="form-group">
                <input name="form_name" class="form-control" id="name" placeholder="Name" type="text">
              </div>

              <div class="form-group">
                <input name="form_email" class="form-control required" id="email" placeholder="E-mail address" type="email">
              </div>

              <div class="form-group">
                <input type="text" name="form_subject" placeholder="Subject" required>
              </div>

              <div class="form-group">
                <input type="text" name="form_phone" placeholder="Phone (Optional)">
              </div>

              <div class="form-group">
                <textarea name="form_message" class="form-control required" placeholder="Write a Message" id="message"></textarea>
              </div>

              <div class="form-group">
                <input type="hidden" name="form_botcheck" value="">
                <button type="submit" class="theme-btn btn-style-one" name="submit-form" data-loading-text="Please wait...">
                  <span class="btn-title">Send a message</span>
                </button>
              </div>
            </form>

          </div>
          <!--End Contact Form -->

        </div>
      </div>
    </div>
  </div>
</section><section id="news" class="news-section">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">from the blog</span>
            <h2>News & Articles</h2>
        </div>

        <div class="row">
            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-1.jpg" alt=""></a></figure>
                        <span class="date"><b>21</b> OCT</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> by Admin</li>
                            <li><i class="fa fa-tag"></i> Technology</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> 02</div>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-2.jpg" alt=""></a></figure>
                        <span class="date"><b>31</b> JAN</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> by Admin</li>
                            <li><i class="fa fa-tag"></i> Technology</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> 02</div>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-3.jpg" alt=""></a></figure>
                        <span class="date"><b>28</b> OCT</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> by Admin</li>
                            <li><i class="fa fa-tag"></i> Technology</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
                        <div class="text">Parturient platea sociis congue maecenas dictumst imperdiet velit pellentesque rutrum molestie diam tempor tortor aptent natoque</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> 02</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="call-to-action-two p-0">
    <div class="auto-container">
        <div class="outer-box wow fadeIn">
            <!-- Image Box -->
            <div class="image-box">
                <figure class="image"><img src="images/resource/image-2.jpg" alt=""></figure>
            </div>
            <!-- Content Box -->
            <div class="content-box">
                <div class="title-box">
                    <h3 class="title">The Passion Trying & Skill Can <br>Make A Top Performing Company</h3>
                </div>
                <div class="btn-box">
                    <a href="page-about.php" class="theme-btn btn-style-two hvr-light"><span class="btn-title">DISCOVER MORE</span></a>
                </div>
            </div>
        </div>
    </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo-2.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>