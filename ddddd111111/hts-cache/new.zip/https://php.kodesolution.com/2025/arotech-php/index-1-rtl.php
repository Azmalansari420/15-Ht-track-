
<!DOCTYPE html>
<html dir="rtl" lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 01 Rtl</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style-rtl.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
class="rtl"
>
<div class="page-wrapper">

<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header class="main-header header-style-one">
  <!-- Header Top -->
  <div class="header-top">
    <div class="inner-container">

      <div class="top-left">
        <!-- Info List -->
        <ul class="list-style-one">
          <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">بحاجة الى مساعدة@شركة.كوم</a></li>
          <li><i class="fa fa-map-marker"></i> ۸۸ شارع بروكلين الذهبي، نيويورك</li>
        </ul>
      </div>

      <div class="top-right">
        <ul class="useful-links">
          <li><a href="#">يساعد</a></li>
          <li><a href="#">يدعم</a></li>
          <li><a href="#">اتصال</a></li>
        </ul>
      </div>
    </div>

    <div class="outer-box">
      <ul class="social-icon-one">
        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
      </ul>
    </div>
  </div>
  <!-- Header Top -->

  <!-- Header Lower -->
  <div class="header-lower">
    <!-- Main box -->
    <div class="main-box">
      <div class="logo-box">
        <div class="logo">
                      <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
        </div>
      </div>

      <!--Nav Box-->
      <div class="nav-outer">

        <nav class="nav main-menu">
                      <ul class="navigation">
  <li class="current dropdown"><a href="index.php">بيت</a>
    <ul>
      <li><a href="index.php">Home Layout 1</a></li>
      <li><a href="index-2.php">Home Layout 2</a></li>
      <li><a href="index-3.php">Home Layout 3</a></li>
      <li class="dropdown"><a href="#">More Home Layouts</a>
        <ul>
          <li><a href="index-4.php">Home Layout 4</a></li>
          <li><a href="index-5.php">Home Layout 5</a></li>
          <li><a href="index-6.php">Home Layout 6</a></li>
          <li><a href="index-7.php">Home Layout 7</a></li>
          <li><a href="index-8.php">Home Layout 8</a></li>
          <li><a href="index-9.php">Home Layout 9</a></li>
          <li><a href="index-10.php">Home Layout 10</a></li>
          <li><a href="index-11.php">Home Layout 11</a></li>
          <li><a href="index-12.php">Home Layout 12</a></li>
          <li><a href="index-13.php">Home Layout 13</a></li>
          <li><a href="index-14.php">Home Layout 14</a></li>
          <li><a href="index-15.php">Home Layout 15</a></li>
          <li><a href="index-16.php">Home Layout 16</a></li>
          <li><a href="index-17.php">Home Layout 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Styles</a>
        <ul>
          <li><a href="index.php">Header Style 1</a></li>
          <li><a href="index-2.php">Header Style 2</a></li>
          <li><a href="index-3.php">Header Style 3</a></li>
          <li><a href="index-4.php">Header Style 4</a></li>
          <li><a href="index-5.php">Header Style 5</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Single</a>
        <ul>
          <li><a href="index-1-single.php">Header Single 1</a></li>
          <li><a href="index-2-single.php">Header Single 2</a></li>
          <li><a href="index-3-single.php">Header Single 3</a></li>
          <li><a href="index-4-single.php">Header Single 4</a></li>
          <li><a href="index-5-single.php">Header Single 5</a></li>
          <li><a href="index-6-single.php">Header Single 6</a></li>
          <li><a href="index-7-single.php">Header Single 7</a></li>
          <li><a href="index-8-single.php">Header Single 8</a></li>
          <li><a href="index-9-single.php">Header Single 9</a></li>
          <li><a href="index-10-single.php">Header Single 10</a></li>
          <li><a href="index-11-single.php">Header Single 11</a></li>
          <li><a href="index-12-single.php">Header Single 12</a></li>
          <li><a href="index-13-single.php">Header Single 13</a></li>
          <li><a href="index-14-single.php">Header Single 14</a></li>
          <li><a href="index-15-single.php">Header Single 15</a></li>
          <li><a href="index-16-single.php">Header Single 16</a></li>
          <li><a href="index-17-single.php">Header Single 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Dark</a>
        <ul>
          <li><a href="index-1-dark.php">Header Dark 1</a></li>
          <li><a href="index-2-dark.php">Header Dark 2</a></li>
          <li><a href="index-3-dark.php">Header Dark 3</a></li>
          <li><a href="index-4-dark.php">Header Dark 4</a></li>
          <li><a href="index-5-dark.php">Header Dark 5</a></li>
          <li><a href="index-6-dark.php">Header Dark 6</a></li>
          <li><a href="index-7-dark.php">Header Dark 7</a></li>
          <li><a href="index-8-dark.php">Header Dark 8</a></li>
          <li><a href="index-9-dark.php">Header Dark 9</a></li>
          <li><a href="index-10-dark.php">Header Dark 10</a></li>
          <li><a href="index-11-dark.php">Header Dark 11</a></li>
          <li><a href="index-12-dark.php">Header Dark 12</a></li>
          <li><a href="index-13-dark.php">Header Dark 13</a></li>
          <li><a href="index-14-dark.php">Header Dark 14</a></li>
          <li><a href="index-15-dark.php">Header Dark 15</a></li>
          <li><a href="index-16-dark.php">Header Dark 16</a></li>
          <li><a href="index-17-dark.php">Header Dark 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Rtl Page</a>
        <ul>
          <li><a href="index-1-rtl.php">Header Rtl</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">الصفحات</a>
    <ul>
      <li><a href="page-about.php">About</a></li>
      <li class="dropdown"><a href="#">Projects</a>
        <ul>
          <li><a href="page-projects.php">Projects List</a></li>
          <li><a href="page-project-details.php">Project Details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team List</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-testimonial.php">Testimonial</a></li>
      <li><a href="page-pricing.php">Pricing</a></li>
      <li><a href="page-pricing-switcher.php">Pricing Switcher</a></li>
      <li><a href="page-faq.php">FAQ</a></li>
      <li><a href="page-404.php">Page 404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">خدمات</a>
    <ul>
      <li><a href="page-services.php">Services List</a></li>
      <li><a href="page-service-details.php">Service Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">محل</a>
    <ul>
      <li><a href="shop-products.php">Products</a></li>
      <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
      <li><a href="shop-product-details.php">Product Details</a></li>
      <li><a href="shop-cart.php">Cart</a></li>
      <li><a href="shop-checkout.php">Checkout</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">أخبار</a>
    <ul>
      <li><a href="news-grid.php">News Grid</a></li>
      <li><a href="news-details.php">News Details</a></li>
    </ul>
  </li>
  <li><a href="page-contact.php">اتصال</a></li>
</ul>        </nav>
        <!-- Main Menu End-->


        <div class="outer-box">
          <div class="ui-btn-outer">
            <button class="ui-btn ui-btn search-btn">
              <span class="icon lnr lnr-icon-search"></span>
            </button>
            <a href="shop-cart.php" class="ui-btn"><i class="lnr-icon-shopping-cart"></i></a>
          </div>


          <a href="tel:+92(8800)9806" class="info-btn">
            <i class="icon fa fa-phone"></i>
            <small>اتصل في أي وقت</small><br /> + ۸۸ ( ۹۸۰۰ ) ۶۸۰۲
          </a>

          <a href="page-contact.php" class="theme-btn btn-style-one"><span class="btn-title">الحصول على الحل</span></a>

          <!-- Mobile Nav toggler -->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Header Lower -->

  <!-- Mobile Menu  -->
  <div class="mobile-menu">
    <div class="menu-backdrop"></div>

    <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
    <nav class="menu-box">
      <div class="upper-box">
        <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
        <div class="close-btn"><i class="icon fa fa-times"></i></div>
      </div>

      <ul class="navigation clearfix">
        <!--Keep This Empty / Menu will come through Javascript-->
      </ul>
      <ul class="contact-list-one">
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <i class="icon lnr-icon-phone-handset"></i>
            <span class="title">اتصل الآن</span>
            <a href="tel:+92880098670">+۹۲ (۸۸۰۰) - ۹۸۶۷۰</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-envelope1"></span>
            <span class="title">إرسال البريد الإلكتروني</span>
            <a href="mailto:help@company.com">يساعد@شركة.كوم</a>
          </div>
        </li>
        <li>
          <!-- Contact Info Box -->
          <div class="contact-info-box">
            <span class="icon lnr-icon-clock"></span>
            <span class="title">إرسال البريد الإلكتروني</span>
            الإثنين - السبت ۸:۰۰ - ۶:۳۰, الأحد - مغلق
          </div>
        </li>
      </ul>


      <ul class="social-links">
        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      </ul>
    </nav>
  </div><!-- End Mobile Menu -->

  <!-- Header Search -->
  <div class="search-popup">
    <span class="search-back-drop"></span>
    <button class="close-search"><span class="fa fa-times"></span></button>

    <div class="search-inner">
      <form method="post" action="index.php">
        <div class="form-group">
          <input type="search" name="search-field" value="" placeholder="يبحث..." required="">
          <button type="submit"><i class="fa fa-search"></i></button>
        </div>
      </form>
    </div>
  </div>
  <!-- End Header Search -->

  <!-- Sticky Header  -->
  <div class="sticky-header">
    <div class="auto-container">
      <div class="inner-container">
        <!--Logo-->
        <div class="logo">
                    <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
        </div>

        <!--Right Col-->
        <div class="nav-outer">
          <!-- Main Menu -->
          <nav class="main-menu">
            <div class="navbar-collapse show collapse clearfix">
              <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
              </ul>
            </div>
          </nav><!-- Main Menu End-->

          <!--Mobile Navigation Toggler-->
          <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
        </div>
      </div>
    </div>
  </div><!-- End Sticky Menu -->
</header>  

<section class="banner-section">
  <div class="banner-carousel owl-carousel owl-theme">
    <!-- Slide Item -->
    <div class="slide-item">
      <div class="bg-image" style="background-image: url(images/main-slider/slider1.jpg);"></div>
      <div class="anim-icons animate-1">
        <img class="shape-image1" src="images/main-slider/home1-shape1.png" alt="">
        <img class="shape-image2" src="images/main-slider/home1-shape2.png" alt="">
        <img class="shape-image3" src="images/main-slider/home1-shape3.png" alt="">
        <img class="shape-image4 bounce-y" src="images/main-slider/home1-shape4.png" alt="">
        <img class="shape-image5" src="images/main-slider/home1-shape5.png" alt="">
        <img class="shape-image6" src="images/main-slider/home1-shape6.png" alt="">
      </div>
      <div class="auto-container">
        <div class="content-box">
          <span class="sub-title animate-1">إدارة التكنولوجيا</span>
          <h1 class="title animate-2">أفضل مصدر <br />لحلول تكنولوجيا المعلومات</h1>
          <div class="text animate-3">تصميم الويب بطريقة قوية ليس مجرد مهنة، بل هو شغف <br />شركتنا. علينا أن الميل إلى الاعتقاد بأن المظهر الأنيق لأي موقع ويب <br />هو الانطباع الأول لدى الزوار</div>
          <div class="btn-box animate-4">
            <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title"> اكتشف المزيد</span></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="clients-section border-bottom">
  <div class="auto-container">
    <!-- Sponsors Outer -->
    <div class="sponsors-outer">
      <!--clients carousel-->
      <ul class="clients-carousel owl-carousel owl-theme pt-5 pb-5">
        <li class="slide-item"> <a href="#"><img src="images/resource/client-2.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-3.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-4.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-5.png" alt=""></a> </li>
        <li class="slide-item"> <a href="#"><img src="images/resource/client-6.png" alt=""></a> </li>
      </ul>
    </div>
  </div>
</section><section class="about-section-five">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-6 col-lg-7 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">حول شركتنا</span>
                        <h2>خبراء تكنولوجيا المعلومات المحترفين للحلول التقنية</h2>
                        <div class="text">تصميم المواقع الإلكترونية ليس مهنةً فحسب، بل شغفٌ بشركتنا. نؤمن بأن المظهر الأنيق لأي موقع إلكتروني هو الانطباع الأول لدى الزوار.</div>
                    </div>

                    <ul class="list-style-three">
                        <li>تطبيقات الأعمال</li>
                        <li>تطبيقات الأعمال</li>
                        <li>المحفزات الثورية تغير</li>
                        <li>المحفزات الثورية تغير</li>
                        <li>محفزات للتغيير بسلاسة</li>
                        <li>محفزات للتغيير بسلاسة</li>
                    </ul>

                    <div class="btn-box d-flex">
                        <a href="page-about.php" class="theme-btn btn-style-one"><span class="btn-title">استكشف الآن</span></a>
                        <div class="founder-info">
                            <div class="thumb"><img src="images/resource/thumb-1.jpg" alt=""></div>
                            <h5 class="name">جون مارتن</h5>
                            <span class="designation">المؤسس المشارك</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-6 col-lg-5">
                <div class="inner-column">
                    <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about-9.jpg" alt=""></figure>
                    <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about-10.jpg" alt=""></figure>
                </div>
            </div>
        </div>
    </div>
</section><section class="services-section-six">
  <div class="auto-container">
    <div class="sec-title">
      <div class="row">
        <div class="col-lg-7">
          <span class="sub-title">ما نقدمه</span>
          <h2>خدمات مصممة خصيصًا <br />لعملك</h2>
        </div>
        <div class="col-lg-5">
          <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف حقيقة وأساس تلك ال</div>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">إبداعات واجهة المستخدم وتجربة المستخدم <br />تصميم</a></h4>
          <i class="icon flaticon-Set flaticon-business-002-color-sample"></i>
          <a href="page-service-details.php" class="read-more">اقرأ المزيد</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">رسومات الموقع <br />تصميم</a></h4>
          <i class="icon flaticon-Set flaticon-business-013-idea"></i>
          <a href="page-service-details.php" class="read-more">اقرأ المزيد</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">الاستراتيجية والرقمية <br />تسويق</a></h4>
          <i class="icon flaticon-Set flaticon-business-007-settings"></i>
          <a href="page-service-details.php" class="read-more">اقرأ المزيد</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">الأعمال الفعالة <br />نمو</a></h4>
          <i class="icon flaticon-Set flaticon-business-3956725"></i>
          <a href="page-service-details.php" class="read-more">اقرأ المزيد</a>
        </div>
      </div>

      <!-- Service Block -->
      <div class="service-block-six col-xl-2 col-lg-3 col-md-4 col-sm-6 wow fadeInUp">
        <div class="inner-box ">
          <h4 class="title"><a href="page-service-details.php">أمن البيانات <br />إدارة</a></h4>
          <i class="icon flaticon-Set flaticon-business-013-campaign"></i>
          <a href="page-service-details.php" class="read-more">اقرأ المزيد</a>
        </div>
      </div>
    </div>
    <div class="bottom-text">
      <div class="inner">
        <div class="text">هل تحتاج إلى حلول وخدمات التسويق الرقمي؟ <span class="color2">أرسل الطلب الآن</span></div>
        <a href="page-services.php" class="theme-btn btn-style-one"><span class="btn-title">جميع الخدمات</span></a>
      </div>
    </div>
  </div>
</section><div class="marquee-section">
    <div class="marquee">
        <div class="marquee-group">
            <div class="text">تحويل الأفكار إلى واقع</div>
            <div class="text">مستوحى من الإبداع</div>
            <div class="text">تصميم وتطوير حرفة</div>
            <div class="text">فتح الإمكانات</div>
            <div class="text">تحويل الأفكار إلى واقع</div>
        </div>
                            
        <div aria-hidden="true" class="marquee-group">
            <div class="text">تحويل الأفكار إلى واقع</div>
            <div class="text">مستوحى من الإبداع</div>
            <div class="text">تصميم وتطوير حرفة</div>
            <div class="text">فتح الإمكانات</div>
            <div class="text">تحويل الأفكار إلى واقع</div>
        </div>
    </div>
</div><section class="offer-section">
    <div class="auto-container">
        <div class="row">
            <!-- Content Column -->
            <div class="content-column col-lg-6 col-md-12">
                <div class="inner-column">
                    <div class="sec-title light">
                        <span class="sub-title">إدارة التكنولوجيا</span>
                        <h2>تمكين الشركات من خلال التكنولوجيا</h2>
                        <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف حقيقة .</div>
                    </div>
                    <div class="info-box">
                        <i class="icon flaticon-business-036-idea"></i>
                        <h4 class="title">نحن نفعل الشيء الصحيح.<br /> الطريق الصحيح.</h4>
                    </div>
                    <ul class="list-style-two">
                        <li><i class="fa fa-check-circle"></i> دعم وصيانة موثوقة</li>
                        <li><i class="fa fa-check-circle"></i> جعل هذا أول مولد حقيقي على الإنترنت</li>
                        <li><i class="fa fa-check-circle"></i> لقد تطورت إصدارات مختلفة على مر السنين</li>
                    </ul>
                </div>
            </div>

            <!-- Content Column -->
            <div class="image-column col-lg-6">
                <div class="inner-column">
                    <div class="image-box">
                        <figure class="image"><img src="images/resource/image-4.png" alt=""></figure>
                        <div class="caption-box wow slideInRight">
                            <div class="icon-box">
                                <a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now-two lightbox-image"><i class="icon fa fa-play"></i></a>
                            </div>
                            <div class="title-box">
                                <h4 class="title">خدمات تكنولوجيا المعلومات الاحترافية التي يمكنك الوثوق بها</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="project-section bg-color3 pb-0">
    <div class="auto-container">
        <div class="sec-title">
            <div class="row">
                <div class="col-lg-7">
                    <span class="sub-title">تم الانتهاء من العمل مؤخرا</span>
                    <h2>تحسين وتعزيز <br />المشاريع التقنية</h2>
                </div>
                <div class="col-lg-5">
                    <div class="text">هناك العديد من الاختلافات في المقاطع المتاحة ولكن الأغلبية تعرضت للتغيير في شكل ما، من خلال مزاح أو الكلمات العشوائية التي لا تبدو معقولة حتى قليلاً.</div>
                </div>
            </div>
        </div>

        <div class="carousel-outer ms-0 me-0">
            <!-- Prject Carousel -->
            <div class="project-carousel owl-carousel owl-theme">
                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-1.jpg" class="lightbox-image"><img src="images/resource/project2-1.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-left"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">المنتج والتصميم</a></h4>
                            <span class="cat">التصميم / الأفكار</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-2.jpg" class="lightbox-image"><img src="images/resource/project2-2.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-left"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">استشارات تكنولوجيا المعلومات</a></h4>
                            <span class="cat">التصميم / الأفكار</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-3.jpg" class="lightbox-image"><img src="images/resource/project2-3.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-left"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">تكامل التطبيق</a></h4>
                            <span class="cat">التصميم / الأفكار</span>
                        </div>
                    </div>
                </div>

                <!-- Project Block -->
                <div class="project-block">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><a href="images/resource/project2-4.jpg" class="lightbox-image"><img src="images/resource/project2-4.jpg" alt=""></a></figure>
                            <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-left"></i></a>
                        </div>
                        <div class="content-box">
                            <h4 class="title"><a href="page-project-details.php">الرؤى الذكية</a></h4>
                            <span class="cat">التصميم / الأفكار</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="testimonial-section-five bg-color3">
  <div class="bg-shape2" style="background-image: url(./images/icons/bg-shape2.png);"></div>
  <div class="auto-container">
    <div class="sec-title text-center">
      <span class="sub-title">تعليقاتكم</span>
      <h2>ماذا يتحدثون <br />عن الشركة</h2>
    </div>

    <div class="row">
      <!-- Testimonial Block -->
      <div class="testimonial-block-five col-lg-4 col-md-6">
        <div class="inner-box">
          <div class="content-box">
            <figure class="thumb"><img src="images/resource/testi-thumb-2.jpg" alt=""></figure>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
            </div>
            <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف حقيقة وأساس تلك السعادة .</div>
            <div class="info-box">
              <h4 class="name">سارة ألبرت</h4>
              <span class="designation">مدير</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Testimonial Block -->
      <div class="testimonial-block-five col-lg-4 col-md-6">
        <div class="inner-box">
          <div class="content-box">
            <figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
            </div>
            <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف حقيقة وأساس تلك السعادة .</div>
            <div class="info-box">
              <h4 class="name">مايك هاردسون</h4>
              <span class="designation">ضابط تكنولوجيا المعلومات</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Testimonial Block -->
      <div class="testimonial-block-five col-lg-4 col-md-6">
        <div class="inner-box">
          <div class="content-box">
            <figure class="thumb"><img src="images/resource/testi-thumb-1.jpg" alt=""></figure>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
            </div>
            <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف حقيقة وأساس تلك السعادة .</div>
            <div class="info-box">
              <h4 class="name">أليشا البني</h4>
              <span class="designation">مسؤول الموارد البشرية</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section class="call-to-action" style="background-image: url(./images/background/1.jpg)">
    <div class="auto-container">
        <div class="title-box">
            <div class="icon bounce-y"><img src="images/resource/icon-logo.png" alt=""></div>
            <h1 class="title">حلول وخدمات تكنولوجيا المعلومات في متناول يدك <br />أطراف الأصابع</h1>
            <a href="page-services.php" class="theme-btn btn-style-one"><span class="btn-title">اكتشف المزيد</span></a>
        </div>
    </div>
</section><section class="why-choose-us-four">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-7 col-lg-7 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">فوائد الشركة</span>
                        <h2>لماذا يجب عليك اختيار وكالتنا؟</h2>
                        <h3>هناك العديد من المقاطع المتنوعة المتاحة.</h3>
                        <div class="text">هناك العديد من الاختلافات في النصوص المتاحة، لكن الغالبية تأثرت. النص الأصلي عبارة عن نص حر، يتم إدخال بعض التعديلات عليه، أو كلمات عشوائية. تنوعات في النصوص المتاحة.</div>
                    </div>

                    <blockquote class="blockquote-style-one">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك ال</blockquote>

                    <div class="btn-box">
                        <a href="page-about" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">اكتشف الآن</span></a>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-5 col-lg-5">
                <div class="inner-column wow fadeInLeft">
                    <div class="image-box">
                        <span class="bg-shape"></span>
                        <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/why-us4-1.png" alt=""></figure>
                        <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-2.png" alt=""></figure>
                        <figure class="image-3 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-3.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="fun-fact-section pt-0">
    <div class="auto-container">
        <div class="fact-counter">
            <div class="row">
                <!-- Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner">
                        <i class="icon flaticon-business-060-graph"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="4520">0</span></div>
                        <h6 class="counter-title">اكتمل المشروع</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                    <div class="inner">
                        <i class="icon flaticon-business-035-helpline"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="326">0</span></div>
                        <h6 class="counter-title">متخصصون في تكنولوجيا المعلومات</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                    <div class="inner">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="8600">0</span></div>
                        <h6 class="counter-title">العملاء الراضون</h6>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block col-lg-3 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="900ms">
                    <div class="inner">
                        <i class="icon flaticon-business-048-coin"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="238">0</span></div>
                        <h6 class="counter-title">حلول ذكية</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="faqs-section">
  <div class="auto-container">
    <div class="row">
      <!-- FAQ Column -->
      <div class="faq-column col-lg-6 order-4">
        <div class="faq-bg" style="background-image: url(./images/icons/pattern-2.jpg)"></div>
        <div class="inner-column">
          <div class="sec-title">
            <span class="sub-title">أسئلة وأجوبة</span>
            <h2>انظر الأسئلة الشائعة</h2>
          </div>

          <ul class="accordion-box wow fadeInRight">
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">هل يسمح باستخدام التكنولوجيا الخاصة بي على التكنولوجيا؟
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">هناك العديد من الاختلافات في المقاطع، وقد عانت الأغلبية من التغيير في بعضها لإضافة الفكاهة أو الكلمات العشوائية المعقولة..</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block active-block">
              <div class="acc-btn active">كيفية إطلاق مشروعك التجاري بشكل تجريبي؟
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content current">
                <div class="content">
                  <div class="text">هناك العديد من الاختلافات في المقاطع، وقد عانت الأغلبية من التغيير في بعض الفكاهة المضافة، أو الكلمات العشوائية التي تبدو معقولة..</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">كيفية تحويل الزوار إلى مساهمين
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">هناك العديد من الاختلافات في المقاطع، وقد عانت الأغلبية من التغيير في بعض الفكاهة المضافة، أو الكلمات العشوائية التي تبدو معقولة..</div>
                </div>
              </div>
            </li>
            <!--Block-->
            <li class="accordion block">
              <div class="acc-btn">كيف يمكنني العثور على حلولي؟
                <div class="icon fa fa-plus"></div>
              </div>
              <div class="acc-content">
                <div class="content">
                  <div class="text">هناك العديد من الاختلافات في المقاطع، وقد عانت الأغلبية من التغيير في بعض الفكاهة المضافة، أو الكلمات العشوائية التي تبدو معقولة..</div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <!-- Form Column -->
      <div class="form-column col-lg-6">
        <div class="form-bg" style="background-image: url(./images/background/6.jpg)"></div>
        <div class="inner-column">
          <!-- Contact Form -->
          <div class="contact-form wow fadeInLeft">
            <div class="title-box">
              <span class="sub-title">اتصل بنا</span>
              <h3>اكتب البريد الإلكتروني</h3>
            </div>

            <!--Contact Form-->
            <form method="post" action="get" id="contact-form">
              <div class="form-group">
                <input type="text" name="full_name" placeholder="اسمك" required>
              </div>

              <div class="form-group">
                <input type="text" name="Email" placeholder="عنوان البريد الإلكتروني" required>
              </div>

              <div class="form-group">
                <input type="text" name="Phone" placeholder="رقم التليفون" required>
              </div>

              <div class="form-group">
                <textarea name="message" placeholder="اكتب رسالة" required></textarea>
              </div>

              <div class="form-group">
                <button class="theme-btn btn-style-one" type="submit" name="submit-form"><span class="btn-title">أرسل رسالة</span></button>
              </div>
            </form>
          </div>
          <!--End Contact Form -->

        </div>
      </div>
    </div>
  </div>
</section><section class="news-section">
    <div class="auto-container">
        <div class="sec-title text-center">
            <span class="sub-title">من المدونة</span>
            <h2>أخبار ومقالات</h2>
        </div>

        <div class="row">
            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-1.jpg" alt=""></a></figure>
                        <span class="date"><b>۲۱</b> أكتوبر</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> بواسطة المشرف</li>
                            <li><i class="fa fa-tag"></i> تكنولوجيا</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">خزنة عملك تضمن توفرًا عاليًا</a></h4>
                        <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">اقرأ المزيد <i class="fa fa-long-arrow-alt-left"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> ۰۲</div>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-2.jpg" alt=""></a></figure>
                        <span class="date"><b>۳۱</b> يناير</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> بواسطة المشرف</li>
                            <li><i class="fa fa-tag"></i> تكنولوجيا</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">أفضل ممارسات النسخ الاحتياطي واسترداد البيانات الصغيرة</a></h4>
                        <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">اقرأ المزيد <i class="fa fa-long-arrow-alt-left"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> ۰۲</div>
                    </div>
                </div>
            </div>

            <!-- News Block -->
            <div class="news-block col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="news-details.php"><img src="images/resource/news-3.jpg" alt=""></a></figure>
                        <span class="date"><b>۲۸</b> أكتوبر</span>
                    </div>
                    <div class="content-box">
                        <ul class="post-info">
                            <li><i class="fa fa-user"></i> بواسطة المشرف</li>
                            <li><i class="fa fa-tag"></i> تكنولوجيا</li>
                        </ul>
                        <h4 class="title"><a href="news-details.php">ضع استراتيجية تسويقية لشركتك الصغيرة</a></h4>
                        <div class="text">لكن لا بد أن أوضح لك أن كل هذه الأفكار المغلوطة حول استنكار  النشوة وتمجيد الألم نشأت بالفعل، وسأعرض لك التفاصيل لتكتشف</div>
                    </div>
                    <div class="bottom-box">
                        <a href="news-details.php" class="read-more">اقرأ المزيد <i class="fa fa-long-arrow-alt-left"></i></a>
                        <div class="comments"><i class="fa fa-comments"></i> ۰۲</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="call-to-action-two p-0">
    <div class="auto-container">
        <div class="outer-box wow fadeIn">
            <!-- Image Box -->
            <div class="image-box">
                <figure class="image"><img src="images/resource/image-2.jpg" alt=""></figure>
            </div>
            <!-- Content Box -->
            <div class="content-box">
                <div class="title-box">
                    <h3 class="title">الشغف والمحاولة والمهارة يمكن <br />إنشاء شركة ذات أداء عالي</h3>
                </div>
                <div class="btn-box">
                    <a href="page-about.php" class="theme-btn btn-style-two hvr-light"><span class="btn-title">اكتشف المزيد</span></a>
                </div>
            </div>
        </div>
    </div>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">الرغبة في الحصول على الألم في حد ذاته، لأنه ألم، ولكن في بعض الأحيان الظروف.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">روابط مفيدة</h3>
          <ul class="user-links">
            <li><a href="#">فريق</a></li>
            <li><a href="#">المشاريع</a></li>
            <li><a href="#">شهادة</a></li>
            <li><a href="#">التسعير</a></li>
            <li><a href="#">التعليمات</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">يستكشف</h3>
          <ul class="user-links">
            <li><a href="#">تصور البيانات</a></li>
            <li><a href="#">تصميم واجهة المستخدم وتجربة المستخدم</a></li>
            <li><a href="#">التسويق الرقمي</a></li>
            <li><a href="#">استراتيجية التسويق</a></li>
            <li><a href="#">تحليل البيانات</a></li>
            <li><a href="#">نظام الأمن</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">اتصال</h3>
          <div class="widget-content">
            <div class="text me-lg-4">۶۶ شارع بروكلين رود, ۶۰۰ نيويورك، الولايات المتحدة الأمريكية</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">بحاجة الى مساعدة@شركة.كوم</a><br /></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+۹۲ ۶۶۶ ۸۸۸ ۰۰۰۰</a><br /></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; حقوق الطبع والنشر محفوظة بواسطة <a href="index.php">شركة.كوم</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>  