<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Checkout</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">
<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-one">
    <!-- Header Top -->
    <div class="header-top">
        <div class="inner-container">

            <div class="top-left">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">needhelp@company.com</a></li>
                    <li><i class="fa fa-map-marker"></i> 88 Broklyn Golden Street. New York</li>
                </ul>
            </div>

            <div class="top-right">
                <ul class="useful-links">
                    <li><a href="#">Help</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>

        <div class="outer-box">
            <ul class="social-icon-one">
                <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                <li><a href="#"><span class="fab fa-instagram"></span></a></li>
            </ul>
        </div>
    </div>
    <!-- Header Top -->

    <!-- Header Lower -->
    <div class="header-lower">
        <!-- Main box -->
        <div class="main-box">
            <div class="logo-box">
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo.png" alt="" title="arotech"></a>
                </div>
            </div>

            <!--Nav Box-->
                <nav class="nav main-menu">
                                        <ul class="navigation">
  <li class="current dropdown"><a href="index.php">Home</a>
  <ul>
      <li><a href="index.php">Home Layout 1</a></li>
      <li><a href="index-2.php">Home Layout 2</a></li>
      <li><a href="index-3.php">Home Layout 3</a></li>
      <li class="dropdown"><a href="#">More Home Layouts</a>
        <ul>
          <li><a href="index-4.php">Home Layout 4</a></li>
          <li><a href="index-5.php">Home Layout 5</a></li>
          <li><a href="index-6.php">Home Layout 6</a></li>
          <li><a href="index-7.php">Home Layout 7</a></li>
          <li><a href="index-8.php">Home Layout 8</a></li>
          <li><a href="index-9.php">Home Layout 9</a></li>
          <li><a href="index-10.php">Home Layout 10</a></li>
          <li><a href="index-11.php">Home Layout 11</a></li>
          <li><a href="index-12.php">Home Layout 12</a></li>
          <li><a href="index-13.php">Home Layout 13</a></li>
          <li><a href="index-14.php">Home Layout 14</a></li>
          <li><a href="index-15.php">Home Layout 15</a></li>
          <li><a href="index-16.php">Home Layout 16</a></li>
          <li><a href="index-17.php">Home Layout 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Styles</a>
        <ul>
          <li><a href="index.php">Header Style 1</a></li>
          <li><a href="index-2.php">Header Style 2</a></li>
          <li><a href="index-3.php">Header Style 3</a></li>
          <li><a href="index-4.php">Header Style 4</a></li>
          <li><a href="index-5.php">Header Style 5</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Single</a>
        <ul>
          <li><a href="index-1-single.php">Header Single 1</a></li>
          <li><a href="index-2-single.php">Header Single 2</a></li>
          <li><a href="index-3-single.php">Header Single 3</a></li>
          <li><a href="index-4-single.php">Header Single 4</a></li>
          <li><a href="index-5-single.php">Header Single 5</a></li>
          <li><a href="index-6-single.php">Header Single 6</a></li>
          <li><a href="index-7-single.php">Header Single 7</a></li>
          <li><a href="index-8-single.php">Header Single 8</a></li>
          <li><a href="index-9-single.php">Header Single 9</a></li>
          <li><a href="index-10-single.php">Header Single 10</a></li>
          <li><a href="index-11-single.php">Header Single 11</a></li>
          <li><a href="index-12-single.php">Header Single 12</a></li>
          <li><a href="index-13-single.php">Header Single 13</a></li>
          <li><a href="index-14-single.php">Header Single 14</a></li>
          <li><a href="index-15-single.php">Header Single 15</a></li>
          <li><a href="index-16-single.php">Header Single 16</a></li>
          <li><a href="index-17-single.php">Header Single 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Dark</a>
        <ul>
          <li><a href="index-1-dark.php">Header Dark 1</a></li>
          <li><a href="index-2-dark.php">Header Dark 2</a></li>
          <li><a href="index-3-dark.php">Header Dark 3</a></li>
          <li><a href="index-4-dark.php">Header Dark 4</a></li>
          <li><a href="index-5-dark.php">Header Dark 5</a></li>
          <li><a href="index-6-dark.php">Header Dark 6</a></li>
          <li><a href="index-7-dark.php">Header Dark 7</a></li>
          <li><a href="index-8-dark.php">Header Dark 8</a></li>
          <li><a href="index-9-dark.php">Header Dark 9</a></li>
          <li><a href="index-10-dark.php">Header Dark 10</a></li>
          <li><a href="index-11-dark.php">Header Dark 11</a></li>
          <li><a href="index-12-dark.php">Header Dark 12</a></li>
          <li><a href="index-13-dark.php">Header Dark 13</a></li>
          <li><a href="index-14-dark.php">Header Dark 14</a></li>
          <li><a href="index-15-dark.php">Header Dark 15</a></li>
          <li><a href="index-16-dark.php">Header Dark 16</a></li>
          <li><a href="index-17-dark.php">Header Dark 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Rtl Page</a>
        <ul>
          <li><a href="index-1-rtl.php">Header Rtl</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About</a></li>
      <li class="dropdown"><a href="#">Projects</a>
        <ul>
          <li><a href="page-projects.php">Projects List</a></li>
          <li><a href="page-project-details.php">Project Details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team List</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-testimonial.php">Testimonial</a></li>
      <li><a href="page-pricing.php">Pricing</a></li>
      <li><a href="page-pricing-switcher.php">Pricing Switcher</a></li>
      <li><a href="page-faq.php">FAQ</a></li>
      <li><a href="page-404.php">Page 404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services List</a></li>
      <li><a href="page-service-details.php">Service Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Shop</a>
    <ul>
      <li><a href="shop-products.php">Products</a></li>
      <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
      <li><a href="shop-product-details.php">Product Details</a></li>
      <li><a href="shop-cart.php">Cart</a></li>
      <li><a href="shop-checkout.php">Checkout</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">News</a>
    <ul>
      <li><a href="news-grid.php">News Grid</a></li>
      <li><a href="news-details.php">News Details</a></li>
    </ul>
  </li>
  <li><a href="page-contact.php">Contact</a></li>
</ul>                </nav>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>

        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
            <div class="upper-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="close-btn"><i class="icon fa fa-times"></i></div>
            </div>

            <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
            </ul>
            <ul class="contact-list-one">
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <i class="icon lnr-icon-phone-handset"></i>
                        <span class="title">Call Now</span>
                        <a href="tel:+92880098670">+92 (8800) - 98670</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-envelope1"></span>
                        <span class="title">Send Email</span>
                        <a href="mailto:help@company.com">help@company.com</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-clock"></span>
                        <span class="title">Send Email</span>
                        Mon - Sat 8:00 - 6:30, Sunday - CLOSED
                    </div>
                </li>
            </ul>


            <ul class="social-links">
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->

    <!-- Header Search -->
    <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
            <form method="post" action="index.php">
                <div class="form-group">
                    <input type="search" name="search-field" value="" placeholder="Search..." required="">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
    <!-- End Header Search -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="inner-container">
                <!--Logo-->
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="nav-outer">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->

                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div><!-- End Sticky Menu -->
</header><!-- Start main-content -->
<section class="page-title" style="background-image: url(images/background/page-title.jpg);">
    <div class="auto-container">
        <div class="title-outer text-center">
            <h1 class="title">Checkout</h1>
            <ul class="page-breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li>Shop</li>
            </ul>
        </div>
    </div>
</section>
<!-- end main-content -->



<!--checkout Start-->
<section>
<div class="container pt-70">
	<div class="section-content">
	<form id="checkout-form" action="#">
		<div class="row mt-30">
		<div class="col-md-6">
			<div class="billing-details">
			<h3 class="mb-30">Billing Details</h3>
			<div class="row">
				<div class="mb-3 col-md-6">
				<label for="checkuot-form-fname">First Name</label>
				<input id="checkuot-form-fname" type="email" class="form-control" placeholder="First Name">
				</div>
				<div class="mb-3 col-md-6">
				<label for="checkuot-form-lname">Last Name</label>
				<input id="checkuot-form-lname" type="email" class="form-control" placeholder="Last Name">
				</div>
				<div class="col-md-12">
				<div class="mb-3">
					<label for="checkuot-form-cname">Company Name</label>
					<input id="checkuot-form-cname" type="email" class="form-control" placeholder="Company Name">
				</div>
				<div class="mb-3">
					<label for="checkuot-form-email">Email Address</label>
					<input id="checkuot-form-email" type="email" class="form-control" placeholder="Email Address">
				</div>
				<div class="mb-3">
					<label for="checkuot-form-address">Address</label>
					<input id="checkuot-form-address" type="email" class="form-control" placeholder="Street address">
				</div>
				<div class="mb-3">
					<input type="email" class="form-control" placeholder="Apartment, suite, unit etc. (optional)">
				</div>
				</div>
				<div class="mb-3 col-md-6">
				<label for="checkuot-form-city">City</label>
				<input id="checkuot-form-city" type="email" class="form-control" placeholder="City">
				</div>
				<div class="mb-3 col-md-6">
				<label>State/Province</label>
				<select class="form-control">
					<option>Select Country</option>
					<option>Australia</option>
					<option>UK</option>
					<option>USA</option>
				</select>
				</div>
				<div class="mb-3 col-md-6">
				<label for="checkuot-form-zip">Zip/Postal Code</label>
				<input id="checkuot-form-zip" type="email" class="form-control" placeholder="Zip/Postal Code">
				</div>
				<div class="mb-3 col-md-6">
				<label>Country</label>
				<select class="form-control">
					<option>Select Country</option>
					<option>Australia</option>
					<option>UK</option>
					<option>USA</option>
				</select>
				</div>
			</div>
			</div>
		</div>
		<div class="col-md-6">
			<h3>Additional information</h3>
			<label for="order_comments" class="">Order notes&nbsp;<span class="optional">(optional)</span></label>
			<textarea id="order_comments" class="form-control" placeholder="Notes about your order, e.g. special notes for delivery." rows="3"></textarea>
		</div>
		<div class="col-md-12 mt-30">
			<h3>Your order</h3>
			<table class="table table-striped table-bordered tbl-shopping-cart">
			<thead>
				<tr>
				<th>Photo</th>
				<th>Product Name</th>
				<th>Total</th>
				</tr>
			</thead>
			<tbody>
				<tr>
				<td class="product-thumbnail"><a href="shop-product-details.php"><img alt="product" src="images/resource/products/1.jpg"></a></td>
				<td class="product-name"><a href="shop-product-details.php">Headphone</a> x 2</td>
				<td><span class="amount">$36.00</span></td>
				</tr>
				<tr>
				<td class="product-thumbnail"><a href="shop-product-details.php"><img alt="product" src="images/resource/products/2.jpg"></a></td>
				<td class="product-name"><a href="shop-product-details.php">Lagage</a> x 3</td>
				<td><span class="amount">$115.00</span></td>
				</tr>
				<tr>
				<td class="product-thumbnail"><a href="shop-product-details.php"><img alt="product" src="images/resource/products/3.jpg"></a></td>
				<td class="product-name"><a href="shop-product-details.php">Watch</a> x 1</td>
				<td><span class="amount">$68.00</span></td>
				</tr>
				<tr>
				<td>Cart Subtotal</td>
				<td>&nbsp;</td>
				<td>$180.00</td>
				</tr>
				<tr>
				<td>Shipping and Handling</td>
				<td>&nbsp;</td>
				<td>Free Shipping</td>
				</tr>
				<tr>
				<td>Order Total</td>
				<td>&nbsp;</td>
				<td>$250.00</td>
				</tr>
			</tbody>
			</table>
		</div>
		<div class="col-md-12 mt-60">
			<div class="payment-method">
				<h3>Choose a Payment Method</h3>
				<ul class="accordion-box">
					<li class="accordion block active-block">
						<div class="acc-btn active">
							<div class="icon-outer"><i class="lnr-icon-chevron-down"></i></div>
							Credir Card / Debit Card
						</div>
						<div class="acc-content current">
							<div class="payment-info">
								<div class="row clearfix">
									<div class="col-lg-6 col-md-6 col-sm-12 column">
										<div class="field-input mb-3">
											<input type="text" class="form-control" name="name" placeholder="Name on the Card" required="">
										</div>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-12 column">
										<div class="field-input mb-3">
											<input type="text" class="form-control" name="number" placeholder="Card Number" required="">
										</div>
									</div>
									<div class="col-lg-3 col-md-6 col-sm-12 column">
										<div class="field-input mb-3">
											<input type="text" class="form-control" name="date" placeholder="Expiry Date" required="">
										</div>
									</div>
									<div class="col-lg-3 col-md-6 col-sm-12 column">
										<div class="field-input mb-3">
											<input type="text" class="form-control" name="code" placeholder="Security Code" required="">
										</div>
									</div>
									<div class="col-lg-6 col-md-12 col-sm-12 column">
										<div class="field-input message-btn">
											<button type="submit" class="theme-btn btn-style-one" data-loading-text="Please wait..."><span class="btn-title">Make Payment</span></button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="accordion block">
						<div class="acc-btn">
							<div class="icon-outer"><i class="lnr-icon-chevron-down"></i></div>
							Direct Bank Transfer
						</div>
						<div class="acc-content">
							<div class="payment-info">
								<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
							</div>
						</div>
					</li>
					<li class="accordion block">
							<div class="acc-btn">
							<div class="icon-outer"><i class="lnr-icon-chevron-down"></i></div>
							Cheque Payment
						</div>
						<div class="acc-content">
							<div class="payment-info">
								<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
							</div>
						</div>
					</li>
					<li class="accordion block">
							<div class="acc-btn">
							<div class="icon-outer"><i class="lnr-icon-chevron-down"></i></div>
							Other Payment
						</div>
						<div class="acc-content">
							<div class="payment-info">
								<p class="mb-0">Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have cleared in our account.</p>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
		</div>
	</form>
	</div>
</div>
</section>
<!--checkout Start-->
	<!-- Main Footer -->
	<footer class="main-footer">
		<div class="bg-image"  style="background-image: url(./images/background/2.jpg)"></div>

		<!--Widgets Section-->
		<div class="widgets-section">
			<div class="auto-container">
				<div class="row">
					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
						<div class="footer-widget about-widget">
							<div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
							<div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
							<ul class="social-icon-two">
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-facebook"></i></a></li>
								<li><a href="#"><i class="fab fa-pinterest"></i></a></li>
								<li><a href="#"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</div>
					</div>

					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
						<div class="footer-widget">
							<h3 class="widget-title">Explore</h3>
							<ul class="user-links">
								<li><a href="#">About Company</a></li>
								<li><a href="#">Meet the Team</a></li>
								<li><a href="#">News & Media</a></li>
								<li><a href="#">Our Projects</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>

					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
						<div class="footer-widget contact-widget">
							<h3 class="widget-title">Contact</h3>
							<div class="widget-content">
								<div class="text">66 Road Broklyn Street, 600 New York, USA</div>
								<ul class="contact-info">
									<li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
									<li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
								</ul>
							</div>
						</div>
					</div>

					<!--Footer Column-->
					<div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
						<div class="footer-widget gallery-widget">
							<h3 class="widget-title">Gallery</h3>
							<div class="widget-content">
								<div class="outer clearfix">
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-1.jpg" alt=""></a>
									</figure>
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-2.jpg" alt=""></a>
									</figure>
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-3.jpg" alt=""></a>
									</figure>
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-4.jpg" alt=""></a>
									</figure>
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-5.jpg" alt=""></a>
									</figure>
									<figure class="image">
										<a href="#"><img src="images/resource/project-thumb-6.jpg" alt=""></a>
									</figure>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

		<!--Footer Bottom-->
		<div class="footer-bottom">
			<div class="auto-container">
				<div class="inner-container">
					<div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
					</div>


				</div>
			</div>
		</div>
	</footer>
	<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>