
<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
<title>Arotech | IT Solutions & Technology PHP Template | Home Page 14</title>
<!-- Stylesheets -->
<link href="css/bootstrap.min.css" rel="stylesheet">


<link href="css/style.css" rel="stylesheet">

<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="icon" href="images/favicon.png" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="js/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body
>
<div class="page-wrapper">
<!-- Preloader -->
<!-- Preloader -->
<div class="preloader"></div> 

<header id="home" class="main-header header-style-two style-two">
    <!-- Header Top -->
    <div class="header-top">
        <div class="inner-container">

            <div class="top-left">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fas fa-map-marker-alt"></i> 	121 King Street, Melbourne</li>
                </ul>
                <div class="outer-box">
                    <ul class="social-icon-one">
                        <li><a href="#"><span class="fab fa-x-twitter"></span></a></li>
                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                    </ul>
                </div>
            </div>

            <div class="top-right">
                <!-- Info List -->
                <ul class="list-style-one">
                    <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@company.com">	help@company.com</a></li>
                    <li><i class="fas fa-clock"></i> Mon - Sat 8:00 - 6:30, Sunday - CLOSED</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Header Top -->

    <!-- Header Lower -->
    <div class="header-lower">
        <!-- Main box -->
        <div class="main-box">
            <div class="logo-box">
                <div class="logo">
                                <a href="index.php" title=""><img src="images/logo-3.png" alt="" title="arotech"></a>
                </div>
            </div>

            <!--Nav Box-->
            <div class="nav-outer">

                <nav class="nav main-menu">
                                        <ul class="navigation">
  <li class="current dropdown"><a href="index.php">Home</a>
  <ul>
      <li><a href="index.php">Home Layout 1</a></li>
      <li><a href="index-2.php">Home Layout 2</a></li>
      <li><a href="index-3.php">Home Layout 3</a></li>
      <li class="dropdown"><a href="#">More Home Layouts</a>
        <ul>
          <li><a href="index-4.php">Home Layout 4</a></li>
          <li><a href="index-5.php">Home Layout 5</a></li>
          <li><a href="index-6.php">Home Layout 6</a></li>
          <li><a href="index-7.php">Home Layout 7</a></li>
          <li><a href="index-8.php">Home Layout 8</a></li>
          <li><a href="index-9.php">Home Layout 9</a></li>
          <li><a href="index-10.php">Home Layout 10</a></li>
          <li><a href="index-11.php">Home Layout 11</a></li>
          <li><a href="index-12.php">Home Layout 12</a></li>
          <li><a href="index-13.php">Home Layout 13</a></li>
          <li><a href="index-14.php">Home Layout 14</a></li>
          <li><a href="index-15.php">Home Layout 15</a></li>
          <li><a href="index-16.php">Home Layout 16</a></li>
          <li><a href="index-17.php">Home Layout 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Styles</a>
        <ul>
          <li><a href="index.php">Header Style 1</a></li>
          <li><a href="index-2.php">Header Style 2</a></li>
          <li><a href="index-3.php">Header Style 3</a></li>
          <li><a href="index-4.php">Header Style 4</a></li>
          <li><a href="index-5.php">Header Style 5</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Single</a>
        <ul>
          <li><a href="index-1-single.php">Header Single 1</a></li>
          <li><a href="index-2-single.php">Header Single 2</a></li>
          <li><a href="index-3-single.php">Header Single 3</a></li>
          <li><a href="index-4-single.php">Header Single 4</a></li>
          <li><a href="index-5-single.php">Header Single 5</a></li>
          <li><a href="index-6-single.php">Header Single 6</a></li>
          <li><a href="index-7-single.php">Header Single 7</a></li>
          <li><a href="index-8-single.php">Header Single 8</a></li>
          <li><a href="index-9-single.php">Header Single 9</a></li>
          <li><a href="index-10-single.php">Header Single 10</a></li>
          <li><a href="index-11-single.php">Header Single 11</a></li>
          <li><a href="index-12-single.php">Header Single 12</a></li>
          <li><a href="index-13-single.php">Header Single 13</a></li>
          <li><a href="index-14-single.php">Header Single 14</a></li>
          <li><a href="index-15-single.php">Header Single 15</a></li>
          <li><a href="index-16-single.php">Header Single 16</a></li>
          <li><a href="index-17-single.php">Header Single 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Dark</a>
        <ul>
          <li><a href="index-1-dark.php">Header Dark 1</a></li>
          <li><a href="index-2-dark.php">Header Dark 2</a></li>
          <li><a href="index-3-dark.php">Header Dark 3</a></li>
          <li><a href="index-4-dark.php">Header Dark 4</a></li>
          <li><a href="index-5-dark.php">Header Dark 5</a></li>
          <li><a href="index-6-dark.php">Header Dark 6</a></li>
          <li><a href="index-7-dark.php">Header Dark 7</a></li>
          <li><a href="index-8-dark.php">Header Dark 8</a></li>
          <li><a href="index-9-dark.php">Header Dark 9</a></li>
          <li><a href="index-10-dark.php">Header Dark 10</a></li>
          <li><a href="index-11-dark.php">Header Dark 11</a></li>
          <li><a href="index-12-dark.php">Header Dark 12</a></li>
          <li><a href="index-13-dark.php">Header Dark 13</a></li>
          <li><a href="index-14-dark.php">Header Dark 14</a></li>
          <li><a href="index-15-dark.php">Header Dark 15</a></li>
          <li><a href="index-16-dark.php">Header Dark 16</a></li>
          <li><a href="index-17-dark.php">Header Dark 17</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Header Rtl Page</a>
        <ul>
          <li><a href="index-1-rtl.php">Header Rtl</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Pages</a>
    <ul>
      <li><a href="page-about.php">About</a></li>
      <li class="dropdown"><a href="#">Projects</a>
        <ul>
          <li><a href="page-projects.php">Projects List</a></li>
          <li><a href="page-project-details.php">Project Details</a></li>
        </ul>
      </li>
      <li class="dropdown"><a href="#">Team</a>
        <ul>
          <li><a href="page-team.php">Team List</a></li>
          <li><a href="page-team-details.php">Team Details</a></li>
        </ul>
      </li>
      <li><a href="page-testimonial.php">Testimonial</a></li>
      <li><a href="page-pricing.php">Pricing</a></li>
      <li><a href="page-pricing-switcher.php">Pricing Switcher</a></li>
      <li><a href="page-faq.php">FAQ</a></li>
      <li><a href="page-404.php">Page 404</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Services</a>
    <ul>
      <li><a href="page-services.php">Services List</a></li>
      <li><a href="page-service-details.php">Service Details</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">Shop</a>
    <ul>
      <li><a href="shop-products.php">Products</a></li>
      <li><a href="shop-products-sidebar.php">Products with Sidebar</a></li>
      <li><a href="shop-product-details.php">Product Details</a></li>
      <li><a href="shop-cart.php">Cart</a></li>
      <li><a href="shop-checkout.php">Checkout</a></li>
    </ul>
  </li>
  <li class="dropdown"><a href="#">News</a>
    <ul>
      <li><a href="news-grid.php">News Grid</a></li>
      <li><a href="news-details.php">News Details</a></li>
    </ul>
  </li>
  <li><a href="page-contact.php">Contact</a></li>
</ul>                </nav>
                <!-- Main Menu End-->


                <div class="outer-box">
                    <div class="ui-btn-outer">
                        <button class="ui-btn ui-btn search-btn">
                            <span class="icon lnr lnr-icon-search"></span>
                        </button>
                    </div>


                    <a href="tel:+92(8800)9806" class="info-btn-two">
                        <i class="icon fa fa-phone"></i>
                        <small>Call Anytime</small><br> +88 017 500 500 88
                    </a>

                    <!-- Mobile Nav toggler -->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Lower -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>

        <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
        <nav class="menu-box">
            <div class="upper-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="close-btn"><i class="icon fa fa-times"></i></div>
            </div>

            <ul class="navigation clearfix">
                <!--Keep This Empty / Menu will come through Javascript-->
            </ul>
            <ul class="contact-list-one">
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <i class="icon lnr-icon-phone-handset"></i>
                        <span class="title">Call Now</span>
                        <a href="tel:+92880098670">+92 (8800) - 98670</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-envelope1"></span>
                        <span class="title">Send Email</span>
                        <a href="mailto:help@company.com">help@company.com</a>
                    </div>
                </li>
                <li>
                    <!-- Contact Info Box -->
                    <div class="contact-info-box">
                        <span class="icon lnr-icon-clock"></span>
                        <span class="title">Send Email</span>
                        Mon - Sat 8:00 - 6:30, Sunday - CLOSED
                    </div>
                </li>
            </ul>


            <ul class="social-links">
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </nav>
    </div><!-- End Mobile Menu -->

    <!-- Header Search -->
    <div class="search-popup">
        <span class="search-back-drop"></span>
        <button class="close-search"><span class="fa fa-times"></span></button>

        <div class="search-inner">
            <form method="post" action="index.php">
                <div class="form-group">
                    <input type="search" name="search-field" value="" placeholder="Search..." required="">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </div>
            </form>
        </div>
    </div>
    <!-- End Header Search -->

    <!-- Sticky Header  -->
    <div class="sticky-header">
        <div class="auto-container">
            <div class="inner-container">
                <!--Logo-->
                <div class="logo">
                                        <a href="index.php" title=""><img src="images/logo-2.png" alt="" title=""></a>
                </div>

                <!--Right Col-->
                <div class="nav-outer">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->

                    <!--Mobile Navigation Toggler-->
                    <div class="mobile-nav-toggler"><span class="icon lnr-icon-bars"></span></div>
                </div>
            </div>
        </div>
    </div><!-- End Sticky Menu -->
</header><section class="banner-section-thirteen">
    <div class="banner-carousel owl-carousel owl-theme">
        <!-- Slide Item -->
        <div class="slide-item">
            <div class="bg-image" style="background-image: url(images/main-slider/slider14.jpg);"></div>
            <div class="shape-image1">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 283.5 27.8" preserveAspectRatio="none">
                    <path class="elementor-shape-fill" d="M283.5,9.7c0,0-7.3,4.3-14,4.6c-6.8,0.3-12.6,0-20.9-1.5c-11.3-2-33.1-10.1-44.7-5.7	s-12.1,4.6-18,7.4c-6.6,3.2-20,9.6-36.6,9.3C131.6,23.5,99.5,7.2,86.3,8c-1.4,0.1-6.6,0.8-10.5,2c-3.8,1.2-9.4,3.8-17,4.7	c-3.2,0.4-8.3,1.1-14.2,0.9c-1.5-0.1-6.3-0.4-12-1.6c-5.7-1.2-11-3.1-15.8-3.7C6.5,9.2,0,10.8,0,10.8V0h283.5V9.7z M260.8,11.3	c-0.7-1-2-0.4-4.3-0.4c-2.3,0-6.1-1.2-5.8-1.1c0.3,0.1,3.1,1.5,6,1.9C259.7,12.2,261.4,12.3,260.8,11.3z M242.4,8.6	c0,0-2.4-0.2-5.6-0.9c-3.2-0.8-10.3-2.8-15.1-3.5c-8.2-1.1-15.8,0-15.1,0.1c0.8,0.1,9.6-0.6,17.6,1.1c3.3,0.7,9.3,2.2,12.4,2.7	C239.9,8.7,242.4,8.6,242.4,8.6z M185.2,8.5c1.7-0.7-13.3,4.7-18.5,6.1c-2.1,0.6-6.2,1.6-10,2c-3.9,0.4-8.9,0.4-8.8,0.5	c0,0.2,5.8,0.8,11.2,0c5.4-0.8,5.2-1.1,7.6-1.6C170.5,14.7,183.5,9.2,185.2,8.5z M199.1,6.9c0.2,0-0.8-0.4-4.8,1.1	c-4,1.5-6.7,3.5-6.9,3.7c-0.2,0.1,3.5-1.8,6.6-3C197,7.5,199,6.9,199.1,6.9z M283,6c-0.1,0.1-1.9,1.1-4.8,2.5s-6.9,2.8-6.7,2.7	c0.2,0,3.5-0.6,7.4-2.5C282.8,6.8,283.1,5.9,283,6z M31.3,11.6c0.1-0.2-1.9-0.2-4.5-1.2s-5.4-1.6-7.8-2C15,7.6,7.3,8.5,7.7,8.6	C8,8.7,15.9,8.3,20.2,9.3c2.2,0.5,2.4,0.5,5.7,1.6S31.2,11.9,31.3,11.6z M73,9.2c0.4-0.1,3.5-1.6,8.4-2.6c4.9-1.1,8.9-0.5,8.9-0.8	c0-0.3-1-0.9-6.2-0.3S72.6,9.3,73,9.2z M71.6,6.7C71.8,6.8,75,5.4,77.3,5c2.3-0.3,1.9-0.5,1.9-0.6c0-0.1-1.1-0.2-2.7,0.2	C74.8,5.1,71.4,6.6,71.6,6.7z M93.6,4.4c0.1,0.2,3.5,0.8,5.6,1.8c2.1,1,1.8,0.6,1.9,0.5c0.1-0.1-0.8-0.8-2.4-1.3	C97.1,4.8,93.5,4.2,93.6,4.4z M65.4,11.1c-0.1,0.3,0.3,0.5,1.9-0.2s2.6-1.3,2.2-1.2s-0.9,0.4-2.5,0.8C65.3,10.9,65.5,10.8,65.4,11.1	z M34.5,12.4c-0.2,0,2.1,0.8,3.3,0.9c1.2,0.1,2,0.1,2-0.2c0-0.3-0.1-0.5-1.6-0.4C36.6,12.8,34.7,12.4,34.5,12.4z M152.2,21.1	c-0.1,0.1-2.4-0.3-7.5-0.3c-5,0-13.6-2.4-17.2-3.5c-3.6-1.1,10,3.9,16.5,4.1C150.5,21.6,152.3,21,152.2,21.1z"></path>
                    <path class="elementor-shape-fill" d="M269.6,18c-0.1-0.1-4.6,0.3-7.2,0c-7.3-0.7-17-3.2-16.6-2.9c0.4,0.3,13.7,3.1,17,3.3	C267.7,18.8,269.7,18,269.6,18z"></path>
                    <path class="elementor-shape-fill" d="M227.4,9.8c-0.2-0.1-4.5-1-9.5-1.2c-5-0.2-12.7,0.6-12.3,0.5c0.3-0.1,5.9-1.8,13.3-1.2	S227.6,9.9,227.4,9.8z"></path>
                    <path class="elementor-shape-fill" d="M204.5,13.4c-0.1-0.1,2-1,3.2-1.1c1.2-0.1,2,0,2,0.3c0,0.3-0.1,0.5-1.6,0.4	C206.4,12.9,204.6,13.5,204.5,13.4z"></path>
                    <path class="elementor-shape-fill" d="M201,10.6c0-0.1-4.4,1.2-6.3,2.2c-1.9,0.9-6.2,3.1-6.1,3.1c0.1,0.1,4.2-1.6,6.3-2.6	S201,10.7,201,10.6z"></path>
                    <path class="elementor-shape-fill" d="M154.5,26.7c-0.1-0.1-4.6,0.3-7.2,0c-7.3-0.7-17-3.2-16.6-2.9c0.4,0.3,13.7,3.1,17,3.3	C152.6,27.5,154.6,26.8,154.5,26.7z"></path>
                    <path class="elementor-shape-fill" d="M41.9,19.3c0,0,1.2-0.3,2.9-0.1c1.7,0.2,5.8,0.9,8.2,0.7c4.2-0.4,7.4-2.7,7-2.6	c-0.4,0-4.3,2.2-8.6,1.9c-1.8-0.1-5.1-0.5-6.7-0.4S41.9,19.3,41.9,19.3z"></path>
                    <path class="elementor-shape-fill" d="M75.5,12.6c0.2,0.1,2-0.8,4.3-1.1c2.3-0.2,2.1-0.3,2.1-0.5c0-0.1-1.8-0.4-3.4,0	C76.9,11.5,75.3,12.5,75.5,12.6z"></path>
                    <path class="elementor-shape-fill" d="M15.6,13.2c0-0.1,4.3,0,6.7,0.5c2.4,0.5,5,1.9,5,2c0,0.1-2.7-0.8-5.1-1.4	C19.9,13.7,15.7,13.3,15.6,13.2z"></path>
                    </svg>
            </div>
            <div class="auto-container">
                <div class="outer-box">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="content-box">
                                <h1 class="title animate-1">The Leading Provider of IT Solutions</h1>
                                <div class="text animate-2">When your audience visits your website, it gives them their first impression of your business. They will judge your business within seconds.</div>
                                <div class="btn-box animate-3">
                                    <a href="page-about.php" class="theme-btn btn-style-four"><span class="btn-title">Explore now</span></a>
                                </div>
                            </div>
                        </div>
                        <!-- Form Column -->
                        <div class="form-column col-lg-6">
                            <div class="inner-column">
                                <!-- Contact Form -->
                                <div class="contact-form wow fadeInLeft">
                                    <h6 class="sub-title">Contact us</h6>
                                    <h3 class="title">Make an Appointment</h3>

                                    <!--Contact Form-->
                                    <form id="contact_form" name="contact_form" action="includes/sendmail.php" method="post">
                                        <div class="row gx-3">
                                            <div class="form-group col-lg-12">
                                                <input name="form_name" class="form-control" id="name" placeholder="Name" type="text">
                                            </div>

                                            <div class="form-group col-lg-12">
                                                <input name="form_email" class="form-control required" id="email" placeholder="E-mail address" type="email">
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <input type="text" name="form_subject" placeholder="Subject" required>
                                            </div>

                                            <div class="form-group col-lg-6">
                                                <input type="text" name="form_phone" placeholder="Phone (Optional)">
                                            </div>

                                            <div class="form-group col-lg-12">
                                               <textarea name="form_message" class="form-control required" placeholder="Write a Message" id="message"></textarea>
                                            </div>

                                            <div class="form-group col-lg-12">
                                                <button class="theme-btn btn-style-four bg-drk" type="submit" name="submit-form" data-loading-text="Please wait..."><span class="btn-title">Send a Message</span></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!--End Contact Form -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="features-section-six style-two">
	<div class="auto-container">
		<div class="row">
			<!-- Feature Block Six -->
			<div class="feature-block-six col-lg-4 col-md-6 col-sm-12">
				<div class="inner-box ">
					<span class="icon flaticon-business-054-graph"></span>
					<span class="icon">46+</span>
					<h4 class="title"><a href="#">Internet & Cyber Security <br>Solutions</a></h4>
					<a href="page-services.php" class="theme-btn btn-style-two small hvr-light"><span class="btn-title">Find Your Solution</span></a>
				</div>
			</div>

			<!-- Feature Block Six -->
			<div class="feature-block-six col-lg-4 hide-md ">
				<div class="inner-box ">
					<figure class="image"><img src="images/resource/feature-bg-6.jpg" alt=""></figure>
				</div>
			</div>

			<!-- Feature Block Six -->
			<div class="feature-block-six col-lg-4 col-md-6 col-sm-12">
				<div class="inner-box ">
					<span class="icon flaticon-business-054-graph"></span>
					<span class="icon">76+</span>
					<h4 class="title"><a href="#">Expert IT Consultants <br>Available</a></h4>
					<a href="page-team.php" class="theme-btn btn-style-two small hvr-light"><span class="btn-title">Find Your Solution</span></a>
				</div>
			</div>
		</div>
	</div>
</section><section id="about" class="about-section-eleven style-two">
  <div class="auto-container">
    <div class="row">
      <div class="content-column col-xl-6 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
        <div class="inner-column">
          <div class="sec-title">
            <span class="sub-title">Welcome to Tech</span>
            <h2>We Bring Our Ideas to Life from Start to Finish</h2>
            <div class="text">Lorem ipsum dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et simply free text dolore magna aliqua lonm andhn personal touch</div>
          </div>

          <div class="row">
            <div class="info-box col-lg-6 col-md-6">
              <div class="inner">
                <i class="icon flaticon-business-054-graph"></i>
                <h5 class="title">Manage Tech <br>Services</h5>
              </div>
            </div>

            <div class="info-box col-lg-6 col-md-6">
              <div class="inner">
                <i class="icon flaticon-business-020-hierarchy"></i>
                <h5 class="title">Software IT <br>Outsource</h5>
              </div>
            </div>
          </div>

          <ul class="list-style-two">
            <li><i class="fa fa-check-circle"></i> Refresing to get such a personal touch</li>
            <li><i class="fa fa-check-circle"></i> Duis aute irure dolor in reprehenderit in voluptate.</li>
            <li><i class="fa fa-check-circle"></i> Velit esse cillum dolore eu fugiat nulla pariatur.</li>
          </ul>

          <a href="page-about.php" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Discover More</span></a>
        </div>
      </div>

      <!-- Image Column -->
      <div class="image-column col-xl-6 col-lg-5 col-md-12 col-sm-12">
        <div class="inner-column wow fadeInLeft">
          <span class="bg-shpe-1 bounce-y"></span>
          <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/about19-1.png" alt=""></figure>
          <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/about19-2.jpg" alt=""></figure>
        </div>
      </div>
    </div>
  </div>
</section><section class="features-section-nine style-two">
    <div class="auto-container">
        <div class="sec-title light">
                <div class="row">
                    <div class="col-lg-7">
                        <span class="sub-title">Our Service</span>
                        <h2>Explore what services <br>we’re offering</h2>
                    </div>
                    <div class="col-lg-5">
                        <div class="text">There are many variations of passages of available but majority have suffered alteration in some form, by humou or randomised words which don't look even slightly believable.</div>
                    </div>
                </div>
            </div>
        <div class="row"> 
        <!-- Feature Block -->
        <div class="feature-block-nine col-xl-3 col-sm-6 wow fadeInUp">
            <div class="inner-box">
            <div class="image-box">
                <figure class="image"><img src="images/resource/feature2-1.jpg" alt="Image"></figure>
            </div>
            <div class="caption-box"> <i class="icon flaticon-business-002-graph"></i>
                <h4 class="title"><span>Web <br>Development</span></h4>
            </div>
            </div>
        </div>
        <!-- Feature Block -->
        <div class="feature-block-nine col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
            <div class="inner-box">
            <div class="image-box">
                <figure class="image"><img src="images/resource/feature2-2.jpg" alt="Image"></figure>
            </div>
            <div class="caption-box"> <i class="icon flaticon-business-049-presentation"></i>
                <h4 class="title"><span>UI/UX <br>Designing</span></h4>
            </div>
            </div>
        </div>
        <!-- Feature Block -->
        <div class="feature-block-nine col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
            <div class="inner-box">
            <div class="image-box">
                <figure class="image"><img src="images/resource/feature2-3.jpg" alt="Image"></figure>
            </div>
            <div class="caption-box"> <i class="icon flaticon-business-020-hierarchy"></i>
                <h4 class="title"><span>Digital <br>marketing</span></h4>
            </div>
            </div>
        </div>
        <!-- Feature Block -->
        <div class="feature-block-nine col-xl-3 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
            <div class="inner-box">
            <div class="image-box">
                <figure class="image"><img src="images/resource/feature2-4.jpg" alt="Image"></figure>
            </div>
            <div class="caption-box"> <i class="icon flaticon-business-048-coin"></i>
                <h4 class="title"><span>Mobile <br>application</span></h4>
            </div>
            </div>
        </div>
        </div>
    </div>
</section><section id="project" class="project-section style-four pt-0 pb-0">
    <div class="carousel-outer-two">
        <!-- Prject Carousel -->
        <div class="project-carousel-four owl-carousel owl-theme">
            <!-- Project Block -->
            <div class="project-block">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="images/resource/project4-1.jpg" class="lightbox-image"><img src="images/resource/project4-1.jpg" alt=""></a></figure>
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-project-details.php">Tech Solutions</a></h4>
                        <span class="cat">DESIGN / IDEAS</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="images/resource/project4-2.jpg" class="lightbox-image"><img src="images/resource/project4-2.jpg" alt=""></a></figure>
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-project-details.php">Smart Visions</a></h4>
                        <span class="cat">DESIGN / IDEAS</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="images/resource/project4-3.jpg" class="lightbox-image"><img src="images/resource/project4-3.jpg" alt=""></a></figure>
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-project-details.php">Platform Integration</a></h4>
                        <span class="cat">DESIGN / IDEAS</span>
                    </div>
                </div>
            </div>

            <!-- Project Block -->
            <div class="project-block">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="images/resource/project4-4.jpg" class="lightbox-image"><img src="images/resource/project4-4.jpg" alt=""></a></figure>
                        <a href="page-project-details.php" class="icon"><i class="fa fa-long-arrow-alt-right"></i></a>
                    </div>
                    <div class="content-box">
                        <h4 class="title"><a href="page-project-details.php">Web Development</a></h4>
                        <span class="cat">DESIGN / IDEAS</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><div class="marquee-section style-two mt-2">
    <div class="marquee">
        <div class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
                            
        <div aria-hidden="true" class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
    </div>
</div><section class="why-choose-us-four">
    <div class="auto-container">
        <div class="row">
            <div class="content-column col-xl-7 col-lg-7 col-md-12 col-sm-12 order-2 wow fadeInRight" data-wow-delay="600ms">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="sub-title">Company Benefits</span>
                        <h2>Why Should You Choose Our Agency?</h2>
                        <h3>Proin are many variations passages of available.</h3>
                        <div class="text">There are many variations of passages of available but the majority have suffered. Alteration in some form, lipsum is simply free text by injected humou or randomised words. variations of passages of available</div>
                    </div>

                    <blockquote class="blockquote-style-one">Lorem ipsum dolor sit amet, consectetur notted dipisicing elit sed do eiusmod consectetur notted dipisicing elit</blockquote>

                    <div class="btn-box">
                        <a href="page-about" class="theme-btn btn-style-one hvr-dark"><span class="btn-title">Explore Now</span></a>
                    </div>
                </div>
            </div>

            <!-- Image Column -->
            <div class="image-column col-xl-5 col-lg-5 col-md-12 col-sm-12">
                <div class="inner-column wow fadeInLeft">
                    <div class="image-box">
                        <span class="bg-shape"></span>
                        <figure class="image-1 overlay-anim wow fadeInUp"><img src="images/resource/why-us4-1.png" alt=""></figure>
                        <figure class="image-2 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-2.png" alt=""></figure>
                        <figure class="image-3 overlay-anim wow fadeInRight"><img src="images/resource/why-us4-3.jpg" alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><div class="marquee-section">
    <div class="marquee">
        <div class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
                            
        <div aria-hidden="true" class="marquee-group">
            <div class="text">Transofrm ideas into reality</div>
            <div class="text">INSPIRED WITH CREATIVITY</div>
            <div class="text">Design & development craft</div>
            <div class="text">unlock the potential</div>
            <div class="text">Transofrm ideas into reality</div>
        </div>
    </div>
</div><section class="fun-fact-section-four style-two" style="background-image: url(./images/icons/pattern-42.png)">
    <div class="auto-container">
        <div class="sec-title light">
            <div class="inner">
                <span class="sub-title">Tech Management</span>
                <h2>We’re Standout Experts <br>in the Business</h2>
            </div>
            <img class="title-image1" src="images/resource/image-15.jpg" alt="">
        </div>
        <div class="fact-counter">
            <div class="row">
                <!-- Counter block-->
                <div class="counter-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
                    <div class="inner">
                        <i class="icon flaticon-business-060-graph"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="1253">0</span></div>
                        <span class="counter-title">Project Complete</span>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
                    <div class="inner">
                        <i class="icon flaticon-business-035-helpline"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="179">0</span></div>
                        <span class="counter-title">Satisfied Customers</span>
                    </div>
                </div>

                <!--Counter block-->
                <div class="counter-block-five col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="600ms">
                    <div class="inner">
                        <i class="icon flaticon-business-020-hierarchy"></i>
                        <div class="count-box"><span class="count-text" data-speed="3000" data-stop="473">0</span></div>
                        <span class="counter-title">Expert Team Members</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section class="video-section-five pb-0">
    <div class="auto-container">
        <div class="video-box">
            <div class="bg bg-image" style="background-image: url(./images/resource/image-18.png)"></div>
            <div class="content">
                <div class="btn-box">
                    <a href="https://www.youtube.com/watch?v=Fvae8nxzVz4" class="play-now" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i><span class="ripple"></span></a>
                </div>
            </div>
        </div>
    </div>
</section><section class="faqs-section style-four">
    <div class="bg-image" style="background-image: url(./images/background/bg-faq1.jpg)"></div>
    <div class="auto-container">
        <div class="row">
            <!-- FAQ Column -->
            <div class="faq-column col-lg-6 col-md-12 col-sm-12 order-4">
                <div class="inner-column">

                    <ul class="accordion-box wow fadeInRight">
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">Is my technology allowed on tech?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo
                                        injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block active-block">
                            <div class="acc-btn active">How to soft launch your business?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content current">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How to turn visitors into contributors
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                        <!--Block-->
                        <li class="accordion block">
                            <div class="acc-btn">How can i find my solutions?
                                <div class="icon fa fa-plus"></div>
                            </div>
                            <div class="acc-content">
                                <div class="content">
                                    <div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Content Column -->
            <div class="content-column col-xl-6 col-lg-6 col-md-12">
                <div class="inner-column wow fadeInRight">
                    <div class="sec-title">
                        <span class="sub-title">Company Benefits</span>
                        <h2>We're More Than An Company</h2>
                        <div class="text">Lorem ipsum dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et simply free text</div>
                    </div>
                    <div class="graph-box-two">
                        <!-- Pie Graph -->
                        <div class="pie-graph">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ffaa17" data-bgColor="#ffffff" data-width="115" data-height="115"
                                    data-linecap="normal" value="90">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="90" data-speed="2000"></span>%</div>
                            </div>
                            <h6 class="title">Affordable <br>cost</h6>
                        </div>
                        <!-- Pie Graph -->
                        <div class="pie-graph">
                            <div class="graph-outer">
                                <input type="text" class="dial" data-fgColor="#ffaa17" data-bgColor="#ffffff" data-width="115" data-height="115"
                                    data-linecap="normal" value="50">
                                <div class="inner-text count-box"><span class="count-text txt" data-stop="50" data-speed="2000"></span>%</div>
                            </div>
                            <h6 class="title">Quality <br>of work</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><section id="testimonial" class="testimonial-section-four">
	<div class="auto-container">
		<div class="row">
			<!-- Title Column -->
			<div class="title-column col-xl-5 col-lg-6 col-md-12">
				<div class="inner-column pe-lg-5">
					<div class="sec-title">
						<span class="sub-title">Our Testimonials</span>
						<h2>What They’re Talking About Us</h2>
						<div class="text">There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable</div>
					</div>
				</div>
			</div>

			<!-- Testimonial Column -->
			<div class="testimonial-column col-xl-7 col-lg-6 col-md-12">
				<div class="carousel-outer">
					<div class="testimonial-bg" style="background-image: url(images/resource/testimonial-bg.png)"></div>
					<div class="testimonial-carousel-four owl-carousel owl-theme">

						<!-- Testimonial Block Four -->
						<div class="testimonial-block-four">
							<div class="inner-box">
								<div class="content-box">
									<span class="icon icon-quote"></span>
									<div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
									<div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
								</div>
								<div class="info-box">
									<figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
									<h5 class="name">Jessica Brown</h5>
									<span class="designation">Co Founder</span>
								</div>
							</div>
						</div>

						<!-- Testimonial Block Four -->
						<div class="testimonial-block-four">
							<div class="inner-box">
								<div class="content-box">
									<span class="icon icon-quote"></span>
									<div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
									<div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
								</div>
								<div class="info-box">
									<figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
									<h5 class="name">Jessica Brown</h5>
									<span class="designation">Co Founder</span>
								</div>
							</div>
						</div>

						<!-- Testimonial Block Four -->
						<div class="testimonial-block-four">
							<div class="inner-box">
								<div class="content-box">
									<span class="icon icon-quote"></span>
									<div class="rating"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div>
									<div class="text">Proin a lacus arcu. Nullam id dui eu orci maximus. Cras at auctor lectus, vel pretium tellus. Class aptent sociosqu ad litora torquent per conubia nostra.</div>
								</div>
								<div class="info-box">
									<figure class="thumb"><img src="images/resource/testi-thumb-3.jpg" alt=""></figure>
									<h5 class="name">Jessica Brown</h5>
									<span class="designation">Co Founder</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><section id="services" class="services-section-two">
	<div class="auto-container">
		<div class="row">
			<div class="title-column col-lg-4 col-md-12">
				<div class="sec-title light">
					<span class="sub-title">What we offer</span>
					<h2>We Are Best For <br>Technology <br>Solution</h2>
					<a href="page-services.php" class="theme-btn btn-style-one"><span class="btn-title">Discover more</span></a>
				</div>
			</div>

			<div class="services-column col-lg-8 col-md-12">
				<div class="inner-column ps-lg-5">
					<!-- Services Carousel Two -->
					<div class="swiper-container services-carousel-two">
						<div class="swiper-wrapper">
							<!-- Service Block Two -->
							<div class="swiper-slide service-block-two">
								<div class="inner-box">
									<div class="icon fa fa-globe"></div>
									<h6 class="title"><a href="page-service-details.php">Website</a></h6>
								</div>
							</div>

							<!-- Service Block Two -->
							<div class="swiper-slide service-block-two">
								<div class="inner-box">
									<div class="icon fab fa-apple"></div>
									<h6 class="title"><a href="page-service-details.php">IOS</a></h6>
								</div>
							</div>

							<!-- Service Block Two -->
							<div class="swiper-slide service-block-two">
								<div class="inner-box">
									<div class="icon fab fa-android"></div>
									<h6 class="title"><a href="page-service-details.php">Android</a></h6>
								</div>
							</div>

							<!-- Service Block Two -->
							<div class="swiper-slide service-block-two">
								<div class="inner-box">
									<div class="icon fab fa-ioxhost"></div>
									<h6 class="title"><a href="page-service-details.php">IOT</a></h6>
								</div>
							</div>

							<!-- Service Block Two -->
							<div class="swiper-slide service-block-two">
								<div class="inner-box">
									<div class="icon fa fa-tv"></div>
									<h6 class="title"><a href="page-service-details.php">Television</a></h6>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><section id="news" class="news-section-three">
  <div class="auto-container">
    <div class="sec-title text-center">
      <span class="sub-title">From the Blog</span>
      <h2>Checkout latest news <br> updates & articles</h2>
    </div>

    <div class="row">
      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-1.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Your Business Safe Ensure High Availability</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="300ms">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-2.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Data Backup and Recovery Best Practices Small</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>

      <!-- News Block -->
      <div class="news-block-three col-lg-4 col-md-6 col-sm-12 wow fadeInUp">
        <div class="inner-box">
          <div class="image-box">
            <figure class="image"><a href="news-details.php"><img src="images/resource/news2-3.jpg" alt=""></a></figure>
          </div>
          <div class="content-box">
            <span class="date">20 April</span>
            <ul class="post-info">
              <li><i class="fa fa-user-circle"></i> by Admin</li>
              <li><i class="fa fa-comments"></i> 2 Comments</li>
            </ul>
            <h4 class="title"><a href="news-details.php">Make a Marketing Strategy for your Small Business</a></h4>
            <a href="news-details.php" class="read-more">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><section id="contact" class="contact-section-six pt-0">
    <div class="anim-icons"> <span class="icon icon-arrow1 bounce-x"></span> <span class="icon icon-arrow2 bounce-y"></span> </div>
    <div class="auto-container">
    <div class="outer-box">
        <div class="bg-image bg-img-pos" style="background-image: url(images/icons/pattern-36.jpg)"></div>
        <div class="sec-title">
        <span class="text">Get in touch</span>
        <h3>Let’s work together</h3>
        </div>
        <!-- Contact Form -->
        <div class="contact-form-six wow fadeInLeft"> 
        <!--Contact Form-->
        <form id="contact_form" name="contact_form" class="" action="includes/sendmail.php" method="post">
            <div class="row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
                <input type="text" name="full_name" placeholder="Your name" required>
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
                <input type="email" name="Email" placeholder="Email Address" required>
            </div>
            <div class="form-group col-lg-12">
                <textarea name="message" placeholder="Write a message" required></textarea>
            </div>
            <div class="form-group col-lg-12">
                <button class="theme-btn btn-style-one" type="submit" name="submit-form" data-loading-text="Please wait..."><span class="btn-title">Discover More</span></button>
            </div>
            </div>
        </form>
        </div>
        <!--End Contact Form -->
        <figure class="image"><img src="images/resource/slgirl-1.png" alt=""></figure>
    </div>
    </div>
</section><section class="map-section-two">
	<iframe  class="map"  src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=1%20Grafton%20Street,%20Dublin,%20Ireland+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
</section><!-- Main Footer -->
<footer class="main-footer">

<!--Widgets Section-->
<div class="widgets-section">
  <div class="auto-container">
    <div class="row">
      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-12 col-md-6 col-sm-12">
        <div class="footer-widget about-widget">
          <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" ></a></div>
          <div class="text">Desires to obtain pain of itself, because it is pain, but occasionally circumstances.</div>
          <ul class="social-icon-two">
            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a href="#"><i class="fab fa-facebook"></i></a></li>
            <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Useful Links</h3>
          <ul class="user-links">
            <li><a href="#">Team</a></li>
            <li><a href="#">Projects</a></li>
            <li><a href="#">Testimonial</a></li>
            <li><a href="#">Pricing</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget">
          <h3 class="widget-title">Explore</h3>
          <ul class="user-links">
            <li><a href="#">Data Visualization</a></li>
            <li><a href="#">UI/UX Designing</a></li>
            <li><a href="#">Digital Marketing</a></li>
            <li><a href="#">Marketing Strategy</a></li>
            <li><a href="#">Data Analysis</a></li>
            <li><a href="#">Security System</a></li>
          </ul>
        </div>
      </div>

      <!--Footer Column-->
      <div class="footer-column col-xl-3 col-lg-4 col-md-6 col-sm-12">
        <div class="footer-widget contact-widget">
          <h3 class="widget-title">Contact</h3>
          <div class="widget-content">
            <div class="text me-lg-4">66 Road Broklyn Street, 600 New York, USA</div>
            <ul class="contact-info">
              <li><i class="fa fa-envelope"></i> <a href="mailto:needhelp@yourdomain.com">needhelp@company.com</a><br></li>
              <li><i class="fa fa-phone-square"></i> <a href="tel:+926668880000">+92 666 888 0000</a><br></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Footer Bottom-->
<div class="footer-bottom">
  <div class="auto-container">
    <div class="inner-container">
      <div class="copyright-text">&copy; Copyright reserved by <a href="index.php">kodesolution.com</a>
      </div>
    </div>
  </div>
</div>
</footer>
<!--End Main Footer -->

</div><!-- End Page Wrapper -->

<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

<script src="js/jquery.js"></script> 
<script src="js/popper.min.js"></script>
<!--Revolution Slider-->
<!--Revolution Slider-->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/knob.js"></script>
<script src="js/mixitup.js"></script>
<script src="js/bxslider.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/script.js"></script>

<!-- form submit -->
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form.min.js"></script>
<script>
    (function ($) {
        $('#contact_form').validate({
        submitHandler: function (form) {
            const formBtn = $(form).find('button[type="submit"]');
            const formResultDivId = 'form-result';
            const formResultDiv = $('#' + formResultDivId);

            // Remove any existing result div
            formResultDiv.remove();

            // Insert a new result div before the submit button, initially hidden
            formBtn.before(`<div id="${formResultDivId}" class="alert alert-success" role="alert" style="display: none;"></div>`);

            const formBtnOldMsg = formBtn.html();

            // Disable button and show loading text if available
            const loadingText = formBtn.data('loading-text') || 'Loading...';
            formBtn.html(loadingText).prop('disabled', true);

            // Submit the form via AJAX
            $(form).ajaxSubmit({
            dataType: 'json',
            success: function (data) {
                if (data.status === 'true') {
                // Clear input fields only on success
                $(form).find('.form-control').val('');
                }

                // Re-enable button and restore original text
                formBtn.prop('disabled', false).html(formBtnOldMsg);

                // Show response message
                $('#' + formResultDivId).html(data.message).fadeIn('slow');

                // Hide message after 6 seconds
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            },
            error: function () {
                // Handle AJAX errors
                formBtn.prop('disabled', false).html(formBtnOldMsg);
                $('#' + formResultDivId).html('An error occurred. Please try again.').fadeIn('slow');
                setTimeout(() => {
                $('#' + formResultDivId).fadeOut('slow');
                }, 6000);
            }
            });
        }
        });

    })(jQuery);
    </script>
</body>
</html>